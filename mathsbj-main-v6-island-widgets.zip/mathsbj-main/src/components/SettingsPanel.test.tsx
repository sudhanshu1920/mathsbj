import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import SettingsPanel from "./SettingsPanel";
import { THEMES } from "@/lib/theme";

const mocks = vi.hoisted(() => ({
  theme: "arctic-blue",
  mode: "dark",
  setTheme: vi.fn(),
  setMode: vi.fn(),
  setGuest: vi.fn(),
  checkForAppUpdate: vi.fn(),
  announceUpdateAvailable: vi.fn(),
  getBackgroundNotificationsEnabled: vi.fn(),
  setBackgroundNotificationsEnabled: vi.fn(),
}));

vi.mock("@/lib/appVersion", () => ({ APP_VERSION_NAME: "1.0.0", APP_VERSION_CODE: 1 }));

vi.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({ user: null, signOut: vi.fn() }),
}));

vi.mock("@/lib/settings", () => {
  const base = () => ({
    sound: true,
    vibration: false,
    keyboardShortcuts: true,
    font: "space-grotesk",
  });
  return {
    getSettings: base,
    setSound: (sound: boolean) => ({ ...base(), sound }),
    setVibration: (vibration: boolean) => ({ ...base(), vibration }),
    setKeyboardShortcuts: (keyboardShortcuts: boolean) => ({ ...base(), keyboardShortcuts }),
  };
});

vi.mock("@/lib/streak", () => ({
  todayStr: () => "2026-10-18",
  getStreak: () => ({
    enabled: true,
    targetMinutes: 15,
    current: 2,
    best: 4,
    freezeUsedMonth: "2026-10",
    freezesUsed: 0,
    days: { "2026-10-18": { seconds: 120 } },
    lastEvalDate: "2026-10-18",
  }),
  setTarget: vi.fn(() => ({
    enabled: true,
    targetMinutes: 15,
    current: 2,
    best: 4,
    freezeUsedMonth: "2026-10",
    freezesUsed: 0,
    days: {},
    lastEvalDate: "2026-10-18",
  })),
}));

vi.mock("@/lib/guest", () => ({
  isGuest: () => true,
  setGuest: mocks.setGuest,
}));

vi.mock("@/lib/theme", async () => {
  const actual = await vi.importActual<typeof import("@/lib/theme")>("@/lib/theme");
  return {
    ...actual,
    setTheme: mocks.setTheme,
    setMode: mocks.setMode,
    useTheme: () => mocks.theme,
    useMode: () => mocks.mode,
  };
});

vi.mock("@/lib/appUpdateService", () => ({
  checkForAppUpdate: mocks.checkForAppUpdate,
}));

vi.mock("@/lib/appUpdateEvents", () => ({
  announceUpdateAvailable: mocks.announceUpdateAvailable,
}));

vi.mock("@/pages/WidgetStudioPage", () => ({
  default: ({ onBack }: { onBack: () => void }) => (
    <div>
      <p>Widget Studio Test Screen</p>
      <button type="button" onClick={onBack}>Back from Widget Studio</button>
    </div>
  ),
}));

vi.mock("@/lib/dailyTargetReminders", () => ({
  getBackgroundNotificationsEnabled: mocks.getBackgroundNotificationsEnabled,
  setBackgroundNotificationsEnabled: mocks.setBackgroundNotificationsEnabled,
}));

describe("SettingsPanel compact controls", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.theme = "arctic-blue";
    mocks.mode = "dark";
    mocks.getBackgroundNotificationsEnabled.mockReturnValue(true);
    mocks.setBackgroundNotificationsEnabled.mockResolvedValue(true);
    mocks.checkForAppUpdate.mockResolvedValue({ status: "current" });
  });

  it("opens the dedicated Widget Studio page from the compact Settings entry", () => {
    render(<SettingsPanel />);

    fireEvent.click(screen.getByRole("button", { name: "Widgets" }));
    expect(screen.getByText("Widget Studio Test Screen")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Back from Widget Studio" }));
    expect(screen.getByText("Sound")).toBeInTheDocument();
  });

  it("does not expose home-screen widget controls", () => {
    render(<SettingsPanel />);

    expect(screen.queryByText("Home Screen Widgets")).not.toBeInTheDocument();
    expect(screen.queryByText("Widget Content")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Preview/ })).not.toBeInTheDocument();
  });

  it("removes the font selector without removing the normal settings controls", () => {
    const { container } = render(<SettingsPanel />);

    expect(container.querySelector("[data-font-selector]")).toBeNull();
    expect(screen.queryByText("Font")).not.toBeInTheDocument();
    expect(screen.getByText("Sound")).toBeInTheDocument();
    expect(screen.getByText("Vibration")).toBeInTheDocument();
    expect(screen.getByText("Keyboard shortcuts")).toBeInTheDocument();
  });

  it("keeps the notification toggle and removes its supporting paragraphs", async () => {
    render(<SettingsPanel />);

    const toggle = screen.getByRole("switch", { name: "Enable background notifications" });
    expect(toggle).toBeInTheDocument();
    expect(screen.queryByText(/Daily study reminders start at noon/)).not.toBeInTheDocument();
    expect(screen.queryByText(/Permission is requested only when you turn this on/)).not.toBeInTheDocument();

    fireEvent.click(toggle);
    await waitFor(() => expect(mocks.setBackgroundNotificationsEnabled).toHaveBeenCalledWith(false));
  });

  it("renders compact named cards for every theme and preserves theme/mode actions", () => {
    const { container, rerender } = render(<SettingsPanel />);

    const themeButtons = screen.getAllByRole("button", { name: /^Select .* theme$/ });
    expect(themeButtons).toHaveLength(THEMES.length);
    expect(screen.getByRole("button", { name: "Select Arctic Blue theme" })).toHaveAttribute("aria-pressed", "true");

    for (const theme of THEMES) {
      const button = screen.getByRole("button", { name: `Select ${theme.name} theme` });
      expect(button).toHaveAttribute("aria-pressed");
      const swatchParts = button.querySelectorAll("[data-theme-swatch] > span");
      expect(swatchParts).toHaveLength(3);
      expect(swatchParts[0]).toHaveStyle({ background: theme.swatch[0] });
      expect(swatchParts[1]).toHaveStyle({ background: theme.swatch[1] });
      expect(swatchParts[2]).toHaveStyle({ background: theme.swatch[2] });
      expect(button.textContent).toContain(theme.name);
    }

    const grid = container.querySelector("[data-theme-selector-grid]");
    expect(grid).toHaveClass("grid", "grid-cols-4", "min-[480px]:grid-cols-5", "min-[768px]:grid-cols-6", "min-[1024px]:grid-cols-7");
    expect(grid?.querySelector("[data-theme-option]")).toHaveClass("h-10");
    expect(grid?.querySelectorAll("[data-theme-option]")).toHaveLength(THEMES.length);
    expect(grid?.querySelectorAll("[data-theme-swatch]")).toHaveLength(THEMES.length);
    expect(screen.getByText("Arctic Blue")).toBeInTheDocument();
    expect(screen.getByText("Soft Rose")).toBeInTheDocument();
    expect(container.querySelectorAll("[data-theme-selected-indicator]")).toHaveLength(1);
    expect(container.querySelector("[data-theme-mode-selector]")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Select Mint theme" }));
    expect(mocks.setTheme).toHaveBeenCalledWith("mint");

    mocks.theme = "mint";
    rerender(<SettingsPanel />);
    expect(screen.getByRole("button", { name: "Select Mint theme" })).toHaveAttribute("aria-pressed", "true");
    expect(screen.getByRole("button", { name: "Select Arctic Blue theme" })).toHaveAttribute("aria-pressed", "false");

    fireEvent.click(screen.getByRole("button", { name: "Light" }));
    expect(mocks.setMode).toHaveBeenCalledWith("light");
  });  
  it("opens the nested Study Mode settings page and returns without leaving Settings", () => {
    const { container } = render(<SettingsPanel />);

    const settingsText = container.textContent ?? "";
    expect(settingsText.indexOf("Keyboard shortcuts")).toBeLessThan(settingsText.indexOf("Study Mode"));
    expect(settingsText.indexOf("Study Mode")).toBeLessThan(settingsText.indexOf("Daily Target"));

    fireEvent.click(screen.getByRole("button", { name: "Study Mode" }));
    expect(screen.getByRole("heading", { name: "Study Mode" })).toBeInTheDocument();
    expect(screen.getByText("Available in the Android app")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Back to Settings" }));
    expect(screen.getByText("Sound")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Study Mode" })).toBeInTheDocument();
  });

  it("opens Backup & Restore and returns to Settings without disturbing existing controls", () => {
    render(<SettingsPanel />);

    fireEvent.click(screen.getByRole("button", { name: "Backup & Restore" }));
    expect(screen.getByRole("heading", { name: "Backup & Restore" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Create Backup" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Restore Backup" })).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Back to Settings" }));
    expect(screen.getByText("Sound")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Backup & Restore" })).toBeInTheDocument();
  });
  it("keeps the installed App Version visible in Settings", () => {
    render(<SettingsPanel />);
    expect(screen.getByText("App Version 1.0.0")).toBeInTheDocument();
  });
});
