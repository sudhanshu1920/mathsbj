MATH MASTER — EMERALD GLASS SCREEN TIME ISLAND + STUDY / DEVICE APPS WIDGETS

100% REFERENCE MATCH • SMOOTH SPRING MOTION • FILES ATTACHED — APPLY EXACTLY

PROJECT

Repository: "sudhanshu1920/mathsbj" (this Lovable project)

The attached ZIP "mathsbj-v6-changed-files.zip" contains complete, final, already-tested files laid out with their exact repository paths. Put them into the project exactly as provided. Do NOT re-implement, regenerate, reformat, rename or "improve" them.

1. FILES TO APPLY (copy byte-for-byte to the same path; overwrite when it exists)

NEW
- android-native/com/sudhanshu/mathsbj/ScreenTimeIslandMotion.java
- tools/island-preview/ScreenTimeIslandMotionTest.java

REPLACED
- android-native/com/sudhanshu/mathsbj/ScreenTimeIslandPainter.java
- android-native/com/sudhanshu/mathsbj/ScreenTimeIslandOverlay.java
- android-native/com/sudhanshu/mathsbj/MathMasterWidgetRenderer.java
- src/components/StudyModePage.tsx
- src/index.css
- scripts/configure-android-study-mode.mjs
- scripts/configure-android-study-mode.test.mjs
- scripts/study-mode-focus-service.test.mjs
- scripts/verify-architecture.mjs
- scripts/android-widget-layout.test.mjs
- tools/island-preview/IslandPainterPreview.java
- tools/island-preview/run-tests.sh
- tools/island-preview/render-previews.sh
- tools/island-preview/README.md
- docs/STUDY_MODE_AND_APP_USAGE_ANALYTICS.md
- docs/HOME_SCREEN_WIDGET.md
- CHANGELOG.md

2. WHAT THE FILES DO

Dynamic Island (Study Mode, every 5 minutes of non-study app use):
- ScreenTimeIslandPainter: emerald neon-glass pill exactly like the approved reference — app icon tile, app name over "Screen Time · Today", hairline divider, big usage time with smaller units ("20 min", "1 hr 24 min"), four-bar equalizer glyph, glass bubble on the top-right rim, neon rim and soft halo. Collapsed state is a camera-black pill that lights up as it expands.
- ScreenTimeIslandMotion: Android-free timeline (spring morph, staggered content, count-up, press feedback, drag-to-dismiss, hold timer, reduced-motion cross-fade).
- ScreenTimeIslandOverlay: one fixed overlay window driven by Choreographer frame time. It no longer resizes the window on every frame, which removes the animation jank. The public constructor is unchanged, so StudyModeFocusService is untouched.

Study Apps / Device Apps widgets:
- MathMasterWidgetRenderer: reference glass dashboard — gradient header tile (green book / blue phone), title, glass "Today" pill with chevron button, thick gradient usage ring with the total (numbers bold, units lighter), up to three glass rows (icon, name, mint/cyan/lavender usage bar, duration, green percent, chevron), footer message pill, glass bubble and reflection curves. The same tile, pill and rows are used in the compact two-panel layout.

In-app settings card: StudyModePage.tsx + index.css show the same emerald look in the animated mini preview (decorative, aria-hidden, reduced-motion safe).

Registration: ScreenTimeIslandMotion.java is listed in NATIVE_FILES of scripts/configure-android-study-mode.mjs. The Android CI copies Java files from that list; if the entry is missing the APK build breaks.

3. HARD RULES

- Do not edit any other file. In particular do NOT touch StudyModeFocusService.java, StudyModeManager.java, StudyModePlugin.java, WidgetScreenTimeRepository.java, MathMasterHomeWidgetProvider.java or MathMasterWidgetConfigActivity.java.
- Do not rename classes or methods, change public constructors, or add dependencies, permissions, services or network calls.
- Keep the single provider + bitmap renderer architecture and all Study Mode behaviour (Shield, periodic reminder, Pro strict mode, schedules).
- No sample or fake usage data in production code. The "App name / 20 min" text inside the settings-card mini preview is decorative and aria-hidden only.
- If a target file in the project differs from the version these files were built on and cannot be overwritten cleanly, STOP and report the conflict. Do not merge by hand.

4. VERIFY (run what your environment allows and report honestly)

- node scripts/verify-architecture.mjs
- node scripts/study-mode-focus-service.test.mjs
- node scripts/configure-android-study-mode.test.mjs
- node scripts/android-widget-layout.test.mjs
- npm run island:preview (needs a JDK; expect "PASS ScreenTimeIslandMotion")
- TypeScript build and lint for src/components/StudyModePage.tsx and src/index.css

The Android APK is built by GitHub Actions. Do not claim an Android build or a real-device test that you did not run.

5. ACCEPTANCE

- The Island looks like the reference: one wide glass pill, emerald neon rim with halo, icon tile, name + "Screen Time · Today", divider, big time with small units, equalizer glyph, glass bubble.
- The expand/collapse animation is smooth (no window relayout per frame), springs with a small overshoot, and the hold timer pauses while touched.
- Study Apps and Device Apps widgets look like the reference card in every size, with no overlapping or clipped text.
- All listed checks pass and no other file changed.

FINAL STRICT RULE

Apply the supplied files exactly. No decorative rewrites, no hardcoded usage values, no extra refactors.

If your environment supports branches and pull requests, work on a feature branch and open a PR against "main"; do not merge without explicit approval. Otherwise apply the change directly and never force-push.

Report: exact files changed, commands run with pass/fail, and anything that could not be verified.
