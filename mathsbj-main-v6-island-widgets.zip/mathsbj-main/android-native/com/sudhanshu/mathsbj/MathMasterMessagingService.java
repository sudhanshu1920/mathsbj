package com.sudhanshu.mathsbj;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class MathMasterMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "app_updates";
    private static final int NOTIFICATION_ID = 8703;
    private static final String UPDATE_NOTIFICATION_TITLE = "New Update Available";
    private static final String UPDATE_NOTIFICATION_BODY = "A new version of Math Master is ready. Update now to enjoy the latest improvements.";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        boolean enabled = getSharedPreferences("math_master_background_notifications", Context.MODE_PRIVATE)
            .getBoolean("updateAlertsEnabled", false);
        if (enabled) {
            com.google.firebase.messaging.FirebaseMessaging.getInstance()
                .subscribeToTopic("math_app_updates")
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        android.util.Log.i("MathAppNotifications", "FCM topic subscription restored after token refresh.");
                    } else {
                        android.util.Log.w("MathAppNotifications", "FCM topic subscription restore failed after token refresh.");
                    }
                });
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Map<String, String> data = message.getData();
        boolean enabled = getSharedPreferences("math_master_background_notifications", Context.MODE_PRIVATE)
            .getBoolean("updateAlertsEnabled", false);
        if (!enabled) {
            android.util.Log.i("MathAppNotifications", "Update push ignored because the user has disabled background notifications.");
            return;
        }
        if (!"app_update".equals(data.get("type"))) {
            android.util.Log.w("MathAppNotifications", "Ignoring an update push with an unknown message type.");
            return;
        }
        String versionName = data.get("versionName");
        String versionCode = data.get("versionCode");
        String apkUrl = data.get("apkUrl");
        String checksum = data.get("sha256");
        String manifestUrl = data.get("updateManifestUrl");
        long numericVersionCode = -1L;
        try {
            numericVersionCode = Long.parseLong(versionCode == null ? "" : versionCode);
        } catch (NumberFormatException ignored) {
            // Invalid release metadata is rejected below.
        }
        if (versionName == null || !versionName.matches("[0-9]+\\.[0-9]+\\.[0-9]+")
            || numericVersionCode < 1L || numericVersionCode > 2100000000L
            || !"https://github.com/sudhanshu1920/mathsbj-updates/releases/download/latest/MathMaster-release.apk".equals(apkUrl)
            || checksum == null || !checksum.matches("(?i)[a-f0-9]{64}")
            || !"https://raw.githubusercontent.com/sudhanshu1920/mathsbj-updates/main/updates/update.json".equals(manifestUrl)) {
            android.util.Log.w("MathAppNotifications", "Ignoring update push with invalid release metadata.");
            return;
        }
        long installedVersionCode;
        try {
            android.content.pm.PackageInfo installed = getPackageManager()
                .getPackageInfo(getPackageName(), 0);
            installedVersionCode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? installed.getLongVersionCode()
                : installed.versionCode;
            if (numericVersionCode <= installedVersionCode) {
                android.util.Log.i("MathAppNotifications",
                    "Update push skipped because this installation is already at the announced version.");
                return;
            }
        } catch (Exception versionError) {
            android.util.Log.w("MathAppNotifications",
                "Update push skipped because the installed version could not be verified.");
            return;
        }

        // Version metadata remains validated above for update detection and secure routing,
        // but notification copy is deliberately version-free and never trusts remote text.
        showUpdateNotification(data);
    }

    private void showUpdateNotification(Map<String, String> data) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "App Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("New Math Master release notifications.");
            manager.createNotificationChannel(channel);
        }

        if (!androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            android.util.Log.w("MathAppNotifications",
                "Update notification was not posted because app-level notifications are disabled.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel existing = manager.getNotificationChannel(CHANNEL_ID);
            if (existing != null && existing.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                android.util.Log.w("MathAppNotifications",
                    "Update notification was not posted because the App Updates channel is disabled.");
                return;
            }
        }

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setAction("com.sudhanshu.mathsbj.OPEN_APP_UPDATE");
        openApp.putExtra("mathmaster_notification_action", "app-update");
        openApp.putExtra("mathmaster_update_version_name", data.get("versionName"));
        openApp.putExtra("mathmaster_update_version_code", data.get("versionCode"));
        openApp.putExtra("mathmaster_update_manifest_url", data.get("updateManifestUrl"));
        openApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        builder
            .setSmallIcon(getApplicationInfo().icon)
            .setContentTitle(UPDATE_NOTIFICATION_TITLE)
            .setContentText(UPDATE_NOTIFICATION_BODY)
            .setStyle(new Notification.BigTextStyle().bigText(UPDATE_NOTIFICATION_BODY))
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setWhen(System.currentTimeMillis());
        Notification notification = builder.build();
        manager.notify("mathmaster-update", NOTIFICATION_ID, notification);
        android.util.Log.i("MathAppNotifications",
            "Update notification posted to NotificationManager; actual device presentation is not observable here.");
    }
}
