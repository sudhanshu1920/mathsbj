import { BookOpen, ListChecks, BarChart3 } from 'lucide-react';
import { forwardRef, memo, useCallback, useRef } from 'react';
import { playClick } from '@/lib/sound';

interface BottomNavProps {
  active: 'learn' | 'practice' | 'progress';
  hidden?: boolean;
  onChange: (tab: 'learn' | 'practice' | 'progress') => void;
  onDoubleTap?: (tab: 'learn' | 'practice' | 'progress') => void;
}

const tabs = [
  { id: 'learn' as const, label: 'Learning', icon: BookOpen },
  { id: 'practice' as const, label: 'Quiz', icon: ListChecks },
  { id: 'progress' as const, label: 'Progress', icon: BarChart3 },
];

const DOUBLE_TAP_DELAY = 280;

const BottomNavBase = forwardRef<HTMLElement, BottomNavProps>(({ active, hidden = false, onChange, onDoubleTap }, ref) => {
  const lastTap = useRef<{
    tabId: 'learn' | 'practice' | 'progress';
    at: number;
    wasActive: boolean;
  } | null>(null);

  const handleTap = useCallback((tabId: 'learn' | 'practice' | 'progress') => {
    const now = Date.now();
    const previousTap = lastTap.current;
    const isDoubleTap =
      previousTap?.tabId === tabId &&
      now - previousTap.at < DOUBLE_TAP_DELAY &&
      previousTap.wasActive;

    // A double tap is a deliberate reset only when the *first* tap was on
    // the already-active tab. Rapidly selecting an inactive tab, or tapping
    // different tabs in quick succession, must never reset the wrong section.
    if (isDoubleTap) {
      lastTap.current = null;
      onDoubleTap?.(tabId);
      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(10);
    } else {
      lastTap.current = {
        tabId,
        at: now,
        wasActive: active === tabId,
      };
      onChange(tabId);
    }

    // Audio synthesis can allocate WebAudio nodes. Let React commit the
    // navigation/pressed state before doing this non-critical feedback work.
    if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(() => playClick());
    } else {
      playClick();
    }
  }, [active, onChange, onDoubleTap]);

  return (
    <nav
      ref={ref}
      data-app-floating-nav="true"
      aria-label="Primary navigation"
      aria-hidden={hidden || undefined}
      hidden={hidden}
      style={hidden ? { display: "none" } : undefined}
      className="bottom-nav fixed bottom-0 left-0 right-0 z-40 glass-panel border-t border-b-0 border-x-0"
    >
      <div className="flex h-full max-w-lg mx-auto items-center justify-around px-1">
        {tabs.map((tab) => {
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => handleTap(tab.id)}
              className={`motion-press bottom-nav-item-button relative flex flex-1 h-full min-h-[48px] flex-col items-center justify-center gap-0.5 py-1 ${
                isActive ? 'is-active' : ''
              }`}
              aria-current={isActive ? 'page' : undefined}
              aria-label={tab.label}
            >
              <div
                className={`bottom-nav-item relative flex h-7 w-12 items-center justify-center rounded-xl border ${
                  isActive ? 'is-active' : ''
                }`}
              >
                <tab.icon size={19} strokeWidth={2.5} />
              </div>
              <span
                className={`text-[9px] leading-none font-display font-extrabold uppercase tracking-wider ${
                  isActive ? 'text-primary neon-text' : 'text-muted-foreground'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
});

BottomNavBase.displayName = 'BottomNav';

const BottomNav = memo(BottomNavBase);
BottomNav.displayName = 'BottomNav';

export default BottomNav;