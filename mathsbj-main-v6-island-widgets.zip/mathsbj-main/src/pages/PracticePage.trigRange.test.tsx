import { fireEvent, render, screen, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import PracticePage, { generateQuestions } from '@/pages/PracticePage';
import { TRIG_ANGLES, type TrigFunction } from '@/lib/trigData';
import { getTablesProMode, setTablesProMode } from '@/lib/settings';

describe('Learning Table of Angles practice generator range', () => {
  const makeQuestions = (trigProMode: boolean, trigFunctions: TrigFunction[]) =>
    generateQuestions({
      topics: [{
        id: 'trig',
        label: 'Trigonometry',
        range: { from: 0, to: 360, trigFunctions, trigProMode },
      }],
      count: trigFunctions.length * (trigProMode ? TRIG_ANGLES.length : 5),
      infinite: false,
      mode: 'input',
      timerMode: 'off',
      timerSeconds: 9999,
      sequential: false,
      repetitionEnabled: false,
      repetitionByTopic: {},
    });

  it('enforces Standard 0°–90° and Pro 0°–360° inside generated question pools', () => {
    const standard = makeQuestions(false, ['sin']);
    expect(standard).toHaveLength(5);
    expect(standard.every((question) => question.trigFunctionId === 'sin')).toBe(true);
    expect(standard.every((question) => question.trigAngle !== undefined && question.trigAngle <= 90)).toBe(true);

    const pro = makeQuestions(true, ['sin']);
    expect(pro).toHaveLength(TRIG_ANGLES.length);
    expect(pro.every((question) => question.trigFunctionId === 'sin')).toBe(true);
    expect(pro.some((question) => question.trigAngle !== undefined && question.trigAngle > 90)).toBe(true);
    expect(pro.map((question) => question.trigAngle).sort((a, b) => Number(a) - Number(b)))
      .toEqual([...TRIG_ANGLES]);
  });

  it('keeps an individual function isolated and supports multiple selected functions', () => {
    const single = makeQuestions(true, ['cos']);
    expect(single.every((question) => question.trigFunctionId === 'cos')).toBe(true);
    const combined = makeQuestions(false, ['sin', 'cos']);
    expect(combined).toHaveLength(10);
    expect(new Set(combined.map((question) => question.trigFunctionId))).toEqual(new Set(['sin', 'cos']));
    expect(combined.every((question) => question.trigAngle !== undefined && question.trigAngle <= 90)).toBe(true);
  });
});

describe('Quiz Arena trigonometry angle-range control', () => {
  it('defaults to Standard Mode and switches the setup selection to Pro Mode', () => {
    render(<PracticePage />);

    fireEvent.click(screen.getByRole('button', { name: /Trigonometry/ }));

    expect(screen.getByText('Trigonometry Quiz – Angle Range')).toBeInTheDocument();
    const rangeGroup = screen.getByRole('group', { name: 'Trigonometry quiz angle range' });
    const standardButton = within(rangeGroup).getByRole('button', { name: /Standard Mode.*0°–90°/ });
    const proButton = within(rangeGroup).getByRole('button', { name: /Pro Mode.*0°–360°/ });

    expect(standardButton).toHaveAttribute('aria-pressed', 'true');
    expect(proButton).toHaveAttribute('aria-pressed', 'false');

    fireEvent.click(proButton);

    expect(standardButton).toHaveAttribute('aria-pressed', 'false');
    expect(proButton).toHaveAttribute('aria-pressed', 'true');

    fireEvent.click(standardButton);

    expect(standardButton).toHaveAttribute('aria-pressed', 'true');
    expect(proButton).toHaveAttribute('aria-pressed', 'false');
  });

  it('keeps function selection independent from the selected angle range', () => {
    render(<PracticePage />);
    fireEvent.click(screen.getByRole('button', { name: /Trigonometry/ }));

    const rangeGroup = screen.getByRole('group', { name: 'Trigonometry quiz angle range' });
    fireEvent.click(within(rangeGroup).getByRole('button', { name: /Pro Mode.*0°–360°/ }));

    // All six functions are selected by default. Keep sin/cos selected and
    // deselect the other four while Pro Mode is active.
    const sinButton = screen.getByRole('button', { name: 'sin θ' });
    const cosButton = screen.getByRole('button', { name: 'cos θ' });
    fireEvent.click(screen.getByRole('button', { name: 'Select All' }));
    for (const fn of ['tan', 'cot', 'sec', 'cosec']) {
      fireEvent.click(screen.getByRole('button', { name: `${fn} θ` }));
    }

    expect(sinButton).toHaveAttribute('aria-pressed', 'true');
    expect(cosButton).toHaveAttribute('aria-pressed', 'true');
    for (const fn of ['tan', 'cot', 'sec', 'cosec']) {
      expect(screen.getByRole('button', { name: `${fn} θ` })).toHaveAttribute('aria-pressed', 'false');
    }
    expect(within(rangeGroup).getByRole('button', { name: /Pro Mode.*0°–360°/ })).toHaveAttribute('aria-pressed', 'true');
  });
});


describe('Quiz Arena Tables Pro Mode', () => {
  it('uses the shared Learning/Quiz Pro Mode setting from the Tables range panel', () => {
    const previousProMode = getTablesProMode();
    setTablesProMode(false);
    const { unmount } = render(<PracticePage />);

    try {
      fireEvent.click(screen.getByRole('button', { name: /Tables \(/ }));

      const proModeSwitch = screen.getByRole('switch', { name: 'Tables Pro Mode' });
      expect(proModeSwitch).not.toBeChecked();
      expect(screen.getByText('×1 – ×10 per table')).toBeInTheDocument();

      fireEvent.click(proModeSwitch);
      expect(proModeSwitch).toBeChecked();
      expect(screen.getByText('×1 – ×20 per table')).toBeInTheDocument();
      expect(getTablesProMode()).toBe(true);

      fireEvent.click(proModeSwitch);
      expect(proModeSwitch).not.toBeChecked();
      expect(screen.getByText('×1 – ×10 per table')).toBeInTheDocument();
      expect(getTablesProMode()).toBe(false);
    } finally {
      unmount();
      setTablesProMode(previousProMode);
    }
  });
});

describe('Quiz Arena Challenge timer controls', () => {
  it('keeps Challenge and the per-question Timer mutually exclusive', () => {
    render(<PracticePage />);

    const perQuestionTimer = screen.getByRole('switch', { name: 'Per-question timer' });
    const challengeTimer = screen.getByRole('switch', { name: 'Challenge timer' });

    expect(perQuestionTimer).toBeChecked();
    expect(challengeTimer).not.toBeChecked();

    fireEvent.click(challengeTimer);
    expect(challengeTimer).toBeChecked();
    expect(perQuestionTimer).not.toBeChecked();

    const tenMinuteOption = screen.getByRole('button', { name: '10m' });
    expect(tenMinuteOption).toHaveAttribute('aria-pressed', 'false');
    fireEvent.click(tenMinuteOption);
    expect(tenMinuteOption).toHaveAttribute('aria-pressed', 'true');

    fireEvent.click(perQuestionTimer);
    expect(perQuestionTimer).toBeChecked();
    expect(challengeTimer).not.toBeChecked();
  });

  it('disables fixed Questions choices during Challenge and restores them when Challenge is turned off', () => {
    render(<PracticePage />);

    const allButtons = screen.getAllByRole('button');
    const fixedOptions = ['10', '20', '25', '50', '∞'].map((name) => {
      const button = allButtons.find((candidate) => candidate.textContent?.trim() === name);
      if (!(button instanceof HTMLButtonElement)) {
        throw new Error(`Question-count button "${name}" did not render.`);
      }
      return button;
    });
    expect(fixedOptions.every((button) => !button.disabled)).toBe(true);

    const challengeTimer = screen.getByRole('switch', { name: 'Challenge timer' });
    fireEvent.click(challengeTimer);

    expect(fixedOptions.every((button) => button.disabled)).toBe(true);
    for (const button of fixedOptions) {
      expect(button).toHaveClass('cursor-not-allowed');
      fireEvent.click(button);
      expect(button).toBeDisabled();
    }

    fireEvent.click(challengeTimer);
    expect(fixedOptions.every((button) => !button.disabled)).toBe(true);
  });

  it('starts the selected full-session countdown only with Start Quiz and counts submitted answers', () => {
    render(<PracticePage />);

    fireEvent.click(screen.getByRole('switch', { name: 'Challenge timer' }));
    fireEvent.click(screen.getByRole('button', { name: '10m' }));

    expect(screen.queryByText('10:00')).not.toBeInTheDocument();
    expect(screen.queryByText('Solved 0')).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Start Quiz' }));

    expect(screen.getByText('10:00')).toBeInTheDocument();
    expect(screen.getByText('Solved 0')).toBeInTheDocument();

    const firstOption = document.querySelector<HTMLButtonElement>('.mcq-options-grid button');
    expect(firstOption).not.toBeNull();
    if (!firstOption) throw new Error('The first MCQ option did not render.');
    fireEvent.click(firstOption);

    expect(screen.getByText('Solved 1')).toBeInTheDocument();
  });
});
