package android.content;
public abstract class Context {
    public static final int MODE_PRIVATE = 0;
    public abstract SharedPreferences getSharedPreferences(String name, int mode);
    public abstract String getPackageName();
    public abstract android.content.res.Resources getResources();
    public abstract android.content.res.AssetManager getAssets();
    public abstract Context getApplicationContext();
    public abstract android.content.pm.PackageManager getPackageManager();
}
