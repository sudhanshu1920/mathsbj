package com.sudhanshu.mathsbj;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.KeyguardManager;
import android.os.PowerManager;
import android.media.AudioManager;
import android.os.SystemClock;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.res.Configuration;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.LruCache;
import android.util.Log;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class StudyModeFocusService extends Service {
    private static final String CHANNEL_ID = "study_mode_focus";
    private static final int NOTIFICATION_ID = 9528;
    private static final long POLL_INTERVAL_MS = 1000L;
    private static final long INITIAL_EVENT_LOOKBACK_MS = 24L * 60L * 60L * 1000L;
    private static final long EVENT_QUERY_OVERLAP_MS = 5000L;
    private static final long EMPTY_INITIAL_LOOKUP_RETRY_MS = 60_000L;
    private static final long EMPTY_INITIAL_LOOKUP_FALLBACK_MS = 30_000L;
    private static final long POPUP_RETRY_FIRST_BACKOFF_MS = 2000L;
    private static final long POPUP_RETRY_SECOND_BACKOFF_MS = 6000L;
    private static final long POPUP_RETRY_RECOVERY_BACKOFF_MS = 30_000L;
    private static final long MIN_IMMEDIATE_RECHECK_INTERVAL_MS = 250L;
    private static final long MONITOR_HEALTH_TIMEOUT_MS = 10_000L;
    private static final long MONITOR_THREAD_RETRY_MS = 3_000L;
    private static final int MAX_POPUP_FAILURES_PER_FOREGROUND = 3;
    private static final String LOG_TAG = "MathMasterStudyMode";
    private static volatile boolean running = false;
    private static volatile boolean starting = false;
    private static volatile boolean stopping = false;
    private static volatile StudyModeFocusService activeService;

    public static boolean isStopping() {
        return stopping;
    }

    public static void markStopping() {
        if (running) stopping = true;
    }

    public static boolean isStarting() {
        return starting;
    }

    public static void markStarting() {
        starting = true;
    }

    public static void clearStarting() {
        starting = false;
    }

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object monitorThreadLock = new Object();
    private volatile HandlerThread monitorThread;
    private volatile Handler monitorHandler;
    private volatile long monitorGeneration = 0L;
    private volatile long monitorThreadStartedElapsedMs = 0L;
    private volatile long lastMonitorHeartbeatElapsedMs = 0L;
    private final AtomicBoolean monitorRecoveryInFlight = new AtomicBoolean(false);
    private final AtomicBoolean immediateEvaluationQueued = new AtomicBoolean(false);
    private volatile long lastImmediateEvaluationElapsedMs = 0L;
    private final Runnable immediateEvaluationRunnable = this::runImmediateEvaluation;
    private WindowManager windowManager;
    private android.view.View shieldView;
    private TextView remainingTimeView;
    private TextView sessionEndView;
    private final StudyModeUsageAccumulator periodicReminderUsage = new StudyModeUsageAccumulator();
    private final StudyModeUsageAccumulator islandUsage = new StudyModeUsageAccumulator();
    private final AtomicBoolean islandRequestInFlight = new AtomicBoolean(false);
    private volatile ScreenTimeIslandOverlay screenTimeIslandOverlay;
    private volatile long islandDueElapsedMs = 0L;
    private String islandTrackedPackage = "";
    private long islandTrackedPackageSinceWallMs = 0L;
    private static volatile ScreenTimeIslandOverlay previewIslandOverlay;
    private final AtomicBoolean periodicReminderVisible = new AtomicBoolean(false);
    private android.view.View periodicReminderView;
    private volatile String periodicReminderPackage = "";
    private volatile String periodicReminderId = "";
    private LinearLayout periodicReminderStudyAppsSection;
    private TextView periodicReminderAppsError;
    private volatile long lastReminderUsagePersistElapsedMs = 0L;
    private volatile long lastPersistedReminderUsageMs = -1L;
    private enum PopupState { IDLE, LAUNCH_PENDING, VISIBLE, RECOVERY_REQUIRED }

    private String shieldedPackage = "";
    private String activeShieldRequestId = "";
    private volatile PopupState popupState = PopupState.IDLE;
    private boolean foregroundStarted = false;

    // UsageEvents is consumed from a moving cursor with a small overlap. This avoids
    // losing an app transition when the monitor thread is delayed for longer than a
    // fixed rolling lookback window.
    private String lastForegroundPackage = null;
    private String lastDecisionPackage = null;
    private boolean lastDecisionShouldShield = false;
    private long lastUsageEventScanTimeMs = 0L;
    private long lastFullLookupElapsedMs = 0L;
    private boolean hasResolvedForegroundOnce = false;
    private String lastLoggedForegroundPackage = null;
    private String lastLoggedBlockedPackage = null;
    private boolean foregroundUnknownLogged = false;
    private boolean foregroundLookupFailureLogged = false;
    private boolean windowSnapshotUnavailableLogged = false;
    private boolean permissionUnavailableLogged = false;
    private String failedPopupPackage = "";
    private int failedPopupAttempts = 0;
    private long nextPopupRetryElapsedMs = 0L;
    private volatile String activeDiagnosticSessionId = "none";
    private long lastDiagnosticSessionRefreshElapsedMs = 0L;
    private final AtomicLong foregroundDecisionSequence = new AtomicLong(0L);

    public static boolean isRunning() {
        return running;
    }

    /**
     * A service process being alive is not proof that its monitor thread is
     * still processing app/window events. Require a live HandlerThread and a
     * recent monitor heartbeat before exposing a healthy monitoring state.
     */
    public static boolean isMonitoringHealthy() {
        StudyModeFocusService service = activeService;
        return running && !stopping && service != null && service.isMonitorThreadHealthy();
    }

    private boolean isMonitorThreadHealthy() {
        if (!foregroundStarted || !running || stopping) return false;
        if (StudyModeManager.isPolicyOwner(this)) return true;
        HandlerThread thread = monitorThread;
        Handler handler = monitorHandler;
        long heartbeat = lastMonitorHeartbeatElapsedMs;
        return thread != null && thread.isAlive()
            && handler != null && thread.getLooper() != null
            && thread.getLooper().getThread().isAlive()
            && heartbeat > 0L
            && SystemClock.elapsedRealtime() - heartbeat <= MONITOR_HEALTH_TIMEOUT_MS;
    }

    public static boolean isMonitorStarting() {
        StudyModeFocusService service = activeService;
        if (!running || stopping || service == null || StudyModeManager.isPolicyOwner(service)) return false;
        HandlerThread thread = service.monitorThread;
        return thread != null && thread.isAlive()
            && service.lastMonitorHeartbeatElapsedMs == 0L
            && SystemClock.elapsedRealtime() - service.monitorThreadStartedElapsedMs
                <= MONITOR_HEALTH_TIMEOUT_MS;
    }

    public static boolean isBlockingActive() {
        StudyModeFocusService service = activeService;
        return service != null && running
            && service.popupState == PopupState.VISIBLE
            && service.isShieldViewVisible(service.shieldView);
    }

    public static String getMonitoringState() {
        StudyModeFocusService service = activeService;
        if (!running || service == null) return starting ? "focus_shield_starting" : "service_stopped";
        if (StudyModeManager.isPolicyOwner(service)) return "system_suspension";
        if (service.popupState == PopupState.VISIBLE && isBlockingActive()) return "blocking_active";
        if (service.popupState == PopupState.LAUNCH_PENDING) return "blocking_pending";
        if (service.popupState == PopupState.RECOVERY_REQUIRED || hasOverlayFailure()) return "overlay_failed";
        if (isMonitoringHealthy()) return "focus_shield_running";
        if (isMonitorStarting()) return "focus_shield_starting";
        return "monitoring_unavailable";
    }

    /**
     * Recover a failed/dead monitor inside an already-running foreground
     * service. This avoids starting a second FGS while the original one lives.
     */
    public static boolean requestMonitorRecovery(String reason) {
        StudyModeFocusService service = activeService;
        if (service == null || !running || stopping) return false;
        if (service.isMonitorThreadHealthy()) return true;
        return service.ensureMonitorThreadStarted(reason == null ? "unspecified" : reason);
    }

    private boolean ensureMonitorThreadStarted(String reason) {
        if (!running || stopping || StudyModeManager.isPolicyOwner(this)
            || !StudyModeManager.shouldEnforceNow(this)
            || !StudyModeManager.hasForegroundMonitoringPermission(this)
            || !StudyModeManager.hasOverlayPermission(this)) return false;

        if (isMonitorThreadHealthy()) return true;
        HandlerThread currentThread = monitorThread;
        if (currentThread != null && currentThread.isAlive()
            && lastMonitorHeartbeatElapsedMs == 0L
            && SystemClock.elapsedRealtime() - monitorThreadStartedElapsedMs
                <= MONITOR_HEALTH_TIMEOUT_MS) {
            return true;
        }
        if (!monitorRecoveryInFlight.compareAndSet(false, true)) return false;

        try {
            synchronized (monitorThreadLock) {
                if (isMonitorThreadHealthy()) return true;
                periodicReminderUsage.pause();
                long generation = ++monitorGeneration;
                foregroundDecisionSequence.incrementAndGet();

                Handler previousHandler = monitorHandler;
                if (previousHandler != null) previousHandler.removeCallbacksAndMessages(null);
                HandlerThread previousThread = monitorThread;
                if (previousThread != null) previousThread.quitSafely();
                monitorHandler = null;
                monitorThread = null;
                lastMonitorHeartbeatElapsedMs = 0L;

                HandlerThread replacement = new HandlerThread(
                    "StudyModeMonitor",
                    android.os.Process.THREAD_PRIORITY_BACKGROUND
                );
                replacement.start();
                Looper looper = replacement.getLooper();
                if (looper == null || !replacement.isAlive()) {
                    replacement.quitSafely();
                    StudyModeManager.setServiceState(this, "monitoring_unavailable");
                    logStage("PROCESS_RECOVERY_FAILED", "", "", "failed", "monitor_looper_unavailable");
                    return false;
                }

                monitorThread = replacement;
                monitorHandler = new Handler(looper);
                monitorThreadStartedElapsedMs = SystemClock.elapsedRealtime();
                activeService = this;
                if (!monitorHandler.post(monitorRunnable)) {
                    monitorHandler.removeCallbacksAndMessages(null);
                    replacement.quitSafely();
                    monitorHandler = null;
                    monitorThread = null;
                    StudyModeManager.setServiceState(this, "monitoring_unavailable");
                    logStage("PROCESS_RECOVERY_FAILED", "", "", "failed", "monitor_handler_rejected");
                    return false;
                }
                StudyModeManager.setServiceState(this, "focus_shield_starting");
                logStage("PROCESS_RECOVERY_STARTED", "", "", "started",
                    reason + "_generation_" + generation);
                return true;
            }
        } catch (RuntimeException recoveryFailure) {
            StudyModeManager.setServiceState(this, "monitoring_unavailable");
            logStage("PROCESS_RECOVERY_FAILED", "", "", "failed",
                recoveryFailure.getClass().getSimpleName());
            return false;
        } finally {
            monitorRecoveryInFlight.set(false);
        }
    }

    private void scheduleMonitorCycle(long delayMs, long expectedGeneration) {
        if (!running || expectedGeneration != monitorGeneration) return;
        Handler handler = monitorHandler;
        HandlerThread thread = monitorThread;
        if (handler == null || thread == null || !thread.isAlive()) {
            StudyModeManager.setServiceState(this, "monitoring_unavailable");
            return;
        }
        handler.removeCallbacks(monitorRunnable);
        if (!handler.postDelayed(monitorRunnable, Math.max(0L, delayMs))) {
            lastMonitorHeartbeatElapsedMs = 0L;
            StudyModeManager.setServiceState(this, "monitoring_unavailable");
            logStage("PROCESS_RECOVERY_FAILED", "", "", "failed", "monitor_handler_rejected");
        }
    }

    /**
     * AccessibilityService calls this after a real app-window event. Rechecks
     * run on the monitor HandlerThread and are bounded/coalesced.
     */
    public static void onReminderIntervalChanged(Context context, int intervalMinutes) {
        if (context == null || !StudyModeUsageAccumulator.isValidInterval(intervalMinutes)) return;
        StudyModeFocusService service = activeService;
        if (service == null || !running) {
            // A pending ID without a live overlay is an unshown reminder. A new
            // interval invalidates it, including when the service is restarting.
            StudyModeManager.clearPendingPeriodicReminder(context);
            return;
        }
        Handler handler = service.monitorHandler;
        Runnable applyInterval = () -> {
            if (!running || service != activeService) return;
            clearUnshownPeriodicReminderState(service);
            service.periodicReminderUsage.setIntervalMinutes(intervalMinutes);
            if (service.periodicReminderVisible.get()) service.periodicReminderUsage.markReminderVisible();
            service.persistReminderUsage(true);
            service.monitorRunnable.run();
        };
        if (handler == null || !handler.post(applyInterval)) {
            clearUnshownPeriodicReminderState(service);
            service.periodicReminderUsage.setIntervalMinutes(intervalMinutes);
            if (service.periodicReminderVisible.get()) service.periodicReminderUsage.markReminderVisible();
            service.persistReminderUsage(true);
        }
    }

    /** Reset the in-memory cadence and dismiss immediately when island settings change. */
    public static void onScreenTimeIslandSettingsChanged(Context context) {
        StudyModeFocusService service = activeService;
        if (service == null || !running) {
            if (context != null && !StudyModeManager.isScreenTimeIslandEnabled(context)) {
                ScreenTimeIslandOverlay preview = previewIslandOverlay;
                previewIslandOverlay = null;
                if (preview != null) preview.dismissImmediately();
            }
            return;
        }
        Runnable reset = () -> {
            if (service != activeService) return;
            service.islandUsage.resetInterval();
            service.islandDueElapsedMs = 0L;
            service.islandRequestInFlight.set(false);
            service.mainHandler.post(() -> {
                service.dismissScreenTimeIslandImmediately("settings_changed");
                if (!StudyModeManager.isScreenTimeIslandEnabled(context)) {
                    ScreenTimeIslandOverlay preview = previewIslandOverlay;
                    previewIslandOverlay = null;
                    if (preview != null) preview.dismissImmediately();
                }
            });
        };
        Handler handler = service.monitorHandler;
        if (handler == null || !handler.post(reset)) reset.run();
    }

    private static void clearUnshownPeriodicReminderState(StudyModeFocusService service) {
        if (service.periodicReminderVisible.get()) return;
        service.periodicReminderId = "";
        service.periodicReminderPackage = "";
        StudyModeManager.clearPendingPeriodicReminder(service);
    }

    public static void onStudyAppsChanged() {
        StudyModeFocusService service = activeService;
        if (service == null || !running) return;
        service.enqueueImmediateEvaluation();
        if (service.periodicReminderVisible.get()) {
            service.mainHandler.post(service::refreshPeriodicReminderStudyApps);
        }
    }

    /** Re-evaluate the current foreground app as soon as the strict policy changes. */
    public static void onProModeChanged() {
        StudyModeFocusService service = activeService;
        if (service == null || !running) return;
        service.mainHandler.post(() -> {
            if (!running || service != activeService) return;
            if (StudyModeManager.isProStrictModeActive(service)) {
                if (service.periodicReminderVisible.get()) {
                    service.dismissPeriodicReminder("pro_strict_mode_activated", false);
                }
                service.dismissScreenTimeIslandImmediately("pro_strict_mode_activated");
            }
            service.enqueueImmediateEvaluation();
        });
    }

    public static void requestImmediateEvaluation() {
        StudyModeFocusService service = activeService;
        if (service != null) service.enqueueImmediateEvaluation();
    }

    private void enqueueImmediateEvaluation() {
        Handler currentHandler = monitorHandler;
        if (!running || currentHandler == null
            || !immediateEvaluationQueued.compareAndSet(false, true)) return;

        long now = SystemClock.elapsedRealtime();
        long elapsed = now - lastImmediateEvaluationElapsedMs;
        long delay = elapsed >= MIN_IMMEDIATE_RECHECK_INTERVAL_MS
            ? 0L
            : MIN_IMMEDIATE_RECHECK_INTERVAL_MS - elapsed;
        if (!currentHandler.postDelayed(immediateEvaluationRunnable, delay)) {
            immediateEvaluationQueued.set(false);
        }
    }

    public static boolean hasOverlayFailure() {
        return running && overlayFailureForStatus;
    }

    public static boolean hasForegroundLookupFailure() {
        return running && foregroundLookupFailureForStatus;
    }

    private static volatile boolean overlayFailureForStatus = false;
    private static volatile boolean foregroundLookupFailureForStatus = false;
    private static final LruCache<String, android.graphics.drawable.Drawable.ConstantState> STUDY_ICON_CACHE =
        new LruCache<>(32);
    private static final LruCache<String, String> STUDY_LABEL_CACHE = new LruCache<>(64);

    public static void invalidatePackageCache(String packageName) {
        if (packageName == null || packageName.isEmpty()) return;
        STUDY_ICON_CACHE.remove(packageName);
        STUDY_LABEL_CACHE.remove(packageName);
    }

    private final Runnable monitorThreadRecoveryRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running || !StudyModeManager.shouldEnforceNow(StudyModeFocusService.this)) return;
            if (!ensureMonitorThreadStarted("foreground_service_retry")
                && running && StudyModeManager.shouldEnforceNow(StudyModeFocusService.this)) {
                mainHandler.postDelayed(this, MONITOR_THREAD_RETRY_MS);
            }
        }
    };

    private final Runnable notificationUpdateRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            updateOngoingNotification();
            mainHandler.postDelayed(this, 60_000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        starting = false;
        logStage("FOCUS_SERVICE_CREATED", "", "", "created", "service_on_create");
        stopping = false;
        boolean devicePolicyMode = StudyModeManager.isPolicyOwner(this);
        if (!StudyModeManager.shouldEnforceNow(this)) {
            dismissPreviewIslandImmediately("study_mode_inactive");
            StudyModeManager.setServiceState(this,
                StudyModeManager.isEnabled(this) ? "waiting_for_schedule" : "disabled");
            stopSelf();
            return;
        }
        if (!devicePolicyMode && (!StudyModeManager.hasForegroundMonitoringPermission(this)
            || !StudyModeManager.hasOverlayPermission(this))) {
            dismissPreviewIslandImmediately("permission_missing");
            StudyModeManager.setServiceState(this, "permission_required");
            logStage("PERMISSION_MISSING", "", "", "unavailable", "usage_access_or_overlay_permission");
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        if (!startForegroundSafely()) {
            dismissPreviewIslandImmediately("foreground_start_failed");
            stopSelf();
            return;
        }
        running = true;
        activeService = this;
        periodicReminderUsage.setIntervalMinutes(StudyModeManager.getReminderIntervalMinutes(this));
        periodicReminderUsage.restoreAccumulatedUsageMs(StudyModeManager.getReminderUsageMs(this));
        lastPersistedReminderUsageMs = periodicReminderUsage.getAccumulatedUsageMs();
        lastReminderUsagePersistElapsedMs = SystemClock.elapsedRealtime();
        String savedReminderId = StudyModeManager.getPendingPeriodicReminderId(this);
        String savedReminderPackage = StudyModeManager.getPendingPeriodicReminderPackage(this);
        if (!savedReminderId.isEmpty() && !savedReminderPackage.isEmpty()) {
            periodicReminderId = savedReminderId;
            periodicReminderPackage = savedReminderPackage;
            periodicReminderVisible.set(true);
            periodicReminderUsage.markReminderVisible();
        }
        overlayFailureForStatus = false;
        foregroundLookupFailureForStatus = false;
        if (!devicePolicyMode) StudyModeManager.setServiceState(this, "focus_shield_starting");
        refreshDiagnosticSessionId(true);
        logStage("SESSION_VALIDATED", "", "", "active", "foreground_service_started");
        mainHandler.postDelayed(notificationUpdateRunnable, 60_000L);

        // Device Owner suspension already blocks packages at the OS level. In that
        // mode this service only maintains the durable session notification/timer.
        if (!devicePolicyMode && !ensureMonitorThreadStarted("service_created")) {
            StudyModeManager.setServiceState(this, "monitoring_unavailable");
            mainHandler.postDelayed(monitorThreadRecoveryRunnable, MONITOR_THREAD_RETRY_MS);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!foregroundStarted || !StudyModeManager.shouldEnforceNow(this)) {
            dismissScreenTimeIslandImmediately("service_not_enforcing");
            dismissPreviewIslandImmediately("service_not_enforcing");
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        starting = false;
        stopping = false;
        refreshDiagnosticSessionId(true);
        if (intent == null) {
            logStage("SERVICE_RESTARTED_WITH_NULL_INTENT", "", "", "restoring", "sticky_service_restart");
        }
        if (StudyModeManager.isPolicyOwner(this)) {
            updateOngoingNotification();
            return START_STICKY;
        }
        if (!ensureMonitorThreadStarted(intent == null ? "sticky_restart" : "start_command")) {
            StudyModeManager.setServiceState(this, "monitoring_unavailable");
            mainHandler.removeCallbacks(monitorThreadRecoveryRunnable);
            mainHandler.postDelayed(monitorThreadRecoveryRunnable, MONITOR_THREAD_RETRY_MS);
            return START_STICKY;
        }
        Handler currentHandler = monitorHandler;
        if (currentHandler != null) {
            currentHandler.removeCallbacks(immediateEvaluationRunnable);
            immediateEvaluationQueued.set(false);
            scheduleMonitorCycle(0L, monitorGeneration);
        }
        return START_STICKY;
    }

    private boolean startForegroundSafely() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            PendingIntent content = launch == null ? null : PendingIntent.getActivity(
                this, 9529, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );
            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
            builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(StudyModeManager.getSessionNotificationTitle(this))
                .setContentText(StudyModeManager.getSessionNotificationText(this))
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true);
            if (content != null) builder.setContentIntent(content);
            Notification notification = builder.build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            foregroundStarted = true;
            return true;
        } catch (Exception error) {
            boolean startRestricted = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && "ForegroundServiceStartNotAllowedException".equals(error.getClass().getSimpleName());
            StudyModeManager.setServiceState(this,
                startRestricted ? "monitoring_unavailable" : "service_start_blocked");
            logStage(startRestricted ? "FOREGROUND_START_RESTRICTED" : "FOREGROUND_START_FAILED",
                "", "", "failed", error.getClass().getSimpleName());
            return false;
        }
    }

    private void updateOngoingNotification() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            PendingIntent content = launch == null ? null : PendingIntent.getActivity(
                this, 9529, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );
            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
            builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(StudyModeManager.getSessionNotificationTitle(this))
                .setContentText(StudyModeManager.getSessionNotificationText(this))
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true);
            if (content != null) builder.setContentIntent(content);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID, builder.build());
        } catch (Exception ignored) {
            // Notification refresh must not interrupt package restrictions/session expiry.
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "Study Mode Focus Shield", NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Ongoing notification while best-effort Focus Shield monitoring is active.");
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
    }

    private final Runnable monitorRunnable = new Runnable() {
        @Override
        public void run() {
            long monitorGenerationAtStart = monitorGeneration;
            if (!running || Thread.currentThread() != monitorThread) return;
            lastMonitorHeartbeatElapsedMs = SystemClock.elapsedRealtime();

            if (StudyModeManager.completeExpiredSession(StudyModeFocusService.this)) {
                StudyModeManager.reconcile(StudyModeFocusService.this);
            }
            if (!StudyModeManager.shouldEnforceNow(StudyModeFocusService.this)) {
                if (periodicReminderVisible.get()) mainHandler.post(() -> dismissPeriodicReminder("session_inactive", false));
                periodicReminderUsage.clear();
                StudyModeManager.clearReminderUsageMs(StudyModeFocusService.this);
                islandUsage.clear();
                islandDueElapsedMs = 0L;
                islandRequestInFlight.set(false);
                StudyModeManager.clearPendingPeriodicReminder(StudyModeFocusService.this);
                long invalidation = foregroundDecisionSequence.incrementAndGet();
                activeDiagnosticSessionId = "none";
                StudyModeManager.setServiceState(StudyModeFocusService.this,
                    StudyModeManager.isEnabled(StudyModeFocusService.this) ? "waiting_for_schedule" : "disabled");
                mainHandler.post(() -> {
                    if (monitorGenerationAtStart != monitorGeneration
                        || !running || invalidation != foregroundDecisionSequence.get()) return;
                    dismissScreenTimeIslandImmediately("study_mode_inactive");
                    dismissPreviewIslandImmediately("study_mode_inactive");
                    removeShield("session_inactive");
                    stopSelf();
                });
                return;
            }
            if (StudyModeManager.isPolicyOwner(StudyModeFocusService.this)) {
                periodicReminderUsage.pause();
                islandUsage.pause();
                persistReminderUsage(true);
                long invalidation = foregroundDecisionSequence.incrementAndGet();
                mainHandler.post(() -> {
                    if (monitorGenerationAtStart == monitorGeneration
                        && running && invalidation == foregroundDecisionSequence.get()) {
                        dismissScreenTimeIslandImmediately("policy_owner");
                        removeShield("device_policy_enforces_packages");
                    }
                });
                updateOngoingNotification();
                if (monitorHandler != null)  scheduleMonitorCycle(60_000L, monitorGenerationAtStart);
                return;
            }
            if (!StudyModeManager.hasForegroundMonitoringPermission(StudyModeFocusService.this)
                || !StudyModeManager.hasOverlayPermission(StudyModeFocusService.this)) {
                periodicReminderUsage.pause();
                islandUsage.pause();
                persistReminderUsage(true);
                long invalidation = foregroundDecisionSequence.incrementAndGet();
                if (!permissionUnavailableLogged) {
                    permissionUnavailableLogged = true;
                    resetForegroundResolution();
                    logStage("PERMISSION_MISSING", "", "", "unavailable", "usage_access_or_overlay_permission");
                }
                StudyModeManager.setServiceState(StudyModeFocusService.this, "permission_required");
                mainHandler.post(() -> {
                    if (monitorGenerationAtStart == monitorGeneration
                        && running && invalidation == foregroundDecisionSequence.get()) {
                        dismissScreenTimeIslandImmediately("overlay_permission_missing");
                        removeShield("permission_missing");
                    }
                });
                updateOngoingNotification();
                if (monitorHandler != null)  scheduleMonitorCycle(60_000L, monitorGenerationAtStart);
                return;
            }
            if (permissionUnavailableLogged) {
                permissionUnavailableLogged = false;
                resetForegroundResolution();
            }
            refreshDiagnosticSessionId(false);

            // UsageStats is the foreground source for ordinary personal devices.
            // It is event-driven: the service polls the event cursor, not the screen.
            PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
            KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (power == null || !power.isInteractive()
                || (keyguard != null && keyguard.isKeyguardLocked())) {
                periodicReminderUsage.pause();
                islandUsage.pause();
                persistReminderUsage(true);
                islandTrackedPackage = "";
                islandTrackedPackageSinceWallMs = 0L;
                long invalidation = foregroundDecisionSequence.incrementAndGet();
                resetForegroundResolution();
                mainHandler.post(() -> {
                    if (monitorGenerationAtStart == monitorGeneration
                        && running && invalidation == foregroundDecisionSequence.get()) {
                        dismissScreenTimeIslandImmediately("screen_not_interactive");
                        removeShield("screen_not_interactive");
                    }
                });
                if (monitorHandler != null)  scheduleMonitorCycle(POLL_INTERVAL_MS, monitorGenerationAtStart);
                return;
            }

            // UsageStatsManager is the standard foreground source. Advanced Accessibility
            // can add positive package evidence even when Android withholds a complete
            // interactive-window snapshot.
            boolean usageAccessAvailable = StudyModeManager.hasUsageAccess(StudyModeFocusService.this);
            String foreground = usageAccessAvailable ? getMostRecentlyResumedPackage() : null;
            String foregroundSource = usageAccessAvailable ? "usage_events" : "accessibility_window_or_event";

            String blockedWindowPackage = StudyModeWindowRegistry.findBlockedPackage(
                StudyModeFocusService.this, foreground);
            if (blockedWindowPackage != null) {
                foreground = blockedWindowPackage;
                boolean eventMatched = StudyModeWindowRegistry.wasRecentlyObservedAccessibilityEvent(blockedWindowPackage);
                foregroundSource = eventMatched ? "accessibility_event" : "accessible_interactive_window";
                logStage("BLOCKED_WINDOW_MATCHED", blockedWindowPackage, "", "matched", foregroundSource);
            } else if (StudyModeWindowRegistry.hasFreshSnapshot()
                && (!StudyModeManager.hasUsageAccess(StudyModeFocusService.this)
                    || hasForegroundLookupFailure())) {
                // A complete accessible-window snapshot with no selected blocked
                // package supersedes a stale UsageEvents package (or missing Usage Access).
                foreground = getPackageName();
            }

            // An unresolved foreground/window snapshot is not evidence that the
            // user is outside a blocked app. Preserve an already-visible shield.
            if (foreground == null || foreground.trim().isEmpty()) {
                periodicReminderUsage.pause();
                islandUsage.pause();
                islandTrackedPackage = "";
                islandTrackedPackageSinceWallMs = 0L;
                mainHandler.post(() -> dismissScreenTimeIslandImmediately("foreground_unresolved"));
                persistReminderUsage(true);
                if (!foregroundUnknownLogged) {
                    foregroundUnknownLogged = true;
                    logStage("FOREGROUND_PACKAGE_UNRESOLVED", "", "", "deferred", "no_usable_resume_event");
                }
                if (monitorHandler != null)  scheduleMonitorCycle(POLL_INTERVAL_MS, monitorGenerationAtStart);
                return;
            }
            foregroundUnknownLogged = false;

            if (!foreground.equals(lastLoggedForegroundPackage)) {
                resetPopupRetryStateForDifferentPackage(foreground);
                lastLoggedForegroundPackage = foreground;
                logStage("FOREGROUND_PACKAGE_RESOLVED", foreground, "", "success", foregroundSource);
            }

            boolean shouldShield = StudyModeManager.isPackageRestricted(
                StudyModeFocusService.this, foreground);

            // If the user enabled Advanced detection, an incomplete window list
            // cannot prove that no blocked split-screen pane exists. Keep any
            // current shield visible and report monitoring as unavailable.
            boolean accessibilityWindowCoverageRequired =
                StudyModeManager.isAccessibilityWindowMonitoringRequired(StudyModeFocusService.this);
            if (accessibilityWindowCoverageRequired && !StudyModeWindowRegistry.hasFreshSnapshot()
                && !shouldShield) {
                periodicReminderUsage.pause();
                islandUsage.pause();
                mainHandler.post(() -> dismissScreenTimeIslandImmediately("window_snapshot_unavailable"));
                persistReminderUsage(true);
                if (!windowSnapshotUnavailableLogged) {
                    windowSnapshotUnavailableLogged = true;
                    logStage("ACCESSIBILITY_WINDOW_SNAPSHOT_UNAVAILABLE", "", "", "deferred",
                        "stale_or_incomplete_interactive_window_snapshot");
                }
                if (monitorHandler != null)  scheduleMonitorCycle(POLL_INTERVAL_MS, monitorGenerationAtStart);
                return;
            }
            windowSnapshotUnavailableLogged = false;

            String activePackage = StudyModeWindowRegistry.findFocusedPackage(StudyModeFocusService.this, foreground);
            // StudyModeWindowRegistry deliberately returns null when Accessibility
            // is connected but its focused-window snapshot is incomplete. Do not
            // resurrect a cached UsageEvents package here: timer accounting must
            // pause until the current focused package is positively identified.
            boolean selectedStudyApp = activePackage != null
                && StudyModeManager.isSelectedStudyAppPackage(StudyModeFocusService.this, activePackage);
            boolean reminderEligible = !StudyModeManager.isProStrictModeActive(StudyModeFocusService.this)
                && !shouldShield && activePackage != null
                && !activePackage.equals(getPackageName())
                && !selectedStudyApp
                && !StudyModeManager.isPeriodicReminderExemptPackage(StudyModeFocusService.this, activePackage)
                && !periodicReminderVisible.get();
            long islandNowElapsedMs = SystemClock.elapsedRealtime();
            long islandNowWallMs = System.currentTimeMillis();
            String islandForegroundPackage = activePackage == null ? "" : activePackage;
            if (!islandForegroundPackage.equals(islandTrackedPackage)) {
                boolean previouslyTracked = !islandTrackedPackage.isEmpty();
                islandTrackedPackage = islandForegroundPackage;
                islandTrackedPackageSinceWallMs = islandForegroundPackage.isEmpty() ? 0L : islandNowWallMs;
                if (previouslyTracked) {
                    mainHandler.post(() -> {
                        ScreenTimeIslandOverlay current = screenTimeIslandOverlay;
                        if (current != null && !islandForegroundPackage.equals(current.getPackageName())) {
                            dismissScreenTimeIslandImmediately("foreground_package_changed");
                        }
                    });
                }
            }

            boolean islandEnabled = StudyModeManager.isScreenTimeIslandEnabled(StudyModeFocusService.this);
            boolean phoneCallActive = isPhoneCallActive();
            boolean islandEligible = islandEnabled && usageAccessAvailable
                && StudyModeManager.hasOverlayPermission(StudyModeFocusService.this)
                && !StudyModeManager.isProStrictModeActive(StudyModeFocusService.this)
                && !shouldShield && activePackage != null
                && !activePackage.equals(getPackageName())
                && !selectedStudyApp
                && !StudyModeManager.isPeriodicReminderExemptPackage(StudyModeFocusService.this, activePackage)
                && !periodicReminderVisible.get()
                && !phoneCallActive;
            boolean reminderDue = periodicReminderUsage.sample(
                activePackage, islandNowElapsedMs, reminderEligible,
                StudyModeManager.getReminderIntervalMinutes(StudyModeFocusService.this));
            persistReminderUsage(reminderDue);

            boolean islandDue = islandEnabled && islandUsage.sample(
                activePackage, islandNowElapsedMs, islandEligible,
                StudyModeManager.getScreenTimeIslandIntervalMinutes(StudyModeFocusService.this));
            if (!islandEnabled) {
                islandUsage.resetInterval();
                islandDueElapsedMs = 0L;
                islandRequestInFlight.set(false);
                if (screenTimeIslandOverlay != null) {
                    mainHandler.post(() -> dismissScreenTimeIslandImmediately("feature_disabled"));
                }
            } else if (islandDue && islandDueElapsedMs == 0L) {
                islandDueElapsedMs = islandNowElapsedMs;
            }

            boolean islandPopupConflict = periodicReminderVisible.get() || popupState != PopupState.IDLE;
            if (shouldShield) {
                islandUsage.resetInterval();
                islandDueElapsedMs = 0L;
                islandRequestInFlight.set(false);
            } else if (islandDue && islandPopupConflict && islandDueElapsedMs > 0L
                && islandNowElapsedMs - islandDueElapsedMs > 10_000L) {
                islandUsage.dismissReminder(true);
                islandDueElapsedMs = 0L;
                islandRequestInFlight.set(false);
                logStage("SCREEN_TIME_ISLAND_DROPPED", "", "", "dropped", "popup_conflict_timeout");
            }

            if (phoneCallActive && screenTimeIslandOverlay != null) {
                mainHandler.post(() -> dismissScreenTimeIslandImmediately("phone_call_active"));
            }
            boolean requestIslandSnapshot = islandDue && islandEligible && !shouldShield && !reminderDue
                && !islandPopupConflict && !phoneCallActive
                && islandRequestInFlight.compareAndSet(false, true);
            ScreenTimeIslandSnapshot islandSnapshot = null;
            if (requestIslandSnapshot) {
                islandSnapshot = queryTodayIslandSnapshot(StudyModeFocusService.this, activePackage,
                    islandNowWallMs, islandTrackedPackageSinceWallMs);
                if (islandSnapshot == null) {
                    islandRequestInFlight.set(false);
                    islandUsage.dismissReminder(true);
                    islandDueElapsedMs = 0L;
                    logStage("SCREEN_TIME_ISLAND_USAGE_UNAVAILABLE", "", "", "skipped",
                        "events_and_daily_stats_unavailable");
                    requestIslandSnapshot = false;
                }
            }
            final boolean requestScreenTimeIsland = requestIslandSnapshot;
            final ScreenTimeIslandSnapshot screenTimeIslandSnapshot = islandSnapshot;

            boolean decisionChanged = !foreground.equals(lastDecisionPackage)
                || shouldShield != lastDecisionShouldShield;
            if (decisionChanged) {
                lastDecisionPackage = foreground;
                lastDecisionShouldShield = shouldShield;
            }
            long decisionSequence = decisionChanged
                ? foregroundDecisionSequence.incrementAndGet()
                : foregroundDecisionSequence.get();

            if (shouldShield && !foreground.equals(lastLoggedBlockedPackage)) {
                lastLoggedBlockedPackage = foreground;
                logStage("BLOCKED_PACKAGE_DETECTED", foreground, "", "detected", foregroundSource);
                logStage("BLOCKED_LIST_MATCHED", foreground, "", "matched", "active_session_or_schedule");
            } else if (!shouldShield) {
                overlayFailureForStatus = false;
                if (lastLoggedBlockedPackage != null) {
                    logStage("BLOCKING_REEVALUATED", lastLoggedBlockedPackage, "", "not_required", "foreground_no_longer_blocked");
                    lastLoggedBlockedPackage = null;
                }
            }

            final String decisionPackage = foreground;
            final String reminderTargetPackage = activePackage;
            final boolean requestPeriodicReminder = reminderDue;
            final String requestId = shouldShield ? UUID.randomUUID().toString() : "";
            if (monitorGenerationAtStart != monitorGeneration) {
                if (requestScreenTimeIsland) islandRequestInFlight.set(false);
                return;
            }
            mainHandler.post(() -> {
                if (monitorGenerationAtStart != monitorGeneration || !running) {
                    if (requestScreenTimeIsland) islandRequestInFlight.set(false);
                    return;
                }
                if (decisionSequence != foregroundDecisionSequence.get()) {
                    if (requestScreenTimeIsland) islandRequestInFlight.set(false);
                    if (shouldShield) {
                        logStage("BLOCKING_REEVALUATED", decisionPackage, requestId, "superseded", "newer_foreground_decision");
                    }
                    return;
                }
                if (shouldShield) {
                    dismissScreenTimeIslandImmediately("shield_appeared");
                    if (periodicReminderVisible.get()) suspendPeriodicReminderForBlockedApp();
                    showShield(decisionPackage, requestId, decisionSequence);
                } else {
                    removeShield("foreground_not_blocked");
                    if (requestPeriodicReminder || periodicReminderUsage.isReminderPending()) {
                        showPeriodicReminder(reminderTargetPackage, decisionSequence);
                    } else if (periodicReminderVisible.get()
                        && (periodicReminderView == null || !periodicReminderView.isAttachedToWindow())) {
                        restorePeriodicReminderOverlay();
                    }
                    if (requestScreenTimeIsland && screenTimeIslandSnapshot != null) {
                        showScreenTimeIsland(screenTimeIslandSnapshot, decisionSequence);
                    }
                }
            });

            if (monitorHandler != null)  scheduleMonitorCycle(POLL_INTERVAL_MS, monitorGenerationAtStart);
        }
    };

    private static String buildStudyModeLearningDeepLink() {
        return new android.net.Uri.Builder()
            .scheme("mathmaster")
            .authority("learn")
            .build()
            .toString();
    }

    private boolean isPhoneCallActive() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audio == null) return false;
            int mode = audio.getMode();
            return mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION
                || mode == AudioManager.MODE_RINGTONE;
        } catch (RuntimeException unavailable) {
            return false;
        }
    }

    private void showScreenTimeIsland(ScreenTimeIslandSnapshot snapshot, long decisionSequence) {
        if (snapshot == null || !running || decisionSequence != foregroundDecisionSequence.get()
            || !StudyModeManager.shouldEnforceNow(this)
            || !StudyModeManager.isScreenTimeIslandEnabled(this)
            || StudyModeManager.isProStrictModeActive(this)
            || !StudyModeManager.hasUsageAccess(this) || !StudyModeManager.hasOverlayPermission(this)
            || shieldView != null || popupState != PopupState.IDLE || periodicReminderVisible.get()
            || !snapshot.packageName.equals(islandTrackedPackage) || isPhoneCallActive()) {
            islandRequestInFlight.set(false);
            if (periodicReminderVisible.get() || popupState != PopupState.IDLE) {
                if (islandDueElapsedMs > 0L
                    && SystemClock.elapsedRealtime() - islandDueElapsedMs > 10_000L) {
                    islandUsage.dismissReminder(true);
                    islandDueElapsedMs = 0L;
                    logStage("SCREEN_TIME_ISLAND_DROPPED", "", "", "dropped", "popup_conflict_timeout");
                }
            } else {
                islandUsage.dismissReminder(true);
                islandDueElapsedMs = 0L;
            }
            return;
        }

        final ScreenTimeIslandOverlay[] candidateReference = new ScreenTimeIslandOverlay[1];
        ScreenTimeIslandOverlay candidate = new ScreenTimeIslandOverlay(
            this, snapshot.packageName, snapshot.label, snapshot.icon,
            snapshot.totalMillis, snapshot.hourlyMillis, snapshot.accent,
            buildStudyModeLearningDeepLink(),
            () -> {
                if (screenTimeIslandOverlay == candidateReference[0]) {
                    screenTimeIslandOverlay = null;
                    islandUsage.dismissReminder(true);
                    islandDueElapsedMs = 0L;
                    islandRequestInFlight.set(false);
                }
            });
        candidateReference[0] = candidate;
        screenTimeIslandOverlay = candidate;
        boolean shown = candidate.show();
        if (!shown) {
            screenTimeIslandOverlay = null;
            islandUsage.dismissReminder(true);
            islandDueElapsedMs = 0L;
            islandRequestInFlight.set(false);
            logStage("SCREEN_TIME_ISLAND_LAUNCH_FAILED", "", "", "failed", "window_manager_add_view");
            return;
        }
        islandUsage.markReminderVisible();
        islandDueElapsedMs = 0L;
        islandRequestInFlight.set(false);
        logStage("SCREEN_TIME_ISLAND_VISIBLE", "", "", "visible", "eligible_usage_interval_elapsed");
    }

    private void dismissScreenTimeIslandImmediately(String reason) {
        ScreenTimeIslandOverlay current = screenTimeIslandOverlay;
        screenTimeIslandOverlay = null;
        if (current != null) current.dismissImmediately();
        islandUsage.resetInterval();
        islandDueElapsedMs = 0L;
        islandRequestInFlight.set(false);
    }

    private static void dismissPreviewIslandImmediately(String reason) {
        ScreenTimeIslandOverlay preview = previewIslandOverlay;
        previewIslandOverlay = null;
        if (preview != null) preview.dismissImmediately();
    }

    private void dismissVisibleScreenTimeIslandImmediately(String reason) {
        ScreenTimeIslandOverlay current = screenTimeIslandOverlay;
        if (current == null) return;
        screenTimeIslandOverlay = null;
        current.dismissImmediately();
        islandUsage.resetInterval();
        islandDueElapsedMs = 0L;
        islandRequestInFlight.set(false);
    }

    private static final class ScreenTimeIslandSnapshot {
        final String packageName;
        final String label;
        final android.graphics.drawable.Drawable icon;
        final long totalMillis;
        final long[] hourlyMillis;
        final int accent;

        ScreenTimeIslandSnapshot(String packageName, String label,
                                 android.graphics.drawable.Drawable icon, long totalMillis,
                                 long[] hourlyMillis, int accent) {
            this.packageName = packageName;
            this.label = label;
            this.icon = icon;
            this.totalMillis = Math.max(0L, totalMillis);
            this.hourlyMillis = hourlyMillis == null ? new long[24] : hourlyMillis.clone();
            this.accent = accent;
        }
    }

    private static ScreenTimeIslandSnapshot queryTodayIslandSnapshot(
        Context context, String packageName, long nowWallMs, long liveSessionStartWallMs) {
        if (context == null || packageName == null || packageName.isEmpty()
            || !StudyModeManager.hasUsageAccess(context)) return null;
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(nowWallMs);
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        long dayStartMs = today.getTimeInMillis();
        Calendar eventsStart = (Calendar) today.clone();
        eventsStart.add(Calendar.DAY_OF_YEAR, -1);
        UsageStatsManager usageManager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usageManager == null) return null;

        ArrayList<StudyModeDayUsage.Event> events = new ArrayList<>();
        int mappedEvents = 0;
        try {
            UsageEvents stream = usageManager.queryEvents(eventsStart.getTimeInMillis(), nowWallMs);
            if (stream != null) {
                UsageEvents.Event event = new UsageEvents.Event();
                while (stream.hasNextEvent()) {
                    stream.getNextEvent(event);
                    int rawType = event.getEventType();
                    int mappedType = -1;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        if (rawType == UsageEvents.Event.ACTIVITY_RESUMED) mappedType = StudyModeDayUsage.ACTIVITY_RESUMED;
                        else if (rawType == UsageEvents.Event.ACTIVITY_PAUSED) mappedType = StudyModeDayUsage.ACTIVITY_PAUSED;
                    } else {
                        if (rawType == UsageEvents.Event.MOVE_TO_FOREGROUND) mappedType = StudyModeDayUsage.MOVE_TO_FOREGROUND;
                        else if (rawType == UsageEvents.Event.MOVE_TO_BACKGROUND) mappedType = StudyModeDayUsage.MOVE_TO_BACKGROUND;
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        if (rawType == UsageEvents.Event.SCREEN_NON_INTERACTIVE) mappedType = StudyModeDayUsage.SCREEN_NON_INTERACTIVE;
                        else if (rawType == UsageEvents.Event.KEYGUARD_SHOWN) mappedType = StudyModeDayUsage.KEYGUARD_SHOWN;
                        else if (rawType == UsageEvents.Event.DEVICE_SHUTDOWN) mappedType = StudyModeDayUsage.DEVICE_SHUTDOWN;
                    }
                    if (mappedType >= 0) {
                        events.add(new StudyModeDayUsage.Event(event.getTimeStamp(),
                            event.getPackageName(), event.getClassName(), mappedType));
                        mappedEvents++;
                    }
                }
            }
        } catch (RuntimeException eventsUnavailable) {
            events.clear();
            mappedEvents = 0;
        }

        long total = 0L;
        long[] hourly = new long[24];
        if (mappedEvents > 0) {
            StudyModeDayUsage.Result result = StudyModeDayUsage.aggregate(
                dayStartMs, nowWallMs, TimeZone.getDefault(), events);
            if (!result.isPackageActiveAtEnd(packageName)
                && liveSessionStartWallMs > 0L && liveSessionStartWallMs <= nowWallMs) {
                events.add(new StudyModeDayUsage.Event(
                    Math.max(dayStartMs, liveSessionStartWallMs),
                    packageName, "__monitor_live_session__", StudyModeDayUsage.ACTIVITY_RESUMED));
                result = StudyModeDayUsage.aggregate(
                    dayStartMs, nowWallMs, TimeZone.getDefault(), events);
            }
            total = result.totalMillis(packageName);
            hourly = result.hourlyMillis(packageName);
        } else {
            try {
                List<UsageStats> daily = usageManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, dayStartMs, nowWallMs);
            long live = liveSessionStartWallMs > 0L
                ? Math.max(0L, nowWallMs - Math.max(dayStartMs, liveSessionStartWallMs)) : 0L;
            boolean found = false;
            if (daily != null) {
                for (UsageStats usage : daily) {
                    if (usage == null || !packageName.equals(usage.getPackageName())) continue;
                    found = true;
                    total = saturatingAdd(total, Math.max(0L, usage.getTotalTimeInForeground()));
                }
            }
            if (!found && live <= 0L) return null;
            total = Math.min(Math.max(0L, nowWallMs - dayStartMs), saturatingAdd(total, live));
            Calendar localNow = Calendar.getInstance();
            localNow.setTimeInMillis(nowWallMs);
            hourly[localNow.get(Calendar.HOUR_OF_DAY)] = total;
            } catch (RuntimeException statsUnavailable) {
                return null;
            }
        }

        String label = getIslandAppLabel(context, packageName);
        android.graphics.drawable.Drawable icon = getIslandAppIcon(context, packageName);
        String theme = context.getSharedPreferences("math_master_study_mode", Context.MODE_PRIVATE)
            .getString("popupTheme", "arctic-blue");
        return new ScreenTimeIslandSnapshot(packageName, label, icon, total, hourly,
            ScreenTimeIslandPainter.accentForTheme(theme));
    }

    private static long saturatingAdd(long left, long right) {
        return right > 0L && left > Long.MAX_VALUE - right ? Long.MAX_VALUE : left + right;
    }

    private static String getIslandAppLabel(Context context, String packageName) {
        String cached = STUDY_LABEL_CACHE.get(packageName);
        if (cached != null) return cached;
        try {
            android.content.pm.PackageManager manager = context.getPackageManager();
            android.content.pm.ApplicationInfo info = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? manager.getApplicationInfo(packageName, android.content.pm.PackageManager.ApplicationInfoFlags.of(0L))
                : manager.getApplicationInfo(packageName, 0);
            CharSequence label = manager.getApplicationLabel(info);
            String value = label == null || label.length() == 0 ? packageName : label.toString();
            STUDY_LABEL_CACHE.put(packageName, value);
            return value;
        } catch (Exception ignored) {
            return packageName;
        }
    }

    private static android.graphics.drawable.Drawable getIslandAppIcon(Context context, String packageName) {
        android.graphics.drawable.Drawable.ConstantState cached = STUDY_ICON_CACHE.get(packageName);
        if (cached != null) return cached.newDrawable(context.getResources()).mutate();
        try {
            android.graphics.drawable.Drawable drawable = context.getPackageManager().getApplicationIcon(packageName);
            android.graphics.drawable.Drawable.ConstantState state = drawable.getConstantState();
            if (state != null) STUDY_ICON_CACHE.put(packageName, state);
            return drawable;
        } catch (Exception ignored) {
            return null;
        }
    }

    public interface ScreenTimeIslandPreviewCallback {
        void onResult(boolean shown);
    }

    public static void previewScreenTimeIsland(Context context, ScreenTimeIslandPreviewCallback callback) {
        if (context == null || !StudyModeManager.hasOverlayPermission(context)) {
            if (callback != null) callback.onResult(false);
            return;
        }
        try {
            AppUsageAnalyticsPlugin.executeUsageWork(() -> {
                long now = System.currentTimeMillis();
                ScreenTimeIslandSnapshot snapshot = queryTodayIslandSnapshot(
                    context.getApplicationContext(), context.getPackageName(), now, now - 1000L);
                if (snapshot == null) {
                    String packageName = context.getPackageName();
                    snapshot = new ScreenTimeIslandSnapshot(packageName,
                        getIslandAppLabel(context, packageName), getIslandAppIcon(context, packageName),
                        0L, new long[24], ScreenTimeIslandPainter.accentForTheme(
                            context.getSharedPreferences("math_master_study_mode", Context.MODE_PRIVATE)
                                .getString("popupTheme", "arctic-blue")));
                }
                final ScreenTimeIslandSnapshot renderSnapshot = snapshot;
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (!StudyModeManager.hasOverlayPermission(context)) {
                        if (callback != null) callback.onResult(false);
                        return;
                    }
                    ScreenTimeIslandOverlay existing = previewIslandOverlay;
                    if (existing != null) existing.dismissImmediately();
                    StudyModeFocusService service = activeService;
                    if (service != null && service.screenTimeIslandOverlay != null) {
                        service.dismissScreenTimeIslandImmediately("preview_requested");
                    }
                    final ScreenTimeIslandOverlay[] candidateReference = new ScreenTimeIslandOverlay[1];
                    ScreenTimeIslandOverlay candidate = new ScreenTimeIslandOverlay(
                        context, renderSnapshot.packageName, renderSnapshot.label, renderSnapshot.icon,
                        renderSnapshot.totalMillis, renderSnapshot.hourlyMillis, renderSnapshot.accent,
                        buildStudyModeLearningDeepLink(), () -> {
                            if (previewIslandOverlay == candidateReference[0]) previewIslandOverlay = null;
                        });
                    candidateReference[0] = candidate;
                    previewIslandOverlay = candidate;
                    boolean shown = candidate.show();
                    if (!shown) previewIslandOverlay = null;
                    if (callback != null) callback.onResult(shown);
                });
            });
        } catch (RuntimeException rejected) {
            new Handler(Looper.getMainLooper()).post(() -> {
                if (callback != null) callback.onResult(false);
            });
        }
    }

    private void runImmediateEvaluation() {
        immediateEvaluationQueued.set(false);
        Handler currentHandler = monitorHandler;
        if (!running || currentHandler == null || Thread.currentThread() != monitorThread) return;
        lastImmediateEvaluationElapsedMs = SystemClock.elapsedRealtime();
        currentHandler.removeCallbacks(monitorRunnable);
        monitorRunnable.run();
    }

    private void resetForegroundResolution() {
        periodicReminderUsage.pause();
        lastForegroundPackage = null;
        lastDecisionPackage = null;
        lastDecisionShouldShield = false;
        lastUsageEventScanTimeMs = 0L;
        lastFullLookupElapsedMs = 0L;
        hasResolvedForegroundOnce = false;
        lastLoggedForegroundPackage = null;
        lastLoggedBlockedPackage = null;
        foregroundUnknownLogged = false;
        foregroundLookupFailureLogged = false;
        windowSnapshotUnavailableLogged = false;
        resetPopupRetryState();
    }

    private synchronized void resetPopupRetryState() {
        failedPopupPackage = "";
        failedPopupAttempts = 0;
        nextPopupRetryElapsedMs = 0L;
    }

    private synchronized void resetPopupRetryStateForDifferentPackage(String packageName) {
        if (!packageName.equals(failedPopupPackage)) resetPopupRetryState();
    }

    private synchronized boolean shouldDeferPopupLaunch(String packageName, String requestId) {
        if (!packageName.equals(failedPopupPackage)) return false;
        if (SystemClock.elapsedRealtime() < nextPopupRetryElapsedMs) return true;

        // Three failures pause rapid retries, not blocking itself. Re-arm a slow
        // recovery attempt for the same package so a transient overlay/OEM failure
        // cannot leave that package unshielded until the user switches apps.
        if (failedPopupAttempts >= MAX_POPUP_FAILURES_PER_FOREGROUND) {
            failedPopupAttempts = 0;
            nextPopupRetryElapsedMs = 0L;
            logStage("POPUP_RETRY_CYCLE_REARMED", packageName, requestId,
                "retrying", "recovery_backoff_elapsed");
        }
        return false;
    }

    private synchronized void recordPopupLaunchFailure(String packageName) {
        if (!packageName.equals(failedPopupPackage)) {
            failedPopupPackage = packageName;
            failedPopupAttempts = 0;
        }
        failedPopupAttempts++;
        if (failedPopupAttempts == 1) {
            nextPopupRetryElapsedMs = SystemClock.elapsedRealtime() + POPUP_RETRY_FIRST_BACKOFF_MS;
        } else if (failedPopupAttempts == 2) {
            nextPopupRetryElapsedMs = SystemClock.elapsedRealtime() + POPUP_RETRY_SECOND_BACKOFF_MS;
        } else {
            nextPopupRetryElapsedMs = SystemClock.elapsedRealtime() + POPUP_RETRY_RECOVERY_BACKOFF_MS;
        }
    }

    private void refreshDiagnosticSessionId(boolean force) {
        long now = SystemClock.elapsedRealtime();
        if (!force && now - lastDiagnosticSessionRefreshElapsedMs < 15_000L) return;
        lastDiagnosticSessionRefreshElapsedMs = now;
        try {
            activeDiagnosticSessionId = StudyModeManager.getActiveSessionId(this);
        } catch (Exception ignored) {
            activeDiagnosticSessionId = "unavailable";
        }
    }

    private String getMostRecentlyResumedPackage() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return lastForegroundPackage;
        UsageStatsManager usage = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (usage == null) {
            foregroundLookupFailureForStatus = true;
            if (!foregroundLookupFailureLogged) {
                foregroundLookupFailureLogged = true;
                logStage("FOREGROUND_LOOKUP_FAILED", "", "", "unavailable", "usage_stats_manager_null");
            }
            return lastForegroundPackage;
        }

        long now = System.currentTimeMillis();
        long elapsedNow = SystemClock.elapsedRealtime();
        if (lastUsageEventScanTimeMs > now) {
            // A user/system clock adjustment invalidates the wall-clock query cursor
            // and any popup request that was built from the previous foreground state.
            foregroundDecisionSequence.incrementAndGet();
            resetForegroundResolution();
        }

        boolean retryWideLookup = !hasResolvedForegroundOnce
            && (lastFullLookupElapsedMs == 0L
                || elapsedNow - lastFullLookupElapsedMs >= EMPTY_INITIAL_LOOKUP_RETRY_MS);
        long queryFrom;
        if (retryWideLookup) {
            queryFrom = Math.max(0L, now - INITIAL_EVENT_LOOKBACK_MS);
            lastFullLookupElapsedMs = elapsedNow;
        } else if (!hasResolvedForegroundOnce) {
            // An empty first stream must not collapse the recovery window to only
            // the overlap. Keep checking a recent bounded window until a valid
            // foreground package has actually been resolved.
            queryFrom = Math.max(0L, now - EMPTY_INITIAL_LOOKUP_FALLBACK_MS);
        } else if (lastUsageEventScanTimeMs > 0L) {
            queryFrom = Math.max(0L, lastUsageEventScanTimeMs - EVENT_QUERY_OVERLAP_MS);
        } else {
            queryFrom = Math.max(0L, now - EMPTY_INITIAL_LOOKUP_FALLBACK_MS);
        }

        UsageEvents events;
        try {
            events = usage.queryEvents(queryFrom, now);
        } catch (SecurityException denied) {
            foregroundLookupFailureForStatus = true;
            StudyModeManager.setServiceState(this, "permission_required");
            if (!permissionUnavailableLogged) {
                permissionUnavailableLogged = true;
                logStage("PERMISSION_MISSING", "", "", "denied", "usage_stats_security_exception");
            }
            return lastForegroundPackage;
        } catch (RuntimeException error) {
            foregroundLookupFailureForStatus = true;
            if (!foregroundLookupFailureLogged) {
                foregroundLookupFailureLogged = true;
                logStage("FOREGROUND_LOOKUP_FAILED", "", "", "failed", error.getClass().getSimpleName());
            }
            return lastForegroundPackage;
        }
        if (events == null) {
            foregroundLookupFailureForStatus = true;
            if (!foregroundLookupFailureLogged) {
                foregroundLookupFailureLogged = true;
                logStage("FOREGROUND_LOOKUP_FAILED", "", "", "empty", "usage_events_null");
            }
            return lastForegroundPackage;
        }
        foregroundLookupFailureLogged = false;
        foregroundLookupFailureForStatus = false;

        String latest = null;
        long latestTimestamp = -1L;
        UsageEvents.Event event = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            int type = event.getEventType();
            boolean resumed = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? type == UsageEvents.Event.ACTIVITY_RESUMED
                : type == UsageEvents.Event.MOVE_TO_FOREGROUND;
            if (!resumed) continue;

            String packageName = event.getPackageName();
            long eventTimestamp = event.getTimeStamp();
            if (packageName != null && !packageName.isEmpty() && eventTimestamp >= latestTimestamp) {
                latest = packageName;
                latestTimestamp = eventTimestamp;
            }
        }

        // Advance the cursor only after queryEvents returned a valid event stream.
        // Keep the last confirmed package when there is no newer RESUMED event.
        lastUsageEventScanTimeMs = now;
        if (latest != null) {
            lastForegroundPackage = latest;
            hasResolvedForegroundOnce = true;
        }
        return lastForegroundPackage;
    }

    private void showShield(String packageName, String requestId, long decisionSequence) {
        if (packageName == null || packageName.isEmpty()) return;
        dismissScreenTimeIslandImmediately("shield_appeared");
        if (!running || decisionSequence != foregroundDecisionSequence.get()) {
            logStage("BLOCKING_REEVALUATED", packageName, requestId, "superseded", "decision_changed_before_popup");
            return;
        }

        if (shouldDeferPopupLaunch(packageName, requestId)) return;

        if (packageName.equals(shieldedPackage)) {
            if (popupState == PopupState.VISIBLE && isShieldViewVisible(shieldView)) return;
            if (popupState == PopupState.LAUNCH_PENDING) return;
            if (shieldView != null) {
                logStage("POPUP_VISIBILITY_LOST", packageName, activeShieldRequestId,
                    "recovery_required", "view_detached_or_hidden");
            }
        }
        if (shieldView != null || popupState != PopupState.IDLE) {
            removeShield("replacing_or_recovering");
            // Never stack a replacement window on top of a view whose removal
            // failed. Preserve the old reference/state and wait for recovery.
            if (shieldView != null) {
                logStage("POPUP_LAUNCH_FAILED", packageName, activeShieldRequestId,
                    "deferred", "previous_overlay_removal_failed");
                return;
            }
        }

        popupState = PopupState.LAUNCH_PENDING;
        logStage("POPUP_REQUESTED", packageName, requestId, "requested", "window_manager_overlay");
        StudyModeManager.setServiceState(this, "blocking_pending");
        activeShieldRequestId = requestId == null || requestId.isEmpty()
            ? UUID.randomUUID().toString() : requestId;
        logStage("BLOCKING_DECISION_CREATED", packageName, activeShieldRequestId, "required", "active_session_and_blocked_package");
        logStage("POPUP_REQUEST_QUEUED", packageName, activeShieldRequestId, "queued", "main_thread_window_request");
        logStage("POPUP_LAUNCH_ATTEMPTED", packageName, activeShieldRequestId, "attempted", "window_manager_add_view");

        try {
            if (windowManager == null) {
                windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            }
            if (windowManager == null) throw new IllegalStateException("WindowManager unavailable");

            android.view.View candidate = buildShieldView(packageName);
            if (!running || decisionSequence != foregroundDecisionSequence.get()) {
                logStage("BLOCKING_REEVALUATED", packageName, activeShieldRequestId,
                    "superseded", "decision_changed_during_popup_build");
                removeShield("stale_request_before_window_add");
                return;
            }
            shieldView = candidate;
            shieldedPackage = packageName;

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.CENTER;
            params.setTitle("Math Master Study Mode");
            windowManager.addView(candidate, params);

            AnimationSet entrance = new AnimationSet(true);
            AlphaAnimation fade = new AlphaAnimation(0.0f, 1.0f);
            TranslateAnimation rise = new TranslateAnimation(0f, 0f, dp(9), 0f);
            entrance.addAnimation(fade);
            entrance.addAnimation(rise);
            entrance.setDuration(220L);
            candidate.startAnimation(entrance);
            updateRemainingTime();
            mainHandler.removeCallbacks(countdownRunnable);
            mainHandler.postDelayed(countdownRunnable, 1000L);
            logStage("POPUP_LAUNCH_ACCEPTED", packageName, activeShieldRequestId, "window_added", "awaiting_attachment_visibility_check");

            final String verifiedRequestId = activeShieldRequestId;
            // Verify on the next view frame, after WindowManager has had an
            // opportunity to attach and traverse the newly-added overlay.
            candidate.postOnAnimation(() -> verifyShieldVisibility(
                candidate, packageName, verifiedRequestId, decisionSequence
            ));
        } catch (Exception error) {
            popupState = PopupState.RECOVERY_REQUIRED;
            overlayFailureForStatus = true;
            StudyModeManager.setServiceState(this, "overlay_failed");
            recordPopupLaunchFailure(packageName);
            logStage("POPUP_LAUNCH_FAILED", packageName, activeShieldRequestId,
                "failed", error.getClass().getSimpleName());
            removeShield("launch_failed");
        }
    }

    private boolean isShieldViewVisible(android.view.View view) {
        return view != null
            && view.isAttachedToWindow()
            && view.getWindowToken() != null
            && view.getVisibility() == android.view.View.VISIBLE
            && view.getWindowVisibility() == android.view.View.VISIBLE
            && view.isShown();
    }

    private void verifyShieldVisibility(
        android.view.View candidate,
        String packageName,
        String requestId,
        long decisionSequence
    ) {
        if (shieldView != candidate
            || !packageName.equals(shieldedPackage)
            || !requestId.equals(activeShieldRequestId)) return;

        if (!running || decisionSequence != foregroundDecisionSequence.get()) {
            logStage("BLOCKING_REEVALUATED", packageName, requestId,
                "superseded", "decision_changed_before_visibility_check");
            removeShield("stale_request_before_visibility_check");
            return;
        }

        if (isShieldViewVisible(candidate)) {
            popupState = PopupState.VISIBLE;
            overlayFailureForStatus = false;
            resetPopupRetryState();
            StudyModeManager.setServiceState(this, "blocking_active");
            logStage("POPUP_VISIBLE", packageName, requestId, "visible", "attached_shown_and_window_token_present");
            logStage("POPUP_WINDOW_VISIBLE", packageName, requestId, "visible", "verified_window_attachment_and_visibility");
            return;
        }

        popupState = PopupState.RECOVERY_REQUIRED;
        overlayFailureForStatus = true;
        recordPopupLaunchFailure(packageName);
        StudyModeManager.setServiceState(this, "overlay_failed");
        logStage("POPUP_VISIBILITY_FAILED", packageName, requestId,
            "not_visible", "window_not_attached_or_hidden");
        logStage("POPUP_LAUNCH_FAILED", packageName, requestId,
            "not_visible", "window_not_attached_or_hidden");
        removeShield("window_not_visible");
    }

    private WindowManager.LayoutParams periodicReminderWindowParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        params.setTitle("Math Master Periodic Study Reminder");
        return params;
    }

    private void showPeriodicReminder(String packageName, long decisionSequence) {
        dismissVisibleScreenTimeIslandImmediately("periodic_popup_priority");
        if (packageName == null || packageName.isEmpty()
            || StudyModeManager.isProStrictModeActive(this)
            || !periodicReminderVisible.compareAndSet(false, true)) return;
        if (!running || decisionSequence != foregroundDecisionSequence.get()
            || !StudyModeManager.shouldEnforceNow(this)
            || StudyModeManager.isProStrictModeActive(this)
            || StudyModeManager.isPackageSelected(this, packageName)
            || StudyModeManager.isSelectedStudyAppPackage(this, packageName)
            || StudyModeManager.isPeriodicReminderExemptPackage(this, packageName)
            || !StudyModeManager.hasOverlayPermission(this)
            || shieldView != null || popupState != PopupState.IDLE) {
            periodicReminderVisible.set(false);
            return;
        }

        String reminderId = periodicReminderId;
        if (reminderId.isEmpty()) reminderId = StudyModeManager.getPendingPeriodicReminderId(this);
        if (reminderId.isEmpty()) reminderId = UUID.randomUUID().toString();
        periodicReminderId = reminderId;
        periodicReminderPackage = packageName;
        StudyModeManager.savePendingPeriodicReminder(this, reminderId, packageName);

        try {
            if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) throw new IllegalStateException("WindowManager unavailable");
            android.view.View candidate = buildPeriodicReminderView(packageName);
            if (!running || decisionSequence != foregroundDecisionSequence.get()
                || !StudyModeManager.shouldEnforceNow(this)
                || StudyModeManager.isPackageSelected(this, packageName)
                || StudyModeManager.isSelectedStudyAppPackage(this, packageName)
                || shieldView != null || popupState != PopupState.IDLE) {
                periodicReminderVisible.set(false);
                periodicReminderId = "";
                periodicReminderPackage = "";
                StudyModeManager.clearPendingPeriodicReminder(this);
                return;
            }
            windowManager.addView(candidate, periodicReminderWindowParams());
            periodicReminderView = candidate;
            periodicReminderUsage.markReminderVisible();
            persistReminderUsage(true);
            logStage("PERIODIC_REMINDER_VISIBLE", packageName, reminderId,
                "visible", "eligible_usage_interval_elapsed");
        } catch (Exception error) {
            periodicReminderVisible.set(false);
            periodicReminderView = null;
            periodicReminderStudyAppsSection = null;
            periodicReminderAppsError = null;
            logStage("PERIODIC_REMINDER_LAUNCH_FAILED", packageName, reminderId,
                "failed", error.getClass().getSimpleName());
        }
    }

    private void restorePeriodicReminderOverlay() {
        if (!running || !StudyModeManager.shouldEnforceNow(this)
            || !StudyModeManager.hasOverlayPermission(this) || !periodicReminderVisible.get()
            || shieldView != null || popupState != PopupState.IDLE) return;
        if (periodicReminderView != null && periodicReminderView.isAttachedToWindow()) return;
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        String reminderId = periodicReminderId;
        String packageName = periodicReminderPackage;
        if (reminderId.isEmpty()) reminderId = StudyModeManager.getPendingPeriodicReminderId(this);
        if (packageName.isEmpty()) packageName = StudyModeManager.getPendingPeriodicReminderPackage(this);
        if (reminderId.isEmpty() || packageName.isEmpty()) {
            periodicReminderVisible.set(false);
            periodicReminderUsage.restoreAccumulatedUsageMs(
                StudyModeManager.getReminderIntervalMinutes(this) * 60_000L);
            return;
        }

        try {
            android.view.View candidate = periodicReminderView;
            if (candidate == null) candidate = buildPeriodicReminderView(packageName);
            windowManager.addView(candidate, periodicReminderWindowParams());
            periodicReminderView = candidate;
            periodicReminderId = reminderId;
            periodicReminderPackage = packageName;
            periodicReminderUsage.markReminderVisible();
            persistReminderUsage(true);
            logStage("PERIODIC_REMINDER_RESTORED", packageName, reminderId,
                "visible", "pending_reminder_recovered");
        } catch (Exception error) {
            periodicReminderVisible.set(false);
            periodicReminderUsage.restoreAccumulatedUsageMs(
                StudyModeManager.getReminderIntervalMinutes(this) * 60_000L);
            logStage("PERIODIC_REMINDER_RESTORE_FAILED", packageName, reminderId,
                "retry_pending", error.getClass().getSimpleName());
        }
    }

    private android.view.View buildPeriodicReminderView(String packageName) {
        PopupPalette palette = getPopupPalette();
        FrameLayout root = new FrameLayout(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent event) {
                if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_BACK) return true;
                return super.dispatchKeyEvent(event);
            }
        };
        root.setBackgroundColor(palette.scrim);
        root.setClickable(true);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setContentDescription("Math Master Study Mode periodic reminder");
        ScrollView outerScroll = new ScrollView(this);
        outerScroll.setFillViewport(true);
        outerScroll.setClipToPadding(false);
        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.VERTICAL);
        stage.setGravity(Gravity.CENTER);
        stage.setPadding(dp(16), dp(14), dp(16), dp(14));
        outerScroll.addView(stage, new ScrollView.LayoutParams(-1, -2));
        root.addView(outerScroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(20), dp(18), dp(20), dp(16));
        panel.setBackground(roundedGradient(palette.panelTop, palette.panelBottom, palette.border, dp(24)));
        panel.setElevation(dp(18));
        int availableWidth = Math.max(dp(240), getResources().getDisplayMetrics().widthPixels - dp(48));
        int panelWidth = Math.min(availableWidth, dp(420));
        stage.addView(panel, new LinearLayout.LayoutParams(panelWidth, -2));

        LinearLayout activePill = new LinearLayout(this);
        activePill.setGravity(Gravity.CENTER);
        activePill.setOrientation(LinearLayout.HORIZONTAL);
        activePill.setPadding(dp(10), dp(5), dp(10), dp(5));
        activePill.setBackground(rounded(palette.pill, palette.border, dp(30)));
        activePill.addView(popupText("●", 9, palette.accent, Typeface.BOLD, Gravity.CENTER), wrapWrap());
        TextView activeLabel = popupText("STUDY MODE ACTIVE", 10, palette.secondaryText, Typeface.BOLD, Gravity.CENTER);
        LinearLayout.LayoutParams activeLabelParams = wrapWrap();
        activeLabelParams.leftMargin = dp(7);
        activePill.addView(activeLabel, activeLabelParams);
        panel.addView(activePill, wrapWrap());
        addGap(panel, 10);

        ImageView icon = new ImageView(this);
        icon.setImageResource(android.R.drawable.ic_dialog_info);
        icon.setColorFilter(palette.accent);
        panel.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));
        addGap(panel, 6);
        panel.addView(popupText("Stay Focused!", 21, palette.text, Typeface.BOLD, Gravity.CENTER), matchWrap());
        TextView appName = popupText(getStudyAppLabel(packageName), 13, palette.accent, Typeface.BOLD, Gravity.CENTER);
        appName.setMaxLines(1);
        appName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams appParams = matchWrap();
        appParams.topMargin = dp(4);
        panel.addView(appName, appParams);

        TextView description = popupText(
            "Take a moment to refocus, then choose a Study App or continue.",
            12, palette.secondaryText, Typeface.NORMAL, Gravity.CENTER);
        description.setLineSpacing(dp(2), 1.0f);
        LinearLayout.LayoutParams descriptionParams = matchWrap();
        descriptionParams.topMargin = dp(5);
        panel.addView(description, descriptionParams);

        periodicReminderStudyAppsSection = new LinearLayout(this);
        periodicReminderStudyAppsSection.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams studySectionParams = matchWrap();
        studySectionParams.topMargin = dp(12);
        panel.addView(periodicReminderStudyAppsSection, studySectionParams);
        refreshPeriodicReminderStudyApps();

        addGap(panel, 12);
        TextView continueAnyway = popupText("Continue Anyway", 13, Color.WHITE, Typeface.BOLD, Gravity.CENTER);
        continueAnyway.setMinHeight(dp(48));
        continueAnyway.setBackground(rounded(palette.accent, palette.accentDark, dp(14)));
        continueAnyway.setClickable(true);
        continueAnyway.setFocusable(true);
        continueAnyway.setOnClickListener(view -> dismissPeriodicReminder("continue_anyway", true));
        if (!StudyModeManager.isProStrictModeActive(this)) {
            panel.addView(continueAnyway, matchWrap());
        }
        root.requestFocus();
        return root;
    }

    private void refreshPeriodicReminderStudyApps() {
        LinearLayout section = periodicReminderStudyAppsSection;
        if (section == null || !periodicReminderVisible.get()) return;
        section.removeAllViews();
        PopupPalette palette = getPopupPalette();
        TextView title = popupText("Your Study Apps", 13, palette.text, Typeface.BOLD, Gravity.CENTER);
        section.addView(title, matchWrap());
        addGap(section, 7);

        List<String> packages = StudyModeManager.getSelectedStudyAppPackages(this);
        if (packages.isEmpty()) {
            TextView empty = popupText("No Study Apps Selected", 11,
                palette.secondaryText, Typeface.NORMAL, Gravity.CENTER);
            empty.setPadding(dp(8), dp(8), dp(8), dp(8));
            section.addView(empty, matchWrap());
            TextView choose = popupText("Choose Study Apps", 12,
                palette.accent, Typeface.BOLD, Gravity.CENTER);
            choose.setMinHeight(dp(42));
            choose.setBackground(rounded(palette.iconSurface, palette.accentBorder, dp(12)));
            choose.setClickable(true);
            choose.setFocusable(true);
            choose.setOnClickListener(view -> {
                if (StudyModeManager.openStudyAppsSelection(StudyModeFocusService.this)) {
                    dismissPeriodicReminder("study_apps_selection_opened", true);
                } else {
                    showPeriodicReminderError("Math Master could not open Study Apps settings.");
                }
            });
            section.addView(choose, matchWrap());
        } else {
            ScrollView appsScroll = new ScrollView(this);
            appsScroll.setFillViewport(false);
            appsScroll.setVerticalScrollBarEnabled(packages.size() > 4);
            LinearLayout grid = new LinearLayout(this);
            grid.setOrientation(LinearLayout.VERTICAL);
            int widthDp = Math.round(getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
            int columns = widthDp >= 560 ? 3 : 2;
            for (int i = 0; i < packages.size(); i += columns) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams rowParams = matchWrap();
                if (i > 0) rowParams.topMargin = dp(6);
                grid.addView(row, rowParams);
                for (int column = 0; column < columns; column++) {
                    int index = i + column;
                    if (index < packages.size()) {
                        row.addView(buildPeriodicStudyAppShortcut(packages.get(index), palette),
                            new LinearLayout.LayoutParams(0, dp(54), 1f));
                    } else {
                        row.addView(new android.view.View(this),
                            new LinearLayout.LayoutParams(0, dp(54), 1f));
                    }
                    if (column < columns - 1) {
                        row.addView(new android.view.View(this), new LinearLayout.LayoutParams(dp(7), 1));
                    }
                }
            }
            appsScroll.addView(grid, new ScrollView.LayoutParams(-1, -2));
            section.addView(appsScroll, new LinearLayout.LayoutParams(-1, dp(150)));
        }

        periodicReminderAppsError = popupText("", 10, Color.rgb(239, 94, 94),
            Typeface.NORMAL, Gravity.CENTER);
        periodicReminderAppsError.setVisibility(android.view.View.GONE);
        periodicReminderAppsError.setPadding(dp(4), dp(5), dp(4), dp(2));
        section.addView(periodicReminderAppsError, matchWrap());
    }

    private android.view.View buildPeriodicStudyAppShortcut(String packageName, PopupPalette palette) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(7), dp(6), dp(7), dp(6));
        card.setBackground(rounded(palette.shortcutSurface, palette.border, dp(13)));
        card.setClickable(true);
        card.setFocusable(true);
        String labelValue = getStudyAppLabel(packageName);
        card.setContentDescription("Open " + labelValue);
        ImageView icon = new ImageView(this);
        android.graphics.drawable.Drawable drawable = getStudyAppIcon(packageName);
        if (drawable != null) icon.setImageDrawable(drawable);
        else icon.setImageResource(android.R.drawable.sym_def_app_icon);
        card.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView label = popupText(labelValue, 10, palette.text, Typeface.BOLD, Gravity.CENTER_VERTICAL);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, -2, 1f);
        labelParams.leftMargin = dp(6);
        card.addView(label, labelParams);
        card.setOnClickListener(view -> {
            if (!StudyModeManager.getSelectedStudyAppPackages(StudyModeFocusService.this).contains(packageName)) {
                refreshPeriodicReminderStudyApps();
                showPeriodicReminderError("This app is no longer in your selected Study Apps.");
                return;
            }
            if (StudyModeManager.launchStudyApp(StudyModeFocusService.this, packageName)) {
                dismissPeriodicReminder("study_app_opened", false);
            } else {
                showPeriodicReminderError("Could not open " + labelValue + ". Check that it is installed and launchable.");
            }
        });
        return card;
    }

    private void showPeriodicReminderError(String message) {
        TextView error = periodicReminderAppsError;
        if (error == null) return;
        error.setText(message);
        error.setVisibility(android.view.View.VISIBLE);
    }

    private void persistReminderUsage(boolean force) {
        long now = SystemClock.elapsedRealtime();
        long usage = periodicReminderUsage.getAccumulatedUsageMs();
        if (usage == lastPersistedReminderUsageMs
            || (!force && now - lastReminderUsagePersistElapsedMs < 5_000L)) return;
        StudyModeManager.saveReminderUsageMs(this, usage);
        lastPersistedReminderUsageMs = usage;
        lastReminderUsagePersistElapsedMs = now;
    }

    private void suspendPeriodicReminderForBlockedApp() {
        android.view.View existingView = periodicReminderView;
        if (existingView == null) return;
        try {
            if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) throw new IllegalStateException("WindowManager unavailable during reminder suspension");
            windowManager.removeViewImmediate(existingView);
            periodicReminderView = null;
            periodicReminderStudyAppsSection = null;
            periodicReminderAppsError = null;
            logStage("PERIODIC_REMINDER_SUSPENDED", periodicReminderPackage, periodicReminderId,
                "pending", "blocked_app_takes_priority");
        } catch (IllegalArgumentException alreadyDetached) {
            periodicReminderView = null;
            periodicReminderStudyAppsSection = null;
            periodicReminderAppsError = null;
        } catch (Exception error) {
            // Keep the attached reference and durable pending state. The hard
            // block overlay is still requested and will cover this reminder.
            logStage("PERIODIC_REMINDER_SUSPEND_FAILED", periodicReminderPackage, periodicReminderId,
                "still_attached", error.getClass().getSimpleName());
        }
    }

    private void dismissPeriodicReminder(String reason, boolean resetInterval) {
        android.view.View existingView = periodicReminderView;
        String removedPackage = periodicReminderPackage;
        String removedId = periodicReminderId;
        if (existingView != null) {
            try {
                if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
                if (windowManager == null) throw new IllegalStateException("WindowManager unavailable during reminder teardown");
                windowManager.removeViewImmediate(existingView);
            } catch (IllegalArgumentException alreadyDetached) {
                // WindowManager may already have detached the window after an OEM transition.
            } catch (Exception error) {
                logStage("PERIODIC_REMINDER_DISMISS_FAILED", removedPackage, removedId,
                    "failed", error.getClass().getSimpleName());
                return;
            }
        }
        periodicReminderView = null;
        periodicReminderPackage = "";
        periodicReminderId = "";
        periodicReminderStudyAppsSection = null;
        periodicReminderAppsError = null;
        periodicReminderVisible.set(false);
        StudyModeManager.clearPendingPeriodicReminder(this);
        Handler handler = monitorHandler;
        Runnable updateUsage = () -> {
            periodicReminderUsage.dismissReminder(resetInterval);
            persistReminderUsage(true);
        };
        if (handler == null || !handler.post(updateUsage)) updateUsage.run();
        logStage("PERIODIC_REMINDER_DISMISSED", removedPackage, removedId, "dismissed", reason);
    }

    private android.view.View buildShieldView(String packageName) {
        PopupPalette palette = getPopupPalette();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(palette.scrim);
        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.VERTICAL);
        stage.setGravity(Gravity.CENTER);
        stage.setPadding(dp(14), dp(12), dp(14), dp(12));
        scroll.addView(stage, new ScrollView.LayoutParams(-1, -2));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(17), dp(16), dp(17), dp(15));
        panel.setBackground(roundedGradient(palette.panelTop, palette.panelBottom, palette.border, dp(26)));
        panel.setElevation(dp(18));
        int availableWidth = Math.max(dp(240),
            getResources().getDisplayMetrics().widthPixels - dp(64));
        int panelWidth = Math.min(availableWidth, dp(560));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(panelWidth, -2);
        panelParams.gravity = Gravity.CENTER_HORIZONTAL;
        stage.addView(panel, panelParams);

        // Quote is selected only when this overlay is newly constructed. It is
        // persisted as a shuffled deck so rebuilds/countdown ticks never change it.
        TextView quote = popupText(StudyModeManager.getNextMotivationalQuote(this),
            15, palette.text, Typeface.BOLD, Gravity.CENTER);
        quote.setPadding(dp(3), dp(1), dp(3), dp(1));
        quote.setLineSpacing(dp(2), 1.0f);
        panel.addView(quote, matchWrap());
        addGap(panel, 8);

        LinearLayout activePill = new LinearLayout(this);
        activePill.setGravity(Gravity.CENTER);
        activePill.setOrientation(LinearLayout.HORIZONTAL);
        activePill.setPadding(dp(10), dp(5), dp(10), dp(5));
        activePill.setBackground(rounded(palette.pill, palette.border, dp(30)));
        TextView dot = popupText("●", 9, palette.accent, Typeface.BOLD, Gravity.CENTER);
        activePill.addView(dot, wrapWrap());
        TextView activeLabel = popupText("STUDY MODE ACTIVE", 10, palette.secondaryText,
            Typeface.BOLD, Gravity.CENTER);
        LinearLayout.LayoutParams activeLabelParams = wrapWrap();
        activeLabelParams.leftMargin = dp(7);
        activePill.addView(activeLabel, activeLabelParams);
        panel.addView(activePill, wrapWrap());
        addGap(panel, 10);

        LinearLayout focusIcon = new LinearLayout(this);
        focusIcon.setGravity(Gravity.CENTER);
        focusIcon.setBackground(rounded(palette.iconSurface, palette.border, dp(23)));
        ImageView lock = new ImageView(this);
        lock.setImageResource(android.R.drawable.ic_lock_lock);
        lock.setColorFilter(palette.accent);
        focusIcon.addView(lock, new LinearLayout.LayoutParams(dp(25), dp(25)));
        panel.addView(focusIcon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        TextView heading = popupText("Stay Focused", 21, palette.text, Typeface.BOLD, Gravity.CENTER);
        LinearLayout.LayoutParams headingParams = matchWrap();
        headingParams.topMargin = dp(7);
        panel.addView(heading, headingParams);

        TextView description = popupText(
            "This app is restricted during your study session.",
            12, palette.secondaryText, Typeface.NORMAL, Gravity.CENTER);
        description.setLineSpacing(dp(2), 1.0f);
        LinearLayout.LayoutParams descriptionParams = matchWrap();
        descriptionParams.topMargin = dp(3);
        panel.addView(description, descriptionParams);

        LinearLayout restrictedAppRow = new LinearLayout(this);
        restrictedAppRow.setOrientation(LinearLayout.HORIZONTAL);
        restrictedAppRow.setGravity(Gravity.CENTER_VERTICAL);
        restrictedAppRow.setPadding(dp(9), dp(7), dp(9), dp(7));
        restrictedAppRow.setBackground(rounded(palette.shortcutSurface, palette.border, dp(13)));
        LinearLayout.LayoutParams restrictedAppParams = matchWrap();
        restrictedAppParams.topMargin = dp(10);
        panel.addView(restrictedAppRow, restrictedAppParams);
        ImageView restrictedAppIcon = new ImageView(this);
        android.graphics.drawable.Drawable restrictedDrawable = getStudyAppIcon(packageName);
        if (restrictedDrawable != null) restrictedAppIcon.setImageDrawable(restrictedDrawable);
        else restrictedAppIcon.setImageResource(android.R.drawable.sym_def_app_icon);
        restrictedAppRow.addView(restrictedAppIcon, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView restrictedAppName = popupText(getStudyAppLabel(packageName), 12,
            palette.text, Typeface.BOLD, Gravity.CENTER_VERTICAL);
        restrictedAppName.setMaxLines(1);
        restrictedAppName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams restrictedNameParams = new LinearLayout.LayoutParams(0, -2, 1f);
        restrictedNameParams.leftMargin = dp(9);
        restrictedAppRow.addView(restrictedAppName, restrictedNameParams);
        addGap(panel, 10);

        LinearLayout countdownCard = new LinearLayout(this);
        countdownCard.setOrientation(LinearLayout.VERTICAL);
        countdownCard.setGravity(Gravity.CENTER);
        countdownCard.setPadding(dp(13), dp(9), dp(13), dp(10));
        countdownCard.setBackground(roundedGradient(palette.cardTop, palette.cardBottom,
            palette.cardBorder, dp(16)));
        TextView timerLabel = popupText("◷  TIME REMAINING", 9, palette.secondaryText,
            Typeface.BOLD, Gravity.CENTER);
        countdownCard.addView(timerLabel, matchWrap());
        remainingTimeView = popupText("—", 25, palette.text, Typeface.BOLD, Gravity.CENTER);
        remainingTimeView.setIncludeFontPadding(true);
        LinearLayout.LayoutParams timeParams = matchWrap();
        timeParams.topMargin = dp(4);
        countdownCard.addView(remainingTimeView, timeParams);
        panel.addView(countdownCard, matchWrap());

        sessionEndView = popupText("", 11, palette.secondaryText, Typeface.NORMAL, Gravity.CENTER);
        LinearLayout.LayoutParams untilParams = matchWrap();
        untilParams.topMargin = dp(6);
        panel.addView(sessionEndView, untilParams);


        List<String> studyPackages = StudyModeManager.getSelectedStudyAppPackages(this);
        if (!studyPackages.isEmpty()) {
            addGap(panel, 10);
            TextView studyTitle = popupText("Study Apps", 14, palette.text, Typeface.BOLD, Gravity.CENTER);
            panel.addView(studyTitle, matchWrap());
            addGap(panel, 8);

            int widthDp = Math.round(getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
            int columns = widthDp >= 560 ? 3 : 2;
            for (int i = 0; i < studyPackages.size(); i += columns) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams rowParams = matchWrap();
                if (i > 0) rowParams.topMargin = dp(6);
                panel.addView(row, rowParams);
                for (int column = 0; column < columns; column++) {
                    int index = i + column;
                    if (index < studyPackages.size()) {
                        String studyPackageName = studyPackages.get(index);
                        row.addView(buildStudyAppShortcut(studyPackageName, palette),
                            new LinearLayout.LayoutParams(0, dp(56), 1f));
                    } else {
                        row.addView(new android.view.View(this),
                            new LinearLayout.LayoutParams(0, dp(56), 1f));
                    }
                    if (column < columns - 1) row.addView(new android.view.View(this),
                        new LinearLayout.LayoutParams(dp(8), 1));
                }
            }
        }

        return scroll;
    }

    private android.view.View buildStudyAppShortcut(String packageName, PopupPalette palette) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(7), dp(6), dp(7), dp(6));
        card.setBackground(rounded(palette.shortcutSurface, palette.border, dp(14)));
        card.setClickable(true);
        card.setFocusable(true);
        String appLabel = getStudyAppLabel(packageName);
        card.setContentDescription("Open " + appLabel);
        ImageView icon = new ImageView(this);
        android.graphics.drawable.Drawable drawable = getStudyAppIcon(packageName);
        if (drawable != null) icon.setImageDrawable(drawable);
        else icon.setImageResource(android.R.drawable.sym_def_app_icon);
        card.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView label = popupText(appLabel, 10, palette.text,
            Typeface.BOLD, Gravity.CENTER_VERTICAL);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, -2, 1f);
        labelParams.leftMargin = dp(6);
        card.addView(label, labelParams);
        card.setOnClickListener(view -> {
            if (StudyModeManager.launchStudyApp(StudyModeFocusService.this, packageName)) {
                // Remember the selected destination while its first resumed event
                // is still pending, preventing a stale blocked-package overlay loop.
                lastForegroundPackage = packageName;
                removeShield();
            } else {
                Toast.makeText(StudyModeFocusService.this,
                    "This Study App is unavailable or is now blocked. Update Study Apps in settings.",
                    Toast.LENGTH_LONG).show();
                if (!StudyModeManager.getSelectedStudyAppPackages(StudyModeFocusService.this)
                    .contains(packageName)) removeShield();
            }
        });
        return card;
    }

    private String getStudyAppLabel(String packageName) {
        String cached = STUDY_LABEL_CACHE.get(packageName);
        if (cached != null) return cached;
        try {
            CharSequence label = getPackageManager().getApplicationLabel(
                getPackageManager().getApplicationInfo(packageName, 0));
            if (label != null && label.length() > 0) {
                String value = label.toString();
                STUDY_LABEL_CACHE.put(packageName, value);
                return value;
            }
        } catch (Exception ignored) {
            // The package is revalidated again immediately before launch.
        }
        return packageName;
    }

    private android.graphics.drawable.Drawable getStudyAppIcon(String packageName) {
        android.graphics.drawable.Drawable.ConstantState cached = STUDY_ICON_CACHE.get(packageName);
        if (cached != null) return cached.newDrawable(getResources()).mutate();
        try {
            android.graphics.drawable.Drawable drawable =
                getPackageManager().getApplicationIcon(packageName);
            android.graphics.drawable.Drawable.ConstantState state = drawable.getConstantState();
            if (state != null) STUDY_ICON_CACHE.put(packageName, state);
            return drawable;
        } catch (Exception ignored) {
            return null;
        }
    }

    private PopupPalette getPopupPalette() {
        android.content.SharedPreferences preferences =
            getSharedPreferences("math_master_study_mode", MODE_PRIVATE);
        String mode = preferences.getString("popupMode", "dark");
        String theme = preferences.getString("popupTheme", "arctic-blue");
        PopupPalette palette = new PopupPalette();
        palette.light = "light".equals(mode);
        palette.accent = ScreenTimeIslandPainter.accentForTheme(theme);
        palette.accentDark = blendColor(palette.accent, Color.BLACK, 0.25f);
        palette.accentBorder = blendColor(palette.accent, Color.WHITE, 0.18f);
        if (palette.light) {
            palette.scrim = Color.argb(238, 238, 243, 251);
            palette.panelTop = Color.rgb(255, 255, 255);
            palette.panelBottom = Color.rgb(243, 247, 253);
            palette.text = Color.rgb(24, 35, 55);
            palette.secondaryText = Color.rgb(91, 105, 127);
            palette.pill = blendColor(palette.accent, Color.WHITE, 0.91f);
            palette.iconSurface = blendColor(palette.accent, Color.WHITE, 0.88f);
            palette.cardTop = blendColor(palette.accent, Color.WHITE, 0.94f);
            palette.cardBottom = Color.rgb(246, 249, 255);
            palette.cardBorder = blendColor(palette.accent, Color.WHITE, 0.62f);
            palette.shortcutSurface = Color.rgb(249, 251, 255);
            palette.border = Color.rgb(218, 226, 238);
        } else {
            palette.scrim = Color.argb(246, 5, 10, 23);
            palette.panelTop = Color.rgb(15, 25, 45);
            palette.panelBottom = Color.rgb(10, 17, 33);
            palette.text = Color.rgb(245, 248, 255);
            palette.secondaryText = Color.rgb(165, 181, 207);
            palette.pill = Color.argb(55, Color.red(palette.accent), Color.green(palette.accent), Color.blue(palette.accent));
            palette.iconSurface = Color.argb(42, Color.red(palette.accent), Color.green(palette.accent), Color.blue(palette.accent));
            palette.cardTop = Color.rgb(22, 37, 63);
            palette.cardBottom = Color.rgb(16, 29, 51);
            palette.cardBorder = blendColor(palette.accent, Color.BLACK, 0.45f);
            palette.shortcutSurface = Color.rgb(22, 34, 56);
            palette.border = Color.rgb(48, 65, 91);
        }
        return palette;
    }

    private int blendColor(int foreground, int background, float backgroundAmount) {
        float amount = Math.max(0f, Math.min(1f, backgroundAmount));
        return Color.rgb(
            Math.round(Color.red(foreground) * (1f - amount) + Color.red(background) * amount),
            Math.round(Color.green(foreground) * (1f - amount) + Color.green(background) * amount),
            Math.round(Color.blue(foreground) * (1f - amount) + Color.blue(background) * amount)
        );
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(radius);
        if (stroke != 0) shape.setStroke(dp(1), stroke);
        return shape;
    }

    private GradientDrawable roundedGradient(int top, int bottom, int stroke, int radius) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{top, bottom});
        shape.setCornerRadius(radius);
        if (stroke != 0) shape.setStroke(dp(1), stroke);
        return shape;
    }

    private TextView popupText(String value, float size, int color, int style, int gravity) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setTypeface(Typeface.create("sans-serif", style));
        text.setGravity(gravity);
        text.setIncludeFontPadding(true);
        return text;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams wrapWrap() {
        return new LinearLayout.LayoutParams(-2, -2);
    }

    private void addGap(LinearLayout parent, int heightDp) {
        parent.addView(new android.view.View(this),
            new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private static final class PopupPalette {
        boolean light;
        int scrim, panelTop, panelBottom, text, secondaryText, pill, iconSurface;
        int cardTop, cardBottom, cardBorder, shortcutSurface, border;
        int accent, accentDark, accentBorder;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void updateRemainingTime() {
        if (remainingTimeView == null) return;
        long remainingSeconds = StudyModeManager.getCurrentSessionRemainingSeconds(this);
        if (remainingSeconds < 0L) {
            remainingTimeView.setText("Unlimited");
        } else {
            long hours = remainingSeconds / 3600L;
            long minutes = (remainingSeconds % 3600L) / 60L;
            long seconds = remainingSeconds % 60L;
            String value = hours > 0
                ? String.format(java.util.Locale.ROOT, "%02dh %02dm %02ds", hours, minutes, seconds)
                : String.format(java.util.Locale.ROOT, "%02dm %02ds", minutes, seconds);
            remainingTimeView.setText(value);
        }
        if (sessionEndView != null) {
            long sessionEnd = StudyModeManager.getCurrentSessionEndMillis(this);
            sessionEndView.setText(sessionEnd > 0L
                ? "Session ends at " + DateFormat.getTimeFormat(this).format(new Date(sessionEnd))
                : "No scheduled end time");
        }
    }

    private final Runnable countdownRunnable = new Runnable() {
        @Override
        public void run() {
            if (remainingTimeView == null || !running) return;
            updateRemainingTime();
            mainHandler.postDelayed(this, 1000L);
        }
    };

    private void removeShield() {
        removeShield("unspecified");
    }

    private void removeShield(String reason) {
        mainHandler.removeCallbacks(countdownRunnable);
        android.view.View existingView = shieldView;
        if (existingView != null) dismissScreenTimeIslandImmediately("shield_overlay");
        String removedPackage = shieldedPackage;
        String removedRequestId = activeShieldRequestId;
        if (existingView != null) {
            try {
                if (windowManager == null) {
                    windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
                }
                if (windowManager == null) {
                    throw new IllegalStateException("WindowManager unavailable during overlay teardown");
                }
                windowManager.removeViewImmediate(existingView);
                logStage("POPUP_DISMISSED", removedPackage, removedRequestId, "removed", reason);
            } catch (IllegalArgumentException alreadyDetached) {
                // WindowManager uses this when another lifecycle path already detached it.
                logStage("POPUP_DISMISSED", removedPackage, removedRequestId, "already_detached", reason);
            } catch (Exception error) {
                // Keep the reference and RECOVERY_REQUIRED state. A new blocker must
                // not be stacked over a window that Android may still have attached.
                popupState = PopupState.RECOVERY_REQUIRED;
                overlayFailureForStatus = true;
                StudyModeManager.setServiceState(this, "overlay_failed");
                logStage("POPUP_DISMISSED", removedPackage, removedRequestId,
                    "remove_failed", error.getClass().getSimpleName());
                return;
            }
        } else if (popupState == PopupState.LAUNCH_PENDING && !removedRequestId.isEmpty()) {
            logStage("POPUP_DISMISSED", removedPackage, removedRequestId, "pending_cancelled", reason);
        }
        shieldView = null;
        remainingTimeView = null;
        sessionEndView = null;
        shieldedPackage = "";
        activeShieldRequestId = "";
        popupState = PopupState.IDLE;
    }

    private void logStage(
        String stage,
        String packageName,
        String requestId,
        String result,
        String reason
    ) {
        // Package activity is personal data. Keep diagnostics in debuggable builds
        // only, and log stage metadata without screen content or unrelated activity.
        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) == 0) return;

        String sessionId = activeDiagnosticSessionId;
        String safePackage = packageName == null || packageName.isEmpty() ? "unknown" : packageName;
        String safeRequest = requestId == null || requestId.isEmpty() ? "none" : requestId;
        Log.d(LOG_TAG,
            "event=" + stage
                + " timestampMs=" + System.currentTimeMillis()
                + " sessionId=" + sessionId
                + " package=" + safePackage
                + " requestId=" + safeRequest
                + " result=" + result
                + " reason=" + reason);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        logStage("FOCUS_TASK_REMOVED", "", "", "continuing", "launcher_task_removed");
        // Removing the launcher task is not an OFF action. Keep the persisted
        // session and FGS alive, then re-read UsageStats so stale foreground data
        // cannot leave a selected app unshielded after the task was swiped away.
        Handler currentHandler = monitorHandler;
        long expectedGeneration = monitorGeneration;
        if (currentHandler != null && StudyModeManager.shouldEnforceNow(this)) {
            currentHandler.post(() -> {
                if (currentHandler != monitorHandler || expectedGeneration != monitorGeneration) return;
                foregroundDecisionSequence.incrementAndGet();
                resetForegroundResolution();
                monitorRunnable.run();
            });
        }
        if (running) updateOngoingNotification();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        logStage("FOCUS_SERVICE_DESTROYED", "", "", "destroyed", "service_on_destroy");
        foregroundDecisionSequence.incrementAndGet();
        monitorGeneration++;
        lastMonitorHeartbeatElapsedMs = 0L;
        mainHandler.removeCallbacks(monitorThreadRecoveryRunnable);
        running = false;
        starting = false;
        stopping = false;
        if (activeService == this) activeService = null;
        immediateEvaluationQueued.set(false);
        monitorRecoveryInFlight.set(false);
        if (monitorHandler != null) monitorHandler.removeCallbacksAndMessages(null);
        if (monitorThread != null) monitorThread.quitSafely();
        mainHandler.removeCallbacksAndMessages(null);
        dismissScreenTimeIslandImmediately("service_destroyed");
        ScreenTimeIslandOverlay preview = previewIslandOverlay;
        previewIslandOverlay = null;
        if (preview != null) preview.dismissImmediately();
        removeShield("service_destroyed");
        if (!StudyModeManager.shouldEnforceNow(this)) {
            dismissPeriodicReminder("service_destroyed", false);
            periodicReminderUsage.clear();
            StudyModeManager.clearReminderUsageMs(this);
        } else if (periodicReminderVisible.get()) {
            try {
                if (periodicReminderView != null && windowManager != null) {
                    windowManager.removeViewImmediate(periodicReminderView);
                }
            } catch (Exception ignored) {}
            periodicReminderView = null;
            periodicReminderVisible.set(false);
            StudyModeManager.saveReminderUsageMs(this, periodicReminderUsage.getAccumulatedUsageMs());
        } else {
            persistReminderUsage(true);
        }
        boolean overlayCleanupFailed = shieldView != null;
        overlayFailureForStatus = overlayCleanupFailed;
        foregroundLookupFailureForStatus = false;
        if (!StudyModeManager.isPolicyOwner(this) && StudyModeManager.shouldEnforceNow(this)
            && StudyModeManager.hasForegroundMonitoringPermission(this) && StudyModeManager.hasOverlayPermission(this)) {
            StudyModeManager.setServiceState(this, overlayCleanupFailed ? "overlay_failed" : "service_stopped");
        }
        try {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(NOTIFICATION_ID);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        dismissScreenTimeIslandImmediately("configuration_changed");
        ScreenTimeIslandOverlay preview = previewIslandOverlay;
        previewIslandOverlay = null;
        if (preview != null) preview.dismissImmediately();
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
