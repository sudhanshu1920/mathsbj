import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const fail = (message) => {
  console.error('Architecture regression:', message);
  process.exit(1);
};

const css = read('src/index.css');
const learning = read('src/pages/LearningPage.tsx');
const icons = read('src/lib/topicIcons.ts');
const practice = read('src/pages/PracticePage.tsx');
const index = read('src/pages/Index.tsx');
const floatingBarVisibility = read('src/lib/floatingBarVisibility.ts');
const floatingBarVisibilityTests = read('src/lib/floatingBarVisibility.test.ts');
const sync = read('src/lib/sync.ts');
const auth = read('src/contexts/AuthContext.tsx');
const practiceSelector = read('src/components/PracticeModeSelector.tsx');
const bottomNavTest = read('src/components/BottomNav.test.tsx');
const bottomNavUi = read('src/components/BottomNav.tsx');
const offlineReady = read('src/lib/offlineReady.ts');
const streak = read('src/lib/streak.ts');
const personalApkWorkflow = read('.github/workflows/android-apk.yml');
const publicReleaseWorkflow = read('.github/workflows/android-release.yml');
const widgetScreenTimeRepository = read('android-native/com/sudhanshu/mathsbj/WidgetScreenTimeRepository.java');
const widgetScreenTimeProvider = read('android-native/com/sudhanshu/mathsbj/MathMasterHomeWidgetProvider.java');
const widgetScreenTimeRenderer = read('android-native/com/sudhanshu/mathsbj/MathMasterWidgetRenderer.java');
const widgetScreenTimeSetup = read('scripts/configure-android-widgets.mjs');
const widgetScreenTimeBackup = read('src/lib/backupRestore.ts');
const widgetScreenTimeBridge = read('android-native/com/sudhanshu/mathsbj/MathMasterWidgetsPlugin.java');
const widgetScreenTimeEntry = read('src/pages/Index.tsx');
const widgetConfigActivity = read('android-native/com/sudhanshu/mathsbj/MathMasterWidgetConfigActivity.java');
if (!widgetScreenTimeRepository.includes('UsageStatsManager.INTERVAL_DAILY')
    || !widgetScreenTimeRepository.includes('StudyModeManager.getSelectedStudyAppPackages(context)')
    || !widgetScreenTimeRepository.includes('new HashSet<>(usage.keySet())')
    || !widgetScreenTimeRepository.includes('candidatePackages.addAll(selectedStudy)')
    || !widgetScreenTimeRepository.includes('pm.getApplicationInfo(packageName')
    || widgetScreenTimeRepository.includes('getInstalledApplications')
    || widgetConfigActivity.includes('populateAppFilters')
    || widgetConfigActivity.includes('getInstalledApplications')
    || !widgetScreenTimeRepository.includes('AppUsageAnalyticsPlugin.hasUsageAccess')
    || !widgetScreenTimeRepository.includes('cacheGeneration != requestGeneration')
    || !widgetScreenTimeProvider.includes('studyAppsScreenTime')
    || !widgetScreenTimeProvider.includes('deviceAppsScreenTime')
    || !widgetScreenTimeRepository.includes('record != null && !hidden.contains(packageName)')
    || !widgetScreenTimeRenderer.includes('void layoutScreenTimeReflow(float rw, float rh)')
    || !widgetScreenTimeRenderer.includes('void studyAppsPanel(')
    || !widgetScreenTimeRenderer.includes('void deviceAppsPanel(')
    || !widgetScreenTimeRenderer.includes('void drawLegacyMiniBlocks(')
    || widgetScreenTimeRenderer.includes('layoutScreenTimeCombined')
    || widgetScreenTimeRenderer.includes('drawLegacyContentSummary')
    || widgetScreenTimeRenderer.includes('screenTimePrimaryText')
    || !widgetScreenTimeBridge.includes('public void refreshScreenTime(PluginCall call)')
    || !widgetScreenTimeBridge.includes('public void syncAppearance(PluginCall call)')
    || !widgetScreenTimeProvider.includes('options.themeMatched = options.studyAppsScreenTime || options.deviceAppsScreenTime')
    || !widgetScreenTimeProvider.includes('options.themeAccent = Color.parseColor(accent)')
    || !widgetScreenTimeRenderer.includes('this.pal = paletteFor(o.composition, o.themeAccent, o.lightMode, o.themeMatched)')
    || !widgetScreenTimeRenderer.includes('if (themeMatched) applyAccent(p, themeAccent, lightMode)')
    || !widgetScreenTimeBackup.includes("'studyAppsScreenTime', 'deviceAppsScreenTime'")
    || !widgetScreenTimeEntry.includes('NativeWidgetRefresh.refreshScreenTime()')
    || !widgetScreenTimeEntry.includes("window.addEventListener('theme-updated', syncWidgetAppearance)")
    || !widgetScreenTimeEntry.includes('widget-appearance-updated')
    || !widgetScreenTimeSetup.includes('android.intent.category.LAUNCHER')
    || !widgetScreenTimeSetup.includes("'WidgetScreenTimeRepository.java'")) {
  fail('Screen Time widgets must use local UsageStats, keep Study Apps and Device Apps independent, and refresh through the existing native widget setup');
}


if (!personalApkWorkflow.includes("startsWith(github.event.head_commit.message, '[BUILD_ANDROID_APK]')") ||
    publicReleaseWorkflow.includes("startsWith(github.event.head_commit.message, '[BUILD_ANDROID_APK]')")) {
  fail('Artifact-only Android APK builds must not invoke the public GitHub Release/update-feed publisher');
}

if (!css.includes('padding-bottom: var(--floating-bar-height, 0px);')) {
  fail('floating-bar reserve is not tied to the runtime measurement variable');
}
for (const forbidden of ['--bottom-nav-height', '--app-bottom-inset', 'data-app-bottom-bar']) {
  if (css.includes(forbidden)) fail(`legacy floating-bar token/block remains: ${forbidden}`);
}
if (learning.includes('TOPIC_ICON_MAP[t.id]')) {
  fail('LearningPage reverted to string-topic access via t.id');
}
if (!learning.includes('TOPIC_ICON_MAP[topicId]')) {
  fail('LearningPage does not use the canonical topicId mapping');
}
for (const id of [
  'tables', 'squares', 'square-roots', 'cubes', 'cube-roots',
  'powers', 'percentage', 'formulas', 'periodic-table', 'study-tracker', 'study-mode',
]) {
  if (!icons.includes(id)) {
    fail(`missing canonical topic icon mapping: ${id}`);
  }
}
if (!icons.includes('Grid3x3') || !icons.includes('Radical') || !icons.includes('Sigma') || !icons.includes('Atom')) {
  fail('core semantic topic icon imports are missing');
}
if (!icons.includes('LockKeyhole') ||
    !learning.includes("const StudyModePage = lazy(() => import('@/components/StudyModePage'));") ||
    !learning.includes('if (studyModeTopicOpen)') ||
    !learning.includes('<StudyModePage backLabel="Back to Learning Mode" onBack={() => setStudyModeTopicOpen(false)} openStudyAppsPicker={openStudyAppsPickerAfterMount} onStudyAppsPickerOpened={clearStudyAppsPickerRequest} />') ||
    !learning.includes("if (topicId === 'study-mode')")) {
  fail('Learning Mode Study Mode entry must reuse the canonical StudyModePage and return to its topic list');
}
if (practice.includes('sort(() => Math.random() - 0.5)')) {
  fail('biased random sort shuffle reintroduced');
}
const practiceExitStart = index.indexOf('const handlePracticeExit = useCallback(() => {');
const practiceExitEnd = index.indexOf('const handlePracticeExitCancelled = useCallback', practiceExitStart);
const practiceExitHandler = index.slice(practiceExitStart, practiceExitEnd);
if (practiceExitStart < 0 || practiceExitEnd < 0 ||
    !practiceExitHandler.includes('setSectionTransitionDirection(null);')) {
  fail('Quiz exit must clear stale main-section transition state before restoring its destination');
}

if (!index.includes('getFloatingBarVisibility({') ||
    !index.includes('activeTopic: learningState.activeTopic') ||
    !index.includes('quizInProgress: isPracticeSessionInProgress(practicePhase)') ||
    !index.includes('studyModeOpen: studyModePageVisible') ||
    !index.includes('setStudyModePageVisible(open)') ||
    !index.includes('const { show: showBottomNav, mount: mountBottomNav } = getFloatingBarVisibility({')) {
  fail('Floating Bar visibility must use the centralized policy with Learning topic and Quiz state');
}
if (!floatingBarVisibility.includes("tab === 'learn' && activeTopic !== null") ||
    !floatingBarVisibility.includes("tab === 'practice' && quizInProgress") ||
    !floatingBarVisibility.includes('!studyModeOpen && !learningTopicOpen && !quizSessionOpen') ||
    !floatingBarVisibility.includes('show: mount && !settingsOpen') ||
    !floatingBarVisibilityTests.includes('restores the bar when Back returns to the Learning landing state') ||
    !floatingBarVisibilityTests.includes('unmounts the bar for the %s topic and its nested screens') ||
    !floatingBarVisibilityTests.includes('keeps Settings hidden without changing its existing mount behavior') ||
    !floatingBarVisibilityTests.includes('fully unmounts the Floating Bar while the shared Study Mode page is open from either entry point')) {
  fail('Floating Bar topic-depth, auto-restore, Settings, and Quiz regression tests are missing');
}
if (index.includes("custom={sectionTransitionDirection ?? 'left'}") ||
    !index.includes("x: direction === null") ||
    !index.includes("transition: { duration: direction === null ? 0 : duration")) {
  fail('Main-section exits must immediately clear stale swipe transforms when Quiz restores its originating screen');
}
if (!index.includes("opacity: direction === null ? 0 : 1")) {
  fail('Non-swipe exits must hide the outgoing screen immediately to prevent overlap with the restored destination');
}
if (index.includes("data-current-theme={currentTheme}") || index.includes("data-current-mode={currentMode}")) {
  fail('app shell still subscribes to theme/mode only for redundant data attributes');
}
if (index.includes("className={tab === 'learn' ? 'animate-fade-in' : 'hidden'}")) {
  fail('inactive Learning screen remains mounted and hidden instead of being unmounted');
}
if (!index.includes("{tab === 'learn' && (") || !index.includes("<LearningPage")) {
  fail('Learning screen is not conditionally mounted');
}
if (!practice.includes("sessionIntervalRef")) {
  fail('Practice session clock consolidation is missing');
}
if (practice.includes("const timerRef = useRef") || practice.includes("const elapsedRef = useRef")) {
  fail('duplicate Practice timer refs were reintroduced');
}
if ((practice.match(/setInterval\(/g) || []).length > 1) {
  fail('Practice should use one consolidated session interval');
}
if (!offlineReady.includes("Capacitor.isNativePlatform()") || !offlineReady.includes("markOfflineReady();")) {
  fail('native offline preparation still performs unnecessary chunk warming');
}
if (!streak.includes("let cache: StreakState | null = null") || !streak.includes("save(s, notify)") || !streak.includes("streak-persisted")) {
  fail('streak hot-path cache/notification throttling is missing');
}
if (!practice.includes('practice-exit-dialog')) {
  fail('Practice exit dialog is missing its viewport positioning class');
}
if (!practice.includes('onQuizReset?: () => void;') ||
    !practice.includes('onQuizReset?.();') ||
    !index.includes('onQuizReset={handlePracticeReset}')) {
  fail('Exiting/resetting a quiz must restore the parent Practice phase and Floating Bar');
}
const practiceNavigationTests = read('src/test/practiceNavigation.test.ts');
const practiceNavigation = read('src/lib/practiceNavigation.ts');
if (!practiceNavigationTests.includes("isPracticeSessionInProgress('setup')") ||
    !practiceNavigationTests.includes("isPracticeSessionInProgress('active')") ||
    !practiceNavigationTests.includes("isPracticeSessionInProgress('finished')")) {
  fail('Quiz setup/active/result Floating Bar visibility phase tests are missing');
}
if (!index.includes('setLearningPracticeReturn(launchContext)') ||
    !index.includes('setLearningPracticeSelectorOpen(restoreSelector)') ||
    !index.includes('replaceNextNavigationEntry.current = true') ||
    !index.includes("tab === 'learn' && learningPracticeSelectorOpen") ||
    !learning.includes('practiceSelectorOpen = false') ||
    !learning.includes('matchingPracticeReturn?.extras?.timerEnabled') ||
    !learning.includes('practiceReturn?.topic === practicePreferenceTopic') ||
    !practiceSelector.includes('initialSettings?.timerEnabled ?? false') ||
    !practiceNavigation.includes('LEARNING_PRACTICE_SELECTOR_DEPTH') ||
    !practiceNavigationTests.includes('returns a Learning-origin quiz to the Practice selector') ||
    !index.includes('setPracticeBackRequest((value) => value + 1);') ||
    !index.includes('isHandlingPopstate.current = false;') ||
    !learning.includes("if (activeTopic === 'periodic-table' && periodicSelectedElement)")) {
  fail('Learning topic → Practice selector → Quiz → selector → topic restoration contract is incomplete');
}
if (!practice.includes('levelUpTimerRef') ||
    !practice.includes('xpPopTimerRef') ||
    /if \(sessionIntervalRef\.current\) clearInterval\(sessionIntervalRef\.current\);\n\s+if \(sessionIntervalRef\.current\) clearInterval/.test(practice)) {
  fail('Practice exit must clear each unique interval and every deferred UI timeout without duplicate cleanup');
}
const glass = read('src/glass.css');
const device = read('src/lib/device.ts');
if (!glass.includes('.glass:not(.fixed):not(.absolute):not(.sticky)') ||
    !glass.includes('.glass-panel:not(.fixed):not(.absolute):not(.sticky)')) {
  fail('glass utilities can override fixed/absolute/sticky positioning');
}
if (!index.includes('createPortal(') || !index.includes('document.body')) {
  fail('floating-bar is not portalled to the viewport root');
}
if (index.includes("if (newTab === tab || sectionTransitionDirection) return;") ||
    !index.includes("if (!transitionDirection && sectionTransitionDirection) {")) {
  fail('primary Floating Bar taps must be able to supersede in-flight swipe animations');
}
if (!index.includes('if (element.scrollWidth > element.clientWidth + 1) {') ||
    !index.includes("const overflowX = window.getComputedStyle(element).overflowX;")) {
  fail('swipe exclusion must avoid unnecessary computed-style reads on non-overflowing ancestors');
}
if (!bottomNavUi.includes('window.requestAnimationFrame(() => playClick())') ||
    !bottomNavTest.includes('requests navigation synchronously before click sound work')) {
  fail('non-critical click sound work must not block Floating Bar navigation');
}
if (glass.includes('padding-bottom: env(safe-area-inset-bottom, 0px);') ||
    !css.includes('bottom: calc(10px + env(safe-area-inset-bottom, 0px))')) {
  fail('Floating Bar safe-area clearance must be accounted for exactly once through its fixed offset');
}
if (!glass.includes('--bottom-nav-blur: 8px;') ||
    !glass.includes('--bottom-nav-blur: 12px;') ||
    !glass.includes('hsl(var(--card) / 0.94)') ||
    !glass.includes('@supports not (backdrop-filter: blur(1px))')) {
  fail('Floating Bar needs tuned real blur and a readable no-blur fallback');
}
const navLayoutRule = css.match(/\.bottom-nav \{\n([\s\S]*?)\n\}/)?.[1] ?? '';
if (/background:|backdrop-filter|box-shadow/.test(navLayoutRule)) {
  fail('Floating Bar layout and glass-surface styling must have a single CSS owner each');
}
if (css.includes('/* Low-power / reduced-motion devices: drop the expensive blur entirely. */') ||
    device.includes('matchMedia("(prefers-reduced-motion: reduce)")')) {
  fail('reduced-motion preference must not be misclassified as low-power or remove static glass');
}

if ((index.match(/<BottomNav\b/g) ?? []).length !== 1) {
  fail('exactly one Floating Bar component instance must be declared in the app shell');
}
if (!index.includes('hidden={!showBottomNav}')) {
  fail('Floating Bar must stay mounted and hide without remounting in Settings');
}

const bottomNav = read('src/components/BottomNav.tsx');
if (!bottomNav.includes('bottom-nav fixed bottom-0')) {
  fail('floating-bar is not fixed to the viewport');
}
if (!index.includes("scrollElement.style.setProperty('--floating-bar-height', '0px');")) {
  fail('Settings layout does not clear the floating-bar reserve synchronously');
}
if (!index.includes('--floating-bar-height') || !index.includes('ResizeObserver')) {
  fail('runtime floating-bar measurement architecture is missing');
}
if (!index.includes("visualViewport.offsetTop + visualViewport.height") || !index.includes("viewportBottom - rect.top")) {
  fail('floating-bar reserve does not use a consistent visual-viewport coordinate system');
}
if (!css.includes("env(safe-area-inset-bottom") ||
    !glass.includes("left: 50% !important;") ||
    !glass.includes("transform: translateX(-50%)")) {
  fail('Floating Bar safe-area offset or narrow-screen centering regression detected');
}

if (!bottomNavUi.includes("aria-current={isActive ? 'page' : undefined}")) {
  fail('floating-bar active navigation semantics are missing');
}
if (!index.includes("getHorizontalSwipeDirection") ||
    !index.includes("direction === 'left'") ||
    !index.includes("direction === 'right'")) {
  fail('Top-level horizontal swipe navigation must support both directions');
}
if (!index.includes("const MAIN_SECTION_ORDER: readonly Tab[] = ['learn', 'practice', 'progress'];") ||
    !index.includes("getAdjacentMainSection(tab, direction)")) {
  fail('Three-section swipe navigation must use one shared Learning/Quiz/Progress section order');
}
if (!index.includes("!settingsOpen") ||
    !index.includes("tab === 'progress');")) {
  fail('Progress/settings swipe root guards are missing');
}
if (!index.includes("direction === 'left' ? 1 : -1")) {
  fail('Left swipe must map to the next section and right swipe to the previous section');
}
if (!index.includes("if (nextTab) handleTabChange(nextTab, direction);")) {
  fail('Boundary swipes must resolve to a safe no-op without navigation');
}
if (!index.includes("tab === 'learn' && learningState.activeTopic === null")) {
  fail('Learning swipe is not restricted to the top-level Learning screen');
}
if (!index.includes("tab === 'practice' && practicePhase === 'setup'")) {
  fail('Quiz swipe is not restricted to quiz setup');
}
if (!index.includes("appSectionSwipeEnabled =")) {
  fail('Page-level swipe enablement guard is missing');
}
if (!index.includes("MOTION.duration.page") ||
    !index.includes("MOTION.ease.standard") ||
    !index.includes("startTransition(applyNavigation)") ||
    !index.includes("applyNavigation();") ||
    !index.includes("AnimatePresence") ||
    !index.includes("mode=\"sync\"")) {
  fail('Unified page motion system is missing from the app shell');
}
if (!index.includes("if (transitionDirection)") ||
    !index.includes("Primary navigation taps are discrete UI actions")) {
  fail('Primary navigation taps must bypass concurrent transition scheduling');
}
if (!index.includes("startTransition(applyNavigation)") ||
    !index.includes("applyNavigation();")) {
  fail('Navigation lifecycle must retain both swipe-concurrent and direct-immediate paths');
}
if (!bottomNavUi.includes("memo(BottomNavBase)")) {
  fail('Floating Bar should be memoized against unrelated parent renders');
}
if (!index.includes("prefersReducedMotion ? MOTION.duration.instant : MOTION.duration.page")) {
  fail('Page transitions are not reduced-motion aware');
}
const motion = read('src/lib/motion.ts');
for (const token of [
  "duration", "stagger", "distance", "scale", "ease", "springGentle",
]) {
  if (!motion.includes(token)) fail(`shared motion token missing: ${token}`);
}
const button = read('src/components/ui/button.tsx');
if (!button.includes('motion-press')) {
  fail('Base Button does not use shared press feedback');
}
const settingsPanel = read('src/components/SettingsPanel.tsx');
const progressPage = read('src/pages/ProgressPage.tsx');
if (
  practice.includes("whileTap={{ scale: 0.92 }}") ||
  settingsPanel.includes("whileTap={{ scale: 0.92 }}") ||
  progressPage.includes("whileTap={{ scale: 0.92 }}")
) {
  fail('Aggressive 0.92 tap scale should not be reintroduced');
}
if (!index.includes("AnimatePresence") ||
    !index.includes('mode="sync"') ||
    !index.includes('variants={sectionPageVariants}') ||
    !index.includes("x: direction === 'left'") ||
    !index.includes("willChange: sectionTransitionDirection ? 'transform' : 'auto'")) {
  fail('Directional page transition architecture is missing');
}
if (!index.includes("useReducedMotion") ||
    !index.includes("prefersReducedMotion ? MOTION.duration.instant : MOTION.duration.page")) {
  fail('Reduced-motion-aware section transition timing is missing');
}
if (!index.includes("startTransition(applyNavigation)")) {
  fail('Navigation must keep the current screen visible while lazy destination chunks resolve');
}
if (!index.includes("!sectionTransitionDirection")) {
  fail('Page-level swiping must be locked while a section transition is active');
}
if (!index.includes("e.pointerType === 'mouse'") || !index.includes('!e.isPrimary')) {
  fail('app-level swipe is not protected from mouse or multi-touch gestures');
}
if (!practiceSelector.includes('data-swipe-ignore-app-section="true"')) {
  fail('Practice mode selector can accidentally trigger app-level navigation');
}
if (!bottomNavUi.includes('motion-press') ||
    !bottomNavUi.includes('const DOUBLE_TAP_DELAY = 280;') ||
    !bottomNavUi.includes('onChange(tabId);')) {
  fail('floating-bar fast tap interaction architecture regressed');
}
if (!bottomNavTest.includes('renders exactly one navigation surface') ||
    !bottomNavTest.includes('newly selected section as a reset gesture') ||
    !bottomNavTest.includes('consecutive double taps') ||
    !bottomNavTest.includes('another section is tapped between')) {
  fail('Floating Bar uniqueness and rapid-tap regression tests are missing');
}
if (bottomNavUi.includes('tapTimers') ||
    bottomNavUi.includes('setTimeout(() => {\n        onChange(tabId);')) {
  fail('floating-bar navigation must not defer first-tap navigation');
}
if (!bottomNavUi.includes('previousTap?.tabId === tabId') ||
    !bottomNavUi.includes('previousTap.wasActive')) {
  fail('rapid taps on inactive/different tabs must not trigger a section reset');
}
if (!progressPage.includes('useLayoutEffect') ||
    !progressPage.includes('onSettingsVisibilityChange?.(showSettings)')) {
  fail('Settings visibility must synchronize before paint to keep nav visibility/reserve atomic');
}
if (!css.includes('.glass-panel:not(.bottom-nav)') ||
    !css.includes('nav.glass-panel:not(.bottom-nav)')) {
  fail('Floating Bar must not inherit the generic glass-surface compositor transform');
}
if (!sync.includes('switchedUser') || !sync.includes('data.progress ?? {}')) {
  fail('cross-account sync isolation guard is missing');
}
if (!auth.includes('syncStartTimerRef') || !auth.includes('syncUserIdRef')) {
  fail('auth sync lifecycle guard is missing');
}

const updateFeed = read('src/lib/updateFeed.ts');
const updateService = read('src/lib/appUpdateService.ts');
const updateManager = read('src/components/AppUpdateManager.tsx');
const nativeUpdater = read('src/nativeAppUpdater.ts');
const pwaUpdater = read('src/pwa.ts');
const appVersion = read('src/lib/appVersion.ts');
const viteConfig = read('vite.config.ts');
const releaseWorkflow = read('.github/workflows/android-release.yml');
if (!bottomNav.includes('data-app-floating-nav="true"') || !bottomNav.includes('z-40')) {
  fail('Floating Bar must have one stable identity and remain below dialog overlays');
}
if (nativeUpdater.includes('/releases/tags/latest')) {
  fail('native updater must not rely on anonymous access to a private GitHub Releases API');
}
const expectedUpdateManifestUrl = 'https://raw.githubusercontent.com/sudhanshu1920/mathsbj-updates/main/updates/update.json';
const expectedUpdateApkUrl = 'https://github.com/sudhanshu1920/mathsbj-updates/releases/download/latest/MathMaster-release.apk';
if (!updateFeed.includes(expectedUpdateManifestUrl) ||
    !updateFeed.includes(`export const EXPECTED_APK_URL = \"${expectedUpdateApkUrl}\";`) ||
    !updateFeed.includes('SHA256_PATTERN') ||
    !releaseWorkflow.includes(`\"apkUrl\": \"${expectedUpdateApkUrl}\",`) ||
    !releaseWorkflow.includes('\"github.com\".equalsIgnoreCase(updateUri.getHost())') ||
    !releaseWorkflow.includes('TRUSTED_APK_PATH =') ||
    !releaseWorkflow.includes('TRUSTED_APK_PATH.equals(updateUri.getPath())')) {
  fail('manifest URL, manifest APK URL, native APK allowlist, and checksum validation must use one trusted public release location');
}
if (!updateService.includes('checkForAppUpdate') || !updateService.includes('isNewerRelease')) {
  fail('manual and automatic update checks must use validated metadata and numeric version comparison');
}
if (!updateService.includes('result === "unsupported" && !Capacitor.isNativePlatform()') ||
    !updateService.includes('window.location.reload()')) {
  fail('web Update Now must have a supported reload fallback when no service worker is available');
}
if (!settingsPanel.includes('mountedRef.current = false') ||
    !settingsPanel.includes('if (!mountedRef.current) return;')) {
  fail('Settings updater must guard async UI state/timers after unmount');
}
if (!updateManager.includes('dismissedVersionCode = useRef(0)') ||
    updateManager.includes('localStorage.getItem("mathmaster.dismissed-update-version-code")') ||
    !updateManager.includes('Update Now') ||
    !updateManager.includes('Download APK') ||
    !updateManager.includes('downloadAppUpdate') ||
    !updateManager.includes('activeActionRef.current')) {
  fail('update dialog must expose mutually exclusive Update Now/Download APK/Later choices and scope dismissal to the current session');
}
if (!updateManager.includes('lastAutomaticCheckSucceeded') ||
    !updateManager.includes('30_000') ||
    !updateManager.includes('runCheck(false, false, true)') ||
    !updateManager.includes('window.addEventListener("online", onOnline)')) {
  fail('automatic updater must recover promptly after offline/failed checks and connectivity returns');
}
if (!pwaUpdater.includes('PWA_UPDATE_DISCOVERED_EVENT') ||
    !pwaUpdater.includes('applyPwaUpdate') ||
    !viteConfig.includes('registerType: "prompt"')) {
  fail('PWA updates must wait for explicit user confirmation');
}
if (!appVersion.includes('__APP_VERSION_CODE__') || !viteConfig.includes('__APP_VERSION_CODE__') ||
    !settingsPanel.includes("import { APP_VERSION_NAME } from '@/lib/appVersion';") ||
    !settingsPanel.includes('App Version {APP_VERSION_NAME}')) {
  fail('installed app build version must be embedded from actual build metadata and displayed in Settings');
}
if (!releaseWorkflow.includes('actions/upload-artifact@v4') ||
    !releaseWorkflow.includes('MathMaster-update-feed') ||
    !releaseWorkflow.includes('updates/update.json') ||
    !releaseWorkflow.includes('expectedSha256.equalsIgnoreCase') ||
    !releaseWorkflow.includes('MATHMASTER_UPDATES_TOKEN') ||
    !releaseWorkflow.includes('name: Publish APK and update manifest to public update host') ||
    !releaseWorkflow.includes('https://raw.githubusercontent.com/${UPDATES_REPO}/main/updates/update.json?cacheBust=${GITHUB_SHA}')) {
  fail('signed APK and checksummed manifest must be published and verified on the separate public update host');
}
const notificationSendStepAt = releaseWorkflow.indexOf('name: Send new-release push notification through Firebase');
const notificationSendStepEnd = releaseWorkflow.indexOf('\n# [BUILD_APK]', notificationSendStepAt);
const notificationSendStep = releaseWorkflow.slice(notificationSendStepAt, notificationSendStepEnd);
if (!releaseWorkflow.includes('name: Verify published APK asset SHA-256 before push') ||
    !releaseWorkflow.includes('PUBLISHED_APK_URL}?cacheBust=${GITHUB_SHA}') ||
    !releaseWorkflow.includes('manifest["sha256"].lower() != sys.argv[4].lower()') ||
    !releaseWorkflow.includes('published-update.json")') ||
    !releaseWorkflow.includes('actual_sha256') ||
    !releaseWorkflow.includes('expected_sha256') ||
    !notificationSendStep.includes('node scripts/release-notification-sender.mjs') ||
    notificationSendStep.includes('continue-on-error: true')) {
  fail('release push must verify the actually published APK checksum and expose configured FCM failures to Actions');
}
const collectApkAt = releaseWorkflow.indexOf('name: Collect Universal release APK');
const uploadApkAt = releaseWorkflow.indexOf('name: Upload Universal release APK');
const publishReleaseAt = releaseWorkflow.indexOf('name: Publish latest GitHub Release APK');
const uploadFeedAt = releaseWorkflow.indexOf('name: Upload update feed bundle for hosting');
const publishPublicUpdateAt = releaseWorkflow.indexOf('name: Publish APK and update manifest to public update host');
if (!(collectApkAt >= 0 && uploadApkAt > collectApkAt &&
      publishReleaseAt > uploadApkAt && uploadFeedAt > publishReleaseAt &&
      publishPublicUpdateAt > uploadFeedAt)) {
  fail('APK, checksum manifest, and public update-host publication must run in the required order');
}
if (!releaseWorkflow.includes('request.setMimeType("application/octet-stream");') ||
    !releaseWorkflow.includes('DownloadManager.Request.VISIBILITY_VISIBLE') ||
    releaseWorkflow.includes('DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED')) {
  fail('APK downloads must be verified before the installer can be opened from a completion notification');
}

// The generated Android updater must reuse native DownloadManager jobs across
// activity/process restarts, and progress telemetry must be based on real byte samples.
const updateFeedCacheTests = read('src/lib/updateFeed.cache.test.ts');
if (!releaseWorkflow.includes('SharedPreferences preferences') ||
    !releaseWorkflow.includes('download_id_') ||
    !releaseWorkflow.includes('readDownloadStatus(manager, existingId)') ||
    !releaseWorkflow.includes('DownloadManager.STATUS_PAUSED') ||
    !releaseWorkflow.includes('expectedSha256.equalsIgnoreCase(previousSha)') ||
    !releaseWorkflow.includes('monitoredDownloads') ||
    !releaseWorkflow.includes('data.put("downloadedBytes"') ||
    !releaseWorkflow.includes('data.put("bytesPerSecond"') ||
    !releaseWorkflow.includes('new byte[64 * 1024]') ||
    !releaseWorkflow.includes('destinationFile.length() != total') ||
    !updateFeed.includes('RELEASE_MANIFEST_CACHE_TTL_MS = 15_000') ||
    !updateFeedCacheTests.includes('coalesces concurrent checks') ||
    !updateFeedCacheTests.includes('refreshes the manifest once the short cache lifetime expires')) {
  fail('APK download resume, identity matching, measured throughput, integrity and bounded metadata cache safeguards are missing');
}
const nativeUpdaterEvents = read('src/nativeAppUpdater.ts');
const updateManagerUi = read('src/components/AppUpdateManager.tsx');
const updateManagerPerformanceTests = read('src/components/AppUpdateManager.test.tsx');
if (!nativeUpdaterEvents.includes('downloadedBytes?: number') ||
    !nativeUpdaterEvents.includes('bytesPerSecond?: number') ||
    !updateManagerUi.includes('Math.min(99, event.progress)') ||
    !updateManagerUi.includes('describeDownloadMetrics(event)') ||
    !updateManagerPerformanceTests.includes('shows measured bytes and throughput, and caps progress below 100 while verification is running')) {
  fail('Download progress must report native byte counts/speed and stay below 100% until verification succeeds');
}

// Periodic ranges must be contiguous, non-overlapping, and end exactly at 118.
const rangesText = read('src/lib/periodicRanges.ts');
const ranges = [...rangesText.matchAll(
  /\{\s*from:\s*(\d+),\s*to:\s*(\d+),\s*label:\s*'([^']+)'\s*\}/g,
)].map(([, from, to, label]) => ({ from: Number(from), to: Number(to), label }));
if (!ranges.length || ranges[0].from !== 1) fail('periodic ranges do not start at element 1');
for (let i = 0; i < ranges.length; i += 1) {
  const range = ranges[i];
  if (range.from > range.to) fail(`invalid periodic range: ${range.label}`);
  if (i > 0 && range.from !== ranges[i - 1].to + 1) {
    fail(`periodic ranges overlap or contain a gap before ${range.label}`);
  }
}
if (ranges.at(-1)?.to !== 118) fail('periodic ranges do not end at element 118');


const trigTable = read('src/components/TrigonometryLearning.tsx');
const trigTableCss = read('src/components/trigonometry-table.css');
const trigData = read('src/lib/trigData.ts');
const trigPracticeMenu = read('src/components/FormulasLearning.tsx');
const trigPracticeTests = read('src/pages/PracticePage.trigRange.test.tsx');
const quizPage = read('src/pages/PracticePage.tsx');

if (!trigData.includes('export function getTrigAngles(proMode = false)') ||
    !trigData.includes('const STANDARD_TRIG_ANGLES: readonly TrigAngle[] = TRIG_ANGLES.filter((angle) => angle <= 90);')) {
  fail('Table and Quiz must share a canonical, dataset-derived Standard/Pro angle selector');
}
if (!trigTable.includes('getTrigAngles(showFullRange)')) {
  fail('Table of Angles must use the shared Standard/Pro angle selector');
}
if (!quizPage.includes('getTrigQuestions(range.trigFunctions ?? TRIG_FUNCTIONS, getTrigAngles(range.trigProMode === true))') ||
    !quizPage.includes('Trigonometry Quiz – Angle Range') ||
    !quizPage.includes('aria-label="Trigonometry quiz angle range"') ||
    !quizPage.includes("trigProMode: false")) {
  fail('Quiz setup range selection must drive the real generated question pool and default to Standard Mode');
}
if (!quizPage.includes('trigProMode: initialExtras?.trigProMode ?? false') ||
    !learning.includes('trigProMode: pendingTrigProMode') ||
    !learning.includes('count: pendingTrigFunctions.length * getTrigAngles(pendingTrigProMode).length') ||
    !trigPracticeMenu.includes('onPracticeTrigFunctions(selectedFunctions, trigProMode)') ||
    !trigPracticeMenu.includes('aria-label="Practice angle range"') ||
    !trigPracticeTests.includes('enforces Standard 0°–90° and Pro 0°–360° inside generated question pools')) {
  fail('Learning → Practice must carry the selected angle range from the popup into the real generator');
}
if (!trigTable.includes('trig-table-sticky') ||
    !trigTable.includes('trig-table-sticky-header') ||
    !trigTable.includes('trig-table-sticky-corner')) {
  fail('Table of Angles is missing the dedicated sticky first-column layers');
}
if (trigTable.includes('sticky left-0 bg-primary/15') ||
    trigTable.includes('sticky left-0 bg-primary/5')) {
  fail('Table of Angles sticky headers must not use translucent primary backgrounds');
}
if (!trigTable.includes('border-separate border-spacing-0') ||
    trigTable.includes('initial={{ opacity: 0, x: -10 }}') ||
    trigTable.includes('animate={{ opacity: 1, x: 0 }}')) {
  fail('Table of Angles must avoid collapsed-border/translated-row sticky paint conflicts');
}
if (!trigTableCss.includes('.trig-table-grid .trig-table-cell') ||
    !trigTableCss.includes('border-width: 0 1px 1px 0 !important') ||
    !trigTableCss.includes('border-top: 1px solid hsl(var(--border))')) {
  fail('Table of Angles must preserve single-line borders with separated sticky-compatible cells');
}
if (!trigTableCss.includes('background-color: hsl(var(--card)) !important') ||
    !trigTableCss.includes('background-color: hsl(var(--muted)) !important') ||
    !trigTableCss.includes('isolation: isolate') ||
    !trigTableCss.includes('z-index: 40')) {
  fail('Table of Angles sticky cells must keep opaque theme surfaces and correct z-index layering');
}

// Quiz startup/exit transition invariants.
const learningLaunchStart = index.indexOf('const handleStartPractice = useCallback(');
const learningLaunchEnd = index.indexOf('const clearPracticeState =', learningLaunchStart);
const learningLaunchHandler = index.slice(learningLaunchStart, learningLaunchEnd);
if (learningLaunchStart < 0 || learningLaunchEnd < 0 ||
    learningLaunchHandler.indexOf("setPracticePhase('starting');") < 0 ||
    learningLaunchHandler.indexOf("setPracticePhase('starting');") > learningLaunchHandler.indexOf("setTab('practice');")) {
  fail('Learning-origin Start Quiz must enter the startup phase before mounting PracticePage');
}
if (!practiceNavigation.includes("phase === 'starting' || phase === 'active'") ||
    !practiceNavigation.includes("phase === 'starting' || phase === 'active' || phase === 'finished'") ||
    !practiceNavigation.includes("if (phase === 'starting' || phase === 'active') return 'practice-active';")) {
  fail('Quiz startup must hide the Floating Bar and keep startup/active history depth stable');
}
if (!practice.includes("useLayoutEffect(() => {\n    if (initialTopic && initialMode) {")) {
  fail('Learning-origin Quiz session must initialize before paint to prevent setup screen flash');
}
const exitConfirmStart = practice.indexOf('const handleExitConfirmed = useCallback(() => {');
const exitConfirmEnd = practice.indexOf('const handleExitRequest = useCallback', exitConfirmStart);
const exitConfirmHandler = practice.slice(exitConfirmStart, exitConfirmEnd);
if (exitConfirmStart < 0 || exitConfirmEnd < 0 ||
    !exitConfirmHandler.includes('if (fromLearning && onExit)') ||
    !exitConfirmHandler.includes('clearSessionTimers();\n      onExit();')) {
  fail('Learning-origin Quiz exit must clean timers and navigate directly without rendering Quiz setup first');
}
const backRequestEffectStart = practice.indexOf('const request = externalBackRequest ?? 0;');
const backRequestEffectEnd = practice.indexOf('}, [externalBackRequest,', backRequestEffectStart);
const backRequestEffect = practice.slice(backRequestEffectStart, backRequestEffectEnd);
const startupBackGuardIndex = backRequestEffect.indexOf('if (!config || finished) return;');
const activeSessionRequestMarkIndex = backRequestEffect.indexOf('lastExternalBackRequestRef.current = request;', startupBackGuardIndex);
if (startupBackGuardIndex < 0 ||
    activeSessionRequestMarkIndex < startupBackGuardIndex ||
    !backRequestEffect.includes("if (gameSelectionOpen && mode === 'game' && !config)")) {
  fail('Back requests during Quiz startup must remain pending while the explicit game selector handles its own navigation');
}

// Challenge Timer must share one exclusive mode and one lifecycle-controlled clock.
const practiceConfigStart = practice.indexOf('interface PracticeConfig {');
const practiceConfigEnd = practice.indexOf('type AnswerType', practiceConfigStart);
const practiceConfig = practice.slice(practiceConfigStart, practiceConfigEnd);
if (practiceConfigStart < 0 || practiceConfigEnd < 0 ||
    !practiceConfig.includes('timerMode: QuizTimerMode;') ||
    practiceConfig.includes('timerEnabled: boolean;')) {
  fail('Quiz timer configuration must use one mutually exclusive timerMode source of truth');
}
const quizTimer = read('src/lib/quizTimer.ts');
if (!quizTimer.includes('CHALLENGE_MINUTES = [1, 2, 3, 4, 5, 10]') ||
    !quizTimer.includes('getRemainingSeconds') ||
    !quizTimer.includes('getTimerModeFromToggle')) {
  fail('Challenge durations, deadline calculation, and timer-mode switching must use shared tested helpers');
}
if (!practice.includes("config.timerMode === 'challenge'") ||
    !practice.includes("config.timerMode === 'perQuestion' && config.timerSeconds < 9999") ||
    !practice.includes('getRemainingSeconds(deadline, performance.now())') ||
    !practice.includes('performance.now() >= challengeDeadlineRef.current')) {
  fail('Challenge expiry and per-question timeout must be isolated within the shared session clock');
}
if (!practice.includes('Solved {totalAttempts}') ||
    !practice.includes("config.timerMode === 'challenge' ? 'Solved' : 'Attempted'") ||
    !practice.includes('challengeDeadlineRef.current = null;')) {
  fail('Challenge solved count, result labeling, and timer deadline cleanup are required');
}

// Challenge mode disables fixed question-count controls and overrides their pool lifetime.
if (!quizTimer.includes('isQuestionCountSelectionDisabled') ||
    !quizTimer.includes('shouldUseInfiniteQuestionPool')) {
  fail('Challenge question-count availability and time-based pool lifetime must use shared helpers');
}
if (!practice.includes('const questionCountDisabled = isQuestionCountSelectionDisabled(repetitionEnabled, timerMode);') ||
    (practice.match(/disabled={questionCountDisabled}/g) || []).length < 2 ||
    !practice.includes('if (questionCountDisabled) return;')) {
  fail('All fixed Questions buttons must be natively disabled and protected by click guards during Challenge');
}
if (!practice.includes('shouldUseInfiniteQuestionPool(cfg.timerMode, cfg.repetitionEnabled, cfg.infinite)') ||
    !practice.includes("const isFiniteQuiz = config.timerMode !== 'challenge' &&")) {
  fail('Challenge must use a recyclable question pool and finish by its timer, not fixed question count');
}

// Quiz Tables Pro Mode must reuse Learning's persistent setting and question generator.
const tableQuestionTests = read('src/test/practiceQuestionGeneration.test.ts');
const tableRangeUiTests = read('src/pages/PracticePage.trigRange.test.tsx');
if (!practice.includes('getTablesProMode, setTablesProMode') ||
    !practice.includes('aria-label="Tables Pro Mode"') ||
    !practice.includes("const proMax = getTablesProMode() ? 20 : 10") ||
    !practice.includes("window.addEventListener('tables-pro-updated', syncTablesProMode)")) {
  fail('Quiz Tables Pro Mode must reuse the shared persisted setting and keep its compact range toggle synchronized');
}
if (!tableQuestionTests.includes('uses the shared Tables Standard/Pro mode for the exact selected table range') ||
    !tableRangeUiTests.includes('uses the shared Learning/Quiz Pro Mode setting from the Tables range panel')) {
  fail('Quiz Tables Pro Mode must cover both actual generated question ranges and UI setting synchronization');
}

// Release versioning must be centralized, idempotent, and shared by both APK workflows.
const releaseVersion = read('scripts/release-version.mjs');
const releaseVersionTests = read('scripts/release-version.test.mjs');
const releaseWorkflowVersion = read('.github/workflows/android-release.yml');
const manualApkWorkflow = read('.github/workflows/android-apk.yml');
const viteConfigVersion = read('vite.config.ts');
const settingsPanelVersion = read('src/components/SettingsPanel.tsx');
const settingsPanelVersionTests = read('src/components/SettingsPanel.test.tsx');
if (!releaseVersion.includes('parsePublishedRelease') ||
    !releaseVersion.includes('resolveNextReleaseVersion') ||
    !releaseVersion.includes('reusedForSameCommit') ||
    !releaseVersion.includes('merge-base') ||
    !releaseVersionTests.includes('re-running the same commit reuses its published version') ||
    !releaseVersionTests.includes('refuses to overwrite a newer release with an older or divergent source commit')) {
  fail('Automatic release versioning must preserve the real published baseline, handle retries idempotently, and reject stale source commits');
}
for (const [label, workflow] of [
  ['Android Release APK', releaseWorkflowVersion],
  ['Android APK', manualApkWorkflow],
]) {
  if (!workflow.includes('node scripts/release-version.mjs') ||
      !workflow.includes('node --test scripts/release-version.test.mjs') ||
      workflow.includes('VERSION_NAME: "1.0"') ||
      workflow.includes('EXPECTED_VERSION_CODE="$(git rev-list --count HEAD)"')) {
    fail(label + ' must use the shared tested release version resolver rather than hardcoded or commit-count versions');
  }
}
if (!releaseWorkflowVersion.includes('versionName: %s') ||
    !releaseWorkflowVersion.includes('sourceCommit: %s') ||
    !releaseWorkflowVersion.includes('signingCertificateSHA256: %s') ||
    !releaseWorkflowVersion.includes('681A1EEB65E63DB5CCDF01748A27AA0045033E5C3C5D0C29ED16EE0D35769B64') ||
    releaseWorkflowVersion.indexOf('Verify APK identity, version, signature and installability') >
      releaseWorkflowVersion.indexOf('Publish latest GitHub Release APK')) {
  fail('Published APK metadata must record its source/version/certificate and only publish after successful signature verification');
}
if (!viteConfigVersion.includes('process.env.VITE_APP_VERSION_CODE') ||
    !viteConfigVersion.includes('process.env.VITE_APP_VERSION_NAME') ||
    !settingsPanelVersion.includes("import { APP_VERSION_NAME } from '@/lib/appVersion';") ||
    !settingsPanelVersion.includes('App Version {APP_VERSION_NAME}') ||
    !settingsPanelVersionTests.includes('keeps the installed App Version visible in Settings')) {
  fail('Settings must display the same versionName injected into Vite and the Android release');
}

// Automatic update alert lifecycle and safe APK verification.
const updateManagerSource = read('src/components/AppUpdateManager.tsx');
const updateManagerTests = read('src/components/AppUpdateManager.test.tsx');
const updateOrderingSource = read('src/lib/updateVersion.ts');
if (!updateManagerSource.includes('dismissedVersionCode = useRef(0)') ||
    !updateManagerSource.includes('safeCandidate.versionCode <= dismissedVersionCode.current') ||
    updateManagerSource.includes('localStorage.getItem("mathmaster.dismissed-update-version-code")')) {
  fail('"Later" must suppress duplicate alerts only for the current app session, not permanently across launches');
}
if (!updateManagerSource.includes('App.addListener("resume", checkOnForeground)') ||
    !updateManagerSource.includes('document.addEventListener("visibilitychange", checkOnForeground)') ||
    !updateManagerSource.includes('runCheck(false, false, true)') ||
    !updateManagerSource.includes('FOREGROUND_EVENT_DEDUPE_MS')) {
  fail('Update checks must refresh on native resume/web foreground while deduplicating one lifecycle transition');
}
if (updateManagerSource.includes('Version <span className="font-display">v{update.versionName}</span>') ||
    updateManagerSource.includes('update.versionName') ||
    updateManagerSource.includes('Current version:') ||
    updateManagerSource.includes('update.releaseNotes') ||
    !updateManagerSource.includes('New Update Available') ||
    !updateManagerSource.includes('actionInFlight.current') ||
    !updateManagerSource.includes('downloadAppUpdate')) {
  fail('Update alert must not render any version metadata and must guard duplicate update/download actions');
}
if (!updateManagerTests.includes('dismisses only for the current app session') ||
    !updateManagerTests.includes('starts Update Now only when selected') ||
    !updateManagerTests.includes('downloads a verified APK to Downloads only when selected') ||
    !updateManagerTests.includes('shows a version-free update alert and both update choices') ||
    !updateManagerTests.includes('closes through the existing close icon')) {
  fail('Compact version-free update alert needs tests for session dismissal, close, and separate install/download actions');
}
if (!updateOrderingSource.includes('latestCodeValid && currentCodeValid) return latest.versionCode! > current.versionCode!') ||
    !updateOrderingSource.includes('Semantic comparison is a compatibility fallback only')) {
  fail('versionCode must be authoritative when available, with semantic version fallback only when build codes are missing');
}
const apkVerifierStart = releaseWorkflowVersion.indexOf('new Thread(() -> {');
const apkHashCheck = releaseWorkflowVersion.indexOf('expectedSha256.equalsIgnoreCase(actualSha256)', apkVerifierStart);
const apkInstallerPost = releaseWorkflowVersion.indexOf('mainHandler.post(() -> {', apkHashCheck);
if (apkVerifierStart < 0 || apkHashCheck < apkVerifierStart || apkInstallerPost < apkHashCheck ||
    !releaseWorkflowVersion.includes('"MathApp-APK-verifier"') ||
    !releaseWorkflowVersion.includes('if (apkUri == null || !destinationFile.isFile()')) {
  fail('Downloaded APK checksum must run off the UI thread and the Android installer must only open after verification');
}

const nativeUpdaterSource = read('src/nativeAppUpdater.ts');
const updateFeedSource = read('src/lib/updateFeed.ts');
if (!nativeUpdaterSource.includes('versionCode: update.versionCode') ||
    !releaseWorkflowVersion.includes('Integer expectedVersionCode = call.getInt("versionCode");') ||
    !releaseWorkflowVersion.includes('getPackageArchiveInfo(destinationFile.getAbsolutePath(), packageFlags)') ||
    !releaseWorkflowVersion.includes('downloadedInfo.packageName') ||
    !releaseWorkflowVersion.includes('downloadedVersionCode != expectedVersionCode.longValue()') ||
    !releaseWorkflowVersion.includes('sameSigningCertificate(installedInfo, downloadedInfo)') ||
    !releaseWorkflowVersion.includes('saveVerifiedApkToDownloads(destinationFile, publicName, expectedSha256)') ||
    !releaseWorkflowVersion.includes('MediaStore.Downloads.EXTERNAL_CONTENT_URI') ||
    !releaseWorkflowVersion.includes('downloadToDownloads(PluginCall call)') ||
    !releaseWorkflowVersion.includes('androidx.core.content.FileProvider') ||
    !releaseWorkflowVersion.includes('math_app_update_paths.xml') ||
    !releaseWorkflowVersion.includes('<external-path name="public_downloads" path="Download/"/>') ||
    !releaseWorkflowVersion.includes('notifyDownloadState(downloadId, "paused"') ||
    releaseWorkflowVersion.includes('attempts++ > 900')) {
  fail('Native updater must verify package, version, signing identity and support verified APK files in public Downloads');
}
if (!updateFeedSource.includes('Number(data.versionCode) > 2100000000')) {
  fail('Update metadata must reject versionCodes outside Android supported bounds');
}

// Notification reliability: verify that a local reminder schedule is only
// reported as successful when Android actually accepted a pending alarm, and
// that remote push payloads respect the user's preference in the native service.
const reminderBridgeSource = read('src/lib/dailyTargetReminders.ts');
const reminderPluginSource = read('android-native/com/sudhanshu/mathsbj/DailyTargetReminderPlugin.java');
const reminderReceiverSource = read('android-native/com/sudhanshu/mathsbj/DailyTargetReminderReceiver.java');
const updateMessagingSource = read('android-native/com/sudhanshu/mathsbj/MathMasterMessagingService.java');
const updateBootReceiverSource = read('android-native/com/sudhanshu/mathsbj/DailyTargetReminderBootReceiver.java');
const releaseNotificationSenderSource = read('scripts/release-notification-sender.mjs');
const releaseNotificationTestsSource = read('scripts/release-notification-sender.test.mjs');
if (!reminderPluginSource.includes('result.put("synced", syncSucceeded)') ||
    !reminderPluginSource.includes('DailyTargetReminderReceiver.scheduleNext(getContext())') ||
    !reminderReceiverSource.includes('public static boolean scheduleNext(Context context)') ||
    !reminderReceiverSource.includes('Log.w(TAG, "Alarm scheduling failed: Android AlarmManager is unavailable.")') ||
    !reminderBridgeSource.includes('syncResult.synced !== true')) {
  fail('Daily reminder opt-in must not be acknowledged unless native Android confirms that the next alarm is scheduled');
}
if (!reminderBridgeSource.includes('DAILY_REMINDER_POLICY_VERSION = 3') ||
    !reminderBridgeSource.includes('9 * 60') ||
    !reminderBridgeSource.includes('22 * 60') ||
    !reminderReceiverSource.includes('REMINDER_POLICY_VERSION = 3') ||
    !reminderReceiverSource.includes('540, 600, 660, 720, 780, 840, 900, 960, 1020, 1080, 1140') ||
    !reminderReceiverSource.includes('1185, 1230, 1260, 1290, 1310, 1320') ||
    !reminderReceiverSource.includes('candidate.equals(previousText)') ||
    !reminderReceiverSource.includes('RANDOM.nextBoolean()') ||
    !reminderReceiverSource.includes('putString("marathiMessagesJson", "[]")') ||
    !reminderReceiverSource.includes('putString("hindiMessagesJson", "[]")')) {
  fail('Daily target reminders must use the migrated 17-stage 9 AM–10 PM schedule, independent random language selection, anti-repeat logic, and safe old-message migration');
}
if (!releaseNotificationSenderSource.includes("topic: 'math_app_updates'") ||
    !releaseNotificationSenderSource.includes("type: 'app_update'") ||
    !releaseNotificationSenderSource.includes("title: 'New Update Available'") ||
    !releaseNotificationSenderSource.includes("const body = 'A new version of Math Master is ready. Update now to enjoy the latest improvements.';") ||
    !releaseNotificationTestsSource.includes('assert.equal(payload.notification, undefined)') ||
    !releaseNotificationTestsSource.includes('version-free update notification') ||
    !releaseNotificationTestsSource.includes('payload.data.versionName, release.versionName') ||
    !updateMessagingSource.includes('.getBoolean("updateAlertsEnabled", false)') ||
    !updateMessagingSource.includes('if (!enabled)') ||
    !updateMessagingSource.includes('Ignoring update push with invalid release metadata.') ||
    !updateMessagingSource.includes('UPDATE_NOTIFICATION_TITLE = "New Update Available"') ||
    !updateMessagingSource.includes('UPDATE_NOTIFICATION_BODY = "A new version of Math Master is ready. Update now to enjoy the latest improvements."') ||
    !updateMessagingSource.includes('.setContentTitle(UPDATE_NOTIFICATION_TITLE)') ||
    !updateMessagingSource.includes('.setContentText(UPDATE_NOTIFICATION_BODY)') ||
    !updateMessagingSource.includes('new Notification.BigTextStyle().bigText(UPDATE_NOTIFICATION_BODY)') ||
    updateMessagingSource.includes('"New Version " + versionName') ||
    !updateMessagingSource.includes('manager.notify("mathmaster-update", NOTIFICATION_ID, notification)') ||
    !updateMessagingSource.includes('Update notification was not posted because app-level notifications are disabled.') ||
    !updateMessagingSource.includes('existing.getImportance() == NotificationManager.IMPORTANCE_NONE') ||
    !updateBootReceiverSource.includes('cancelStaleUpdateNotifications(context)') ||
    !updateBootReceiverSource.includes('"mathmaster-update".equals(tag)') ||
    !updateBootReceiverSource.includes('"mathapp-apk-saved".equals(tag)') ||
    !updateBootReceiverSource.includes('manager.cancel(tag, notification.getId())') ||
    !updateBootReceiverSource.includes('Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)') ||
    !releaseNotificationTestsSource.includes('Android update notification and APK-save copy stay version-free') ||
    !releaseWorkflowVersion.includes('String publicName = "MathApp.apk"') ||
    !reminderReceiverSource.includes('NotificationManagerCompat.from(context).areNotificationsEnabled()') ||
    !reminderReceiverSource.includes('existing.getImportance() == NotificationManager.IMPORTANCE_NONE') ||
    !reminderReceiverSource.includes('actual device presentation is not observable here')) {
  fail('Release alerts must be version-free, data-only, opt-in aware, replacement-safe, and clear stale update-only notifications');
}

// Quiz countdown progress must use the active timer deadline and leave the overall quiz bar intact.
const questionTimerPage = read('src/pages/PracticePage.tsx');
const questionTimerHelpers = read('src/lib/quizTimer.ts');
const questionTimerTests = read('src/lib/quizTimer.test.ts');
const questionTimerUiTests = read('src/pages/PracticePage.quizSetup.test.tsx');
const questionTimerStyles = read('src/index.css');
if (!questionTimerPage.includes('questionDeadlineRef') ||
    !questionTimerPage.includes('getTimerProgressPercent(') ||
    !questionTimerPage.includes('aria-label="Question timer"') ||
    !questionTimerPage.includes('transformOrigin: \'right center\'') ||
    !questionTimerPage.includes('animationDuration: `${countdownDurationSeconds}s`') ||
    !questionTimerPage.includes('questionDeadlineRef.current = config.timerSeconds < 9999') ||
    !questionTimerPage.includes('const isCountdownProgressVisible = isQuestionTimerActive || config.timerMode === \'challenge\'') ||
    !questionTimerPage.includes('data-testid="quiz-overall-progress"')) {
  fail('Quiz countdown must follow the existing per-question/challenge deadline, shrink from the right, reset with each question, and preserve overall progress');
}
if (!questionTimerHelpers.includes('export function getTimerProgressPercent(') ||
    !questionTimerTests.includes('converts the active timer deadline into a clamped percentage') ||
    !questionTimerTests.includes('safely handles missing deadlines and invalid duration values') ||
    !questionTimerTests.includes('expect(getTimerProgressPercent(deadline, 10_000, 8_000)).toBe(20)')) {
  fail('Countdown percentage calculation needs deadline-based 100/80/50/20/0 and invalid-input regression tests');
}
if (!questionTimerUiTests.includes('uses the active countdown deadline, retains overall quiz progress, and resets on the next question') ||
    !questionTimerUiTests.includes('does not render a countdown bar when the timer mode is off') ||
    !questionTimerUiTests.includes('animationDuration: \'10s\'')) {
  fail('Quiz timer UI needs timer-sync, question-reset, original progress bar, and timer-off coverage');
}
if (!questionTimerStyles.includes('@media (prefers-reduced-motion: no-preference)') ||
    !questionTimerStyles.includes('transform-origin: right center') ||
    !questionTimerStyles.includes('question-timer-progress-shrink')) {
  fail('Countdown animation must shrink from the right and respect reduced-motion settings');
}

// Theme boot/switch must apply one validated appearance before first paint.
const themeModule = read('src/lib/theme.ts');
const themeHtml = read('index.html');
const themeBootstrapCss = read('src/index.css');
const themeTests = read('src/lib/theme.test.ts');
const themeHydrationTests = read('src/lib/themeHydration.test.ts');
const themeTypeBlock = themeModule.match(/export type ThemeId =([\s\S]*?);/)?.[1] ?? '';
const bootstrapThemeBlock = themeHtml.match(/const themeIds = \[([\s\S]*?)\];/)?.[1] ?? '';
const declaredThemeIds = [...themeTypeBlock.matchAll(/'([a-z-]+)'/g)].map((match) => match[1]);
const bootstrapThemeIds = [...bootstrapThemeBlock.matchAll(/'([a-z-]+)'/g)].map((match) => match[1]);
if (declaredThemeIds.length === 0 ||
    declaredThemeIds.some((id) => !bootstrapThemeIds.includes(id)) ||
    bootstrapThemeIds.some((id) => !declaredThemeIds.includes(id))) {
  fail('First-paint theme bootstrap IDs must exactly match the runtime theme union');
}
const parseLegacyThemeMap = (source, pattern) => {
  const block = source.match(pattern)?.[1] ?? '';
  return [...block.matchAll(/'([^']+)': '([^']+)'/g)]
    .map((match) => match[1] + ':' + match[2])
    .sort()
    .join('|');
};
if (parseLegacyThemeMap(themeModule, /const LEGACY_THEME_MAP: Record<string, ThemeId> = \{([\s\S]*?)\n\};/) !==
    parseLegacyThemeMap(themeHtml, /const legacyThemes = \{([\s\S]*?)\n        \};/)) {
  fail('Legacy saved-theme aliases must resolve identically before first paint and at runtime');
}
if (!themeHtml.includes('class="theme-arctic-blue dark"') ||
    themeHtml.indexOf('const themeIds = [') > themeHtml.indexOf('<script type="module" src="/src/main.tsx"></script>') ||
    !themeHtml.includes('root.dataset.mode = mode') ||
    !themeModule.includes('getMode = (): ModeId => currentMode') ||
    !themeModule.includes('persistModeSoon();') ||
    !themeModule.includes('applyAppearanceSnapshot(currentTheme, currentMode, true)') ||
    !themeBootstrapCss.includes('html.theme-appearance-updating *::before') ||
    !themeBootstrapCss.includes('transition-duration: 0ms !important;')) {
  fail('Theme switching must be memory-backed, atomic, pre-bootstrapped, and suppress color transitions only during the switch');
}
for (const testName of [
  'applies mode and selected theme atomically before persistence completes',
  'keeps only the latest choice after rapid repeated switches',
  'continues switching when localStorage writes throw',
  'falls back to safe defaults for unsupported runtime values',
  'keeps theme subscribers isolated from mode-only updates',
]) {
  if (!themeTests.includes(testName)) fail('Missing theme-switch regression case: ' + testName);
}


if (!themeHydrationTests.includes('hydrates saved premium theme and appearance before app initialization')) {
  fail('Saved appearance and selected premium theme need first-load hydration coverage');
}


const percentagePresets = read('src/lib/percentagePresets.ts');
if (!practice.includes('pctPresetIds?: string[]') ||
    !practice.includes('togglePercentagePresetRange') ||
    !practice.includes('setTopicRanges((previous) => {')) {
  fail('Percentage preset selection must use a collection and functional state updates');
}
if (!practice.includes('aria-pressed={isSelected}') ||
    !practice.includes('PERCENTAGE_PRESETS.map((preset) =>') ||
    !practice.includes('Select at least one preset range to start.')) {
  fail('Percentage preset UI must expose independent pressed states and empty-selection guidance');
}
if (!practice.includes('resolvePercentagePresets(range).length > 0') ||
    !practice.includes("range.pctRangeMode === 'preset'") ||
    !practice.includes('percentagePresetId?: PercentagePresetId')) {
  fail('Percentage preset validation and question-source identities are missing');
}
if (!practice.includes('selectQuestionsAcrossPresetRanges(questionCandidates, config.count, config.sequential)') ||
    !practice.includes('selectQuestionsWithPresetCoverage(questionCandidates, config.count, selectedPresetIds, config.sequential)')) {
  fail('Finite quizzes must retain question coverage for every selected Percentage preset after mode-specific filtering');
}
if (!percentagePresets.includes('normalizePercentagePresetIds') ||
    !percentagePresets.includes('togglePercentagePresetIds') ||
    !percentagePresets.includes('resolvePercentagePresets')) {
  fail('Shared Percentage preset normalization/toggle/resolve helpers are missing');
}

const quizRetryQueue = read('src/lib/quizRetryQueue.ts');
const quizRetryTests = read('src/test/quizRetryQueue.test.ts');
if (!practice.includes('questionsRef.current = nextQueue') ||
    !practice.includes('ensureOutstandingQuestionRetries') ||
    !practice.includes('shouldFinishQuestionQueue') ||
    !practice.includes('getQuizCompletionPercent(completedQuestionIds.size, originalQuestionCount)') ||
    !practice.includes('data-testid="quiz-repetition-results"')) {
  fail('Quiz Repetition must retry wrong identities, keep completion progress stable, and wait for completion');
}
if (!quizRetryQueue.includes('at most one pending retry per identity') ||
    !quizRetryQueue.includes('ensureOutstandingQuestionRetries') ||
    !quizRetryQueue.includes('getQuizCompletionPercent') ||
    !quizRetryQueue.includes('completedCount >= originalQuestionCount') ||
    !quizRetryTests.includes('does not create duplicate pending retry entries') ||
    !quizRetryTests.includes('requeues a retry after another wrong attempt')) {
  fail('Quiz retry lifecycle tests or core queue safeguards are missing');
}

const percentageCustomUiTests = read('src/pages/PracticePage.percentageCustom.test.tsx');
const percentageCustomTests = read('src/test/percentagePresetSelection.test.ts');
if (!practice.includes('pctNumFrom: current.pctNumFrom ?? 1') ||
    !practice.includes('pctDenFrom: current.pctDenFrom ?? 2') ||
    !practice.includes("e.target.value === '' ? undefined : Number(e.target.value)") ||
    !practice.includes('No questions could be generated for') ||
    !practice.includes('quizStartLockRef.current')) {
  fail('Percentage Custom defaults must be canonicalized, empty inputs validated, empty-pool failures surfaced, and duplicate starts guarded');
}
if (!percentageCustomUiTests.includes('persists the displayed defaults, accepts a valid edit, and launches the quiz') ||
    !percentageCustomUiTests.includes('treats a genuinely empty input as invalid') ||
    !percentageCustomTests.includes('validates custom Percentage bounds, empties, and ascending semantics') ||
    !percentageCustomTests.includes('generates all fractions for the selected custom range and ignores stale preset IDs')) {
  fail('Percentage Custom range UI/generator regression coverage is missing');
}

const digitMultiSelectUiTests = read('src/pages/PracticePage.digitMultiSelect.test.tsx');
const digitMultiSelectGeneratorTests = read('src/test/practiceQuestionGeneration.test.ts');
if (!practice.includes('operand1DigitCounts?: number[]') ||
    !practice.includes('getSelectedDigitCounts(range, 1)') ||
    !practice.includes('selectQuestionsWithDigitCoverage(questionCandidates, config.count, config.sequential)') ||
    !practice.includes('grid grid-cols-5 gap-1 sm:gap-1.5') ||
    !practice.includes('{digits}D') ||
    !digitMultiSelectUiTests.includes('selects multiple digits independently') ||
    !digitMultiSelectUiTests.includes('requires at least one selected digit') ||
    !digitMultiSelectGeneratorTests.includes('validates and generates every selected digit-count combination')) {
  fail('Quiz +/- must keep compact multi-select controls, independent digit ranges, fair question coverage, and regression tests');
}


const backupService = read('src/lib/backupRestore.ts');
const backupPanel = read('src/components/BackupRestorePanel.tsx');
const backupNative = read('android-native/com/sudhanshu/mathsbj/BackupRestorePlugin.java');
const backupSetup = read('scripts/configure-android-notifications.mjs');
if (!backupService.includes('BACKUP_FORMAT_VERSION = 1') ||
    !backupService.includes('Backup integrity check failed') ||
    !backupService.includes('Could not verify restored record') ||
    !backupPanel.includes('Restore & Replace') ||
    !backupNative.includes('Intent.ACTION_CREATE_DOCUMENT') ||
    !backupNative.includes('Intent.ACTION_OPEN_DOCUMENT') ||
    !backupSetup.includes("'BackupRestorePlugin.java'") ||
    !backupSetup.includes('registerPlugin(BackupRestorePlugin.class);')) {
  fail('Backup & Restore must retain format/checksum validation, read-back verification, confirmation and Android SAF wiring');
}

const studyModeSchedule = read('src/lib/studyModeSchedule.ts');
const studyModeScheduleTests = read('src/lib/studyModeSchedule.test.ts');
const studyModePage = read('src/components/StudyModePage.tsx');
const studyModeBridge = read('src/lib/studyMode.ts');
const studyModeManager = read('android-native/com/sudhanshu/mathsbj/StudyModeManager.java');
const studyModeFocus = read('android-native/com/sudhanshu/mathsbj/StudyModeFocusService.java');
const screenTimeIslandDayUsage = read('android-native/com/sudhanshu/mathsbj/StudyModeDayUsage.java');
const screenTimeIslandSpring = read('android-native/com/sudhanshu/mathsbj/ScreenTimeIslandSpring.java');
const screenTimeIslandPainter = read('android-native/com/sudhanshu/mathsbj/ScreenTimeIslandPainter.java');
const screenTimeIslandOverlay = read('android-native/com/sudhanshu/mathsbj/ScreenTimeIslandOverlay.java');
const screenTimeIslandJvmTests = read('tools/island-preview/StudyModeDayUsageTest.java');
const studyModeUsageAccumulator = read('android-native/com/sudhanshu/mathsbj/StudyModeUsageAccumulator.java');
const studyModeWindowRegistry = read('android-native/com/sudhanshu/mathsbj/StudyModeWindowRegistry.java');
const studyModeAccessibilityService = read('android-native/com/sudhanshu/mathsbj/StudyModeAccessibilityService.java');
const studyModeSessionStore = read('android-native/com/sudhanshu/mathsbj/StudyModeSessionStore.java');
const studyModeAppPlugin = read('android-native/com/sudhanshu/mathsbj/StudyModePlugin.java');
const studyModeAppCatalogCache = read('src/lib/studyModeAppCatalogCache.ts');
const studyModeAppCatalogCacheTests = read('src/lib/studyModeAppCatalogCache.test.ts');
const studyModePackageReceiver = read('android-native/com/sudhanshu/mathsbj/StudyModePackageChangeReceiver.java');
const studyModeAlarmReceiver = read('android-native/com/sudhanshu/mathsbj/StudyModeAlarmReceiver.java');
const studyModeAppFilters = read('src/lib/studyModeAppFilters.ts');
const studyModeAppFilterTests = read('src/lib/studyModeAppFilters.test.ts');
const studyModeSetup = read('scripts/configure-android-study-mode.mjs');
const widgetSetup = read('scripts/configure-android-widgets.mjs');
const validationWorkflow = read('.github/workflows/validation.yml');
const studyModeSettings = read('src/components/SettingsPanel.tsx');
const studyModeIndex = read('src/pages/Index.tsx');
const studyModeDeepLink = read('src/lib/studyModeDeepLink.ts');
const studyModeDeepLinkTests = read('src/lib/studyModeDeepLink.test.ts');
const studyModeBoot = read('android-native/com/sudhanshu/mathsbj/DailyTargetReminderBootReceiver.java');
if (studyModeFocus.includes('Back to Math Master') ||
    studyModeFocus.includes('mathmaster://learn') ||
    !studyModeFocus.includes('StudyModeManager.getNextMotivationalQuote(this)') ||
    !studyModeFocus.includes('StudyModeManager.getCurrentSessionRemainingSeconds(this)') ||
    !studyModeFocus.includes('StudyModeManager.getCurrentSessionEndMillis(this)') ||
    !studyModeFocus.includes('StudyModeManager.launchStudyApp(StudyModeFocusService.this, packageName)') ||
    !index.includes("App.addListener('appUrlOpen'") ||
    !index.includes('App.getLaunchUrl()') ||
    !index.includes('openLearningFromStudyShield') ||
    !index.includes('setLearningState(INITIAL_LEARNING_STATE)') ||
    !studyModeDeepLink.includes('url.protocol === "mathmaster:"') ||
    !studyModeDeepLink.includes('url.hostname === "learn"') ||
    !studyModeDeepLinkTests.includes("accepts only the app's exact Learning destination") ||
    !studyModeDeepLinkTests.includes('rejects unrelated or modified destination')) {
  fail('Study Shield popup must omit navigation while preserving the native quote, session timer, Study Apps launcher, and safe deep-link routing');
}

if (!studyModeSettings.includes('<StudyModePage onBack={() => setStudyModeOpen(false)} />') ||
    !studyModeSettings.includes('onClick={() => setStudyModeOpen(true)}') ||
    !studyModePage.includes('aria-label="Study Mode master switch"') ||
    studyModePage.indexOf('aria-label="Study Mode master switch"') > studyModePage.indexOf('>Blocked Apps</span>') ||
    !studyModePage.includes('chooseStudyModeTime') ||
    !studyModePage.includes('profileOwner === true') ||
    !studyModePage.includes('status?.activeSession?.active') ||
    !studyModePage.includes('aria-label={day.name}') ||
    !studyModeIndex.includes('studyModePageOpen.current') ||
    !studyModeIndex.includes("new CustomEvent('study-mode-back')")) {
  fail('Study Mode settings entry, middle master control, native time/day controls, or Back navigation are missing');
}

const studyModeSwitchIndex = studyModePage.indexOf('aria-label="Study Mode master switch"');
const studyModeSaveIndex = studyModePage.indexOf('min-h-9 min-w-[76px]', studyModeSwitchIndex);
const studyModeHeroGridIndex = studyModePage.indexOf('className="study-mode-focus-summary', studyModeSwitchIndex);
if (!studyModePage.includes('useLayoutEffect(() => {') ||
    !studyModePage.includes('study-mode-page-state", { detail: { open: true }') ||
    !studyModePage.includes('aria-label={backLabel}') ||
    studyModeSwitchIndex < 0 ||
    studyModeSaveIndex <= studyModeSwitchIndex ||
    studyModeHeroGridIndex <= studyModeSaveIndex ||
    !studyModePage.includes('study-mode-primary-grid--active') ||
    !studyModePage.includes('study-mode-session-card') ||
    !studyModePage.includes('study-mode-app-card__saved-label') ||
    !studyModePage.includes('study-mode-schedule-times') ||
    /(?:^|\s)grid-cols-(?:2|5)(?:\s|")/.test(studyModePage) ||
    !css.includes('.study-mode-app-card__summary') ||
    !css.includes('html.desktop-mode .study-mode-primary-grid') ||
    !css.includes('@media (min-width: 768px) and (orientation: landscape)') ||
    !studyModePage.includes('Save Study Mode settings') ||
    studyModePage.includes('sticky bottom-0 z-20 -mx-1') ||
    !studyModePage.includes('if (saving || saveInFlightRef.current) return;') ||
    !studyModePage.includes('saveInFlightRef.current = true;') ||
    !studyModePage.includes('saveInFlightRef.current = false;')) {
  fail('Study Mode must hide the Floating Bar before paint and keep a compact, duplicate-safe Save action beside the master switch');
}

if (!studyModeSchedule.includes('isStudyModeScheduledAt') ||
    !studyModeSchedule.includes('getNextStudyModeTransition') ||
    !studyModeSchedule.includes('Overnight sessions belong to the day') ||
    !studyModeScheduleTests.includes('Friday overnight session') ||
    !studyModeScheduleTests.includes('includes the start boundary and excludes the end boundary') ||
    !studyModeBridge.includes('registerPlugin<NativeStudyModePlugin>("StudyMode")') ||
    !studyModeBridge.includes('initializeStudyMode')) {
  fail('Study Mode schedule engine, overnight boundaries, tests, or native bridge are missing');
}
const studyModePageStateEffectStart = studyModePage.indexOf(
  'window.dispatchEvent(new CustomEvent("study-mode-page-state", { detail: { open: true } }));',
);
const studyModePageStateEffectEnd = studyModePage.indexOf('\n  }, [handleBack]);', studyModePageStateEffectStart);
const studyModePageCleanupStart = studyModePage.indexOf(
  'return () => {\n      window.dispatchEvent(new CustomEvent("study-mode-page-state", { detail: { open: false } }));',
  studyModePageStateEffectStart,
);
const studyModePageCleanupEnd = studyModePage.indexOf('\n    };', studyModePageCleanupStart);
const studyModePageCleanup = studyModePageCleanupStart >= 0 && studyModePageCleanupEnd > studyModePageCleanupStart
  ? studyModePage.slice(studyModePageCleanupStart, studyModePageCleanupEnd)
  : '';
if (studyModePageStateEffectStart < 0 ||
    studyModePageStateEffectEnd < studyModePageStateEffectStart ||
    studyModePageCleanupStart < 0 ||
    studyModePageCleanupEnd < studyModePageCleanupStart ||
    /endStudyModeSession|setStudyModeEnabled|\.endSession\(|\.setEnabled\(/.test(studyModePageCleanup)) {
  fail('Leaving or unmounting the Study Mode page must remove only page listeners and must never end or disable a persisted focus session');
}
if (!studyModeSessionStore.includes('math_master_study_sessions.db') ||
    !studyModeSessionStore.includes('start_elapsed_ms') ||
    !studyModeSessionStore.includes('boot_count') ||
    !studyModeSessionStore.includes('selected_apps') ||
    !studyModeSessionStore.includes('status TEXT NOT NULL') ||
    !studyModeManager.includes('StudyModeSessionStore') ||
    !studyModeManager.includes('public static synchronized JSObject startSession') ||
    !studyModeManager.includes('public static synchronized JSObject endSession') ||
    !studyModeManager.includes('public static synchronized void reconcile') ||
    !studyModeManager.includes('getEnforcedPackages') ||
    !studyModeManager.includes('shouldEnforceNow') ||
    !studyModeManager.includes('ACTION_SESSION_BOUNDARY') ||
    !studyModeManager.includes('completeExpiredSession') ||
    !studyModeManager.includes('hasNotificationPolicyAccess(context)') ||
    !studyModePage.includes('startStudyModeSession') ||
    !studyModePage.includes('endStudyModeSession') ||
    !studyModePage.includes('checked={draft.enabled || Boolean(status.activeSession?.active)}') ||
    !studyModePage.includes('Promise.all([load(true), refreshApps])') ||
    !studyModeAppPlugin.includes('public void startSession(PluginCall call)') ||
    !studyModeAppPlugin.includes('public void endSession(PluginCall call)') ||
    !studyModeAppPlugin.includes('public void getSessionHistory(PluginCall call)') ||
    !studyModeFocus.includes('START_STICKY') ||
    !studyModeFocus.includes('StudyModeManager.shouldEnforceNow(this)') ||
    !studyModeFocus.includes('StudyModeManager.completeExpiredSession') ||
    !studyModeFocus.includes('updateOngoingNotification') ||
    !studyModeFocus.includes('UsageStatsManager') ||
    !studyModeFocus.includes('POLL_INTERVAL_MS') ||
    !studyModeManager.includes('hasUsageAccess(context)') ||
    !studyModeManager.includes('hasForegroundMonitoringPermission') ||
    studyModeSetup.includes('ensureAccessibilityService') ||
    studyModeSetup.includes('BIND_ACCESSIBILITY_SERVICE') ||
    studyModeSetup.includes('android.accessibilityservice.AccessibilityService') ||
    studyModeSetup.includes("copyFile(path.join(NATIVE_DIR, 'StudyModeAccessibilityService.java')") ||
    studyModeSetup.includes("writeFile(path.join(xmlTarget, 'study_mode_accessibility.xml')") ||
    studyModePage.includes('openStudyModePermission("accessibility")') ||
    studyModePage.includes('Multi-window detection') ||
    studyModeAppPlugin.includes('ACTION_ACCESSIBILITY_SETTINGS') ||
    !studyModeFocus.includes('StudyModeWindowRegistry.findBlockedPackage') ||
    !studyModeWindowRegistry.includes('MAX_SNAPSHOT_AGE_MS') ||
    !studyModeWindowRegistry.includes('snapshotComplete') ||
    !studyModeFocus.includes('MONITOR_HEALTH_TIMEOUT_MS = 10_000L') ||
    !studyModeFocus.includes('MONITOR_HEALTH_TIMEOUT_MS = 10_000L') ||
    !studyModeFocus.includes('isMonitoringHealthy()') ||
    !studyModeFocus.includes('blocking_active') ||
    !studyModeManager.includes('permissions.put("xiaomiDevice", isXiaomiDevice())') ||
    !studyModeAccessibilityService.includes('recoverFocusServiceIfNeeded("service_connected")') ||
    !studyModeAccessibilityService.includes('recoverFocusServiceIfNeeded("accessibility_event")') ||
    !studyModeAccessibilityService.includes('StudyModeManager.requestFocusServiceRecovery(this, reason)') ||
    studyModeAccessibilityService.includes('StudyModeManager.reconcile(this)') ||
    !studyModeManager.includes('requestFocusServiceRecovery(Context context, String reason)') ||
    !studyModeManager.includes('setExactAndAllowWhileIdle(') ||
    !studyModeAlarmReceiver.includes('onFocusServiceRecoveryAlarm(context)') ||
    !studyModeWindowRegistry.includes('ACCESSIBILITY_EVENT_TTL_MS = 2200L') ||
    !studyModeFocus.includes('requestImmediateEvaluation()') ||
    !studyModeFocus.includes('candidate.postOnAnimation(() -> verifyShieldVisibility(') ||
    studyModeAccessibilityService.includes('getText(') ||
    studyModeAccessibilityService.includes('performAction(') ||
    !studyModePage.includes('key: "usage" as const') ||
    !studyModePage.includes('getStudyModePermissionReadiness') ||
    !studyModeManager.includes('DevicePolicyManager') ||
    !studyModeManager.includes('setPackagesSuspended(getAdminComponent(context)') ||
    !studyModeManager.includes('isPackageSuspended(getAdminComponent(context), packageName)') ||
    !studyModeManager.includes('getActuallySuspendedPackages') ||
    !studyModeManager.includes('suspendedArray') ||
    !studyModeManager.includes('permission_required') ||
    !studyModeManager.includes('policy_unavailable') ||
    !studyModeManager.includes('AlarmManager') ||
    !studyModeManager.includes('canScheduleExactAlarms') ||
    !studyModeManager.includes('isDefaultDialerPackage') && !studyModeManager.includes('getDefaultDialerPackage')) {
  fail('Managed-device suspension, Advanced Accessibility recovery, Usage Access Focus Shield, truthful permission state, alarm fallback, or critical app protection is missing');
}
const islandMonitor = studyModeFocus.slice(
  studyModeFocus.indexOf('private final Runnable monitorRunnable'),
  studyModeFocus.indexOf('private boolean isPhoneCallActive()'),
);
const islandShow = studyModeFocus.slice(
  studyModeFocus.indexOf('private void showScreenTimeIsland('),
  studyModeFocus.indexOf('private void dismissScreenTimeIslandImmediately('),
);
const islandNativeFiles = [
  'StudyModeDayUsage.java',
  'ScreenTimeIslandSpring.java',
  'ScreenTimeIslandMotion.java',
  'ScreenTimeIslandPainter.java',
  'ScreenTimeIslandOverlay.java',
];
if (!islandNativeFiles.every((file) => studyModeSetup.includes(file)) ||
    !screenTimeIslandDayUsage.includes('Calendar.getInstance(zone)') ||
    !screenTimeIslandDayUsage.includes('hourlyMillis(String packageName)') ||
    /import android\./.test(screenTimeIslandDayUsage) ||
    /import android\./.test(screenTimeIslandSpring) ||
    !screenTimeIslandJvmTests.includes('testDstDayLengths()') ||
    !screenTimeIslandJvmTests.includes('testMidnightClip()') ||
    !screenTimeIslandJvmTests.includes('testScreenOffAndShutdown()')) {
  fail('Screen Time Island pure JVM aggregation, DST/midnight coverage, or generated native source registration is missing');
}
if (!islandMonitor.includes('StudyModeManager.isSelectedStudyAppPackage(StudyModeFocusService.this, activePackage)') ||
    !islandMonitor.includes('StudyModeManager.isPeriodicReminderExemptPackage(StudyModeFocusService.this, activePackage)') ||
    !islandMonitor.includes('StudyModeManager.isProStrictModeActive(StudyModeFocusService.this)') ||
    !islandMonitor.includes('StudyModeManager.shouldEnforceNow(StudyModeFocusService.this)') ||
    !islandMonitor.includes('islandUsage.sample(') ||
    !islandShow.includes('StudyModeManager.shouldEnforceNow(this)') ||
    !islandShow.includes('StudyModeManager.hasOverlayPermission(this)') ||
    !islandShow.includes('popup_conflict_timeout') ||
    !islandShow.includes('isPhoneCallActive()') ||
    !studyModeFocus.includes('dismissScreenTimeIslandImmediately("configuration_changed")') ||
    !studyModeFocus.includes('dismissScreenTimeIslandImmediately("screen_not_interactive")')) {
  fail('Screen Time Island must reuse the Focus monitor eligibility, popup priority, permission, and lifecycle guards');
}
if (!screenTimeIslandOverlay.includes('TYPE_APPLICATION_OVERLAY') ||
    !screenTimeIslandOverlay.includes('FLAG_NOT_FOCUSABLE') ||
    !screenTimeIslandOverlay.includes('FLAG_NOT_TOUCH_MODAL') ||
    !screenTimeIslandOverlay.includes('FLAG_NOT_TOUCHABLE') ||
    !screenTimeIslandOverlay.includes('Choreographer') ||
    !screenTimeIslandOverlay.includes('ACCESSIBILITY_LIVE_REGION_POLITE') ||
    !screenTimeIslandPainter.includes('Canvas') ||
    !screenTimeIslandPainter.includes('accentForTheme') ||
    !studyModeFocus.includes('ScreenTimeIslandPainter.accentForTheme(theme)') ||
    !studyModeSetup.includes('MathMaster-Regular.otf') ||
    !studyModeSetup.includes('MathMaster-Medium.otf') ||
    !studyModeSetup.includes('MathMaster-Bold.otf')) {
  fail('Screen Time Island overlay geometry, Canvas-only painter, shared theme accent, or Inter asset copy is missing');
}
if (/https?:\/\//.test(screenTimeIslandDayUsage + screenTimeIslandSpring + screenTimeIslandPainter + screenTimeIslandOverlay) ||
    /java\.net\.|WebView|AccessibilityNodeInfo|AccessibilityService|TYPE_ACCESSIBILITY_OVERLAY|getText\(/.test(
      screenTimeIslandDayUsage + screenTimeIslandSpring + screenTimeIslandPainter + screenTimeIslandOverlay
    ) ||
    /READ_PHONE_STATE|PACKAGE_USAGE_STATS|SYSTEM_ALERT_WINDOW/.test(
      studyModeSetup.slice(studyModeSetup.indexOf('const REQUIRED_PERMISSIONS'), studyModeSetup.indexOf('];', studyModeSetup.indexOf('const REQUIRED_PERMISSIONS')))
        .replace('android.permission.PACKAGE_USAGE_STATS', '')
        .replace('android.permission.SYSTEM_ALERT_WINDOW', '')
    ) ||
    /class ScreenTimeIsland.*Service|extends Service/.test(screenTimeIslandOverlay)) {
  fail('Screen Time Island must remain offline, avoid Accessibility text reading, and add no permission or service');
}
if (!studyModeManager.includes('setScreenTimeIsland(Context context, boolean enabled, int minutes)') ||
    !studyModeAppPlugin.includes('public void setScreenTimeIsland(PluginCall call)') ||
    !studyModeAppPlugin.includes('public void previewScreenTimeIsland(PluginCall call)') ||
    !studyModeBridge.includes('setStudyModeScreenTimeIsland') ||
    !studyModeBridge.includes('previewStudyModeScreenTimeIsland') ||
    !studyModePage.includes('aria-label="Enable Screen Time Island"') ||
    !studyModePage.includes('Screen Time Island interval') ||
    !studyModePage.includes('Overlay and Usage Access are needed') ||
    !css.includes('.study-mode-island-preview__capsule') ||
    !css.includes('@media (prefers-reduced-motion: reduce)')) {
  fail('Screen Time Island settings bridge, UI controls, permission setup, or reduced-motion preview is missing');
}

if (!studyModeAppPlugin.includes('getInstalledApplications') ||
    !studyModeAppPlugin.includes('checkPermission("android.permission.QUERY_ALL_PACKAGES"') ||
    !studyModeAppPlugin.includes('findLaunchablePackages') ||
    !studyModeAppPlugin.includes('Intent.CATEGORY_LAUNCHER') ||
    !studyModeAppPlugin.includes('Intent.CATEGORY_LEANBACK_LAUNCHER') ||
    !studyModeAppPlugin.includes('PackageManager.ResolveInfoFlags.of(0L)') ||
    !studyModeAppPlugin.includes('PackageManager.ApplicationInfoFlags.of(0L)') ||
    !studyModeAppPlugin.includes('StudyModeManager.isSystemApplication(info)') ||
    !studyModeAppPlugin.includes('item.put("systemApp", entry.systemApp)') ||
    !studyModeSetup.includes('android.permission.QUERY_ALL_PACKAGES') ||
    studyModeAppPlugin.includes('.take(15)') ||
    studyModeAppPlugin.includes('.subList(0, 15)') ||
    !studyModeManager.includes('FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP') ||
    !studyModeManager.includes('public static boolean isVisibleApplication') ||
    !studyModeManager.includes('public static boolean isSelectableApplication') ||
    !studyModeManager.includes('getProtectedPackages(context)') ||
    studyModeManager.includes('return (info.flags & ApplicationInfo.FLAG_SYSTEM) == 0') ||
    !studyModePage.includes('setAppFilter<') && !studyModePage.includes('setAppFilter(filter.id)') ||
    !studyModePage.includes('aria-label="Filter installed apps"') ||
    !studyModePage.includes('filterStudyModeApps(apps, appFilter, deferredSearch)') ||
    !studyModeAppFilters.includes('filter === "system" ? app.systemApp : !app.systemApp') ||
    !studyModePage.includes('disabled={!app.selectable || disabled}') ||
    !studyModePage.includes('selectionReady = cachedSettings !== null || status !== null') ||
    !studyModePage.includes('app.selectable ? (') ||
    !studyModeAppFilterTests.includes('selectable: false') ||
    !studyModeAppFilterTests.includes('shows user and pre-installed system apps together in All') ||
    !studyModeAppFilterTests.includes('searches app names and package names inside each category')) {
  fail('Study Mode app discovery must include launchable user and system apps, report category metadata, and preserve fast All/User/System filtering');
}

const studyModeInitialLoadStart = studyModePage.indexOf('const load = useCallback((reconcile = false): Promise<void> => {');
const studyModeInitialLoadEnd = studyModePage.indexOf(
  '\n\n  useEffect(() => {\n    isMountedRef.current',
  studyModeInitialLoadStart,
);
const studyModeInitialLoad = studyModeInitialLoadStart >= 0 && studyModeInitialLoadEnd > studyModeInitialLoadStart
  ? studyModePage.slice(studyModeInitialLoadStart, studyModeInitialLoadEnd)
  : '';
const studyModeAppLoaderStart = studyModePage.indexOf('const loadApps = useCallback');
const studyModeAppLoaderEnd = studyModePage.indexOf('const toggleBlockedPicker', studyModeAppLoaderStart);
const studyModeAppLoader = studyModeAppLoaderStart >= 0 && studyModeAppLoaderEnd > studyModeAppLoaderStart
  ? studyModePage.slice(studyModeAppLoaderStart, studyModeAppLoaderEnd)
  : '';
const studyModePickerHandlersStart = studyModePage.indexOf('const toggleBlockedPicker');
const studyModePickerHandlersEnd = studyModePage.indexOf('const load = useCallback', studyModePickerHandlersStart);
const studyModePickerHandlers = studyModePickerHandlersStart >= 0 && studyModePickerHandlersEnd > studyModePickerHandlersStart
  ? studyModePage.slice(studyModePickerHandlersStart, studyModePickerHandlersEnd)
  : '';

if (!studyModeBridge.includes('installedAppsCache.get()') ||
    !studyModeBridge.includes('installedAppsCache.get(true)') ||
    !studyModeBridge.includes('invalidateStudyModeAppCatalogCache') ||
    !studyModeAppCatalogCache.includes('if (pending) return pending') ||
    !studyModeAppCatalogCache.includes('generation += 1') ||
    !studyModeAppCatalogCacheTests.includes('deduplicates concurrent loads') ||
    !studyModeAppCatalogCacheTests.includes('does not cache a result invalidated while loading') ||
    !studyModeAppPlugin.includes('APP_CATALOG_CACHE_TTL_MS') ||
    !studyModeAppPlugin.includes('Collections.unmodifiableList(entries)') ||
    !studyModeAppPlugin.includes('getOrBuildAppCatalog(pm)') ||
    !studyModePackageReceiver.includes('StudyModePlugin.invalidateAppCatalogCache()') ||
    !studyModePackageReceiver.includes('Intent.ACTION_PACKAGE_ADDED') ||
    !studyModeSetup.includes('ensurePackageChangeReceiverActions(manifest)') ||
    !studyModeSetup.includes('android.intent.action.PACKAGE_ADDED') ||
    !studyModeSetup.includes('android.intent.action.PACKAGE_CHANGED') ||
    !studyModePage.includes('const SessionCountdown = memo') ||
    studyModePage.includes('setSessionTick') ||
    !studyModePage.includes('useDeferredValue(search)') ||
    !studyModePage.includes('loading="lazy" decoding="async"') ||
    studyModeInitialLoad.length === 0 ||
    studyModeInitialLoad.includes('getInstalledStudyModeApps(') ||
    !studyModeInitialLoad.includes('(reconcile = false)') ||
    !studyModeInitialLoad.includes('refreshStudyMode()') ||
    !studyModeInitialLoad.includes('getStudyModeStatus()') ||
    !studyModePage.includes('void load(false);') ||
    !studyModePage.includes('Promise.all([load(true), refreshApps])') ||
    !studyModeAppLoader.includes('getInstalledStudyModeApps(forceRefresh)') ||
    !studyModeAppLoader.includes('appCatalogLoadedRef.current') ||
    !studyModeAppLoader.includes('appCatalogLoadInFlightRef.current') ||
    !studyModeAppLoader.includes('setAppsLoadError(') ||
    !studyModePickerHandlers.includes('if (nextOpen) void loadApps(true)') ||
    !studyModePage.includes('appsLoading && apps.length === 0 ? (') ||
    !studyModePage.includes('appsLoadError && apps.length === 0 ? (') ||
    !studyModePage.includes('[apps, appFilter, deferredSearch, draft.selectedPackageNames]') ||
    !studyModePage.includes('[apps, deferredStudySearch, studyAppPackages]') ||
    !studyModePage.includes('History is non-critical') ||
    !studyModeAppCatalogCache.includes('peek(): T | undefined') ||
    !studyModeBridge.includes('getCachedInstalledStudyModeApps') ||
    !studyModeBridge.includes('5 * 60_000') ||
    !studyModeBridge.includes('NativeStudyMode.getAppCatalogRevision()') ||
    !studyModeBridge.includes('catalogRevision') ||
    !studyModeAppPlugin.includes('getChangedPackages(appCatalogPackageChangeSequence)') ||
    studyModePage.includes('invalidateStudyModeAppCatalogCache') ||
    !studyModePage.includes('getCachedStudyModeSettings') ||
    !studyModePage.includes('sortStudyModeAppsSelectedFirst') ||
    !studyModePage.includes('getCachedInstalledStudyModeApps() !== null') ||
    !studyModePage.includes('Refreshing installed apps… selection is paused') ||
    !studyModeAppFilterTests.includes('pins only the current picker') ||
    !studyModeAppPlugin.includes('listApps cacheHit=')) {
  fail('Study Mode performance regression: app inventory must be cached/in-flight deduplicated, countdown isolated, app search deferred, and session history must not gate first interaction');
}
if (!studyModeManager.includes('public static synchronized void setProEnabled') ||
    !studyModeManager.includes('isProStrictModeActive(Context context)') ||
    !studyModeManager.includes('isPackageRestricted(Context context, String packageName)') ||
    !studyModeManager.includes('getPolicyEnforcedPackages(Context context)') ||
    !studyModeAppPlugin.includes('public void setProEnabled(PluginCall call)') ||
    !studyModeAppPlugin.includes('getAppCatalogRevision(PluginCall call)') ||
    !studyModeFocus.includes('StudyModeManager.isPackageRestricted(\n                StudyModeFocusService.this, foreground)') ||
    !studyModeWindowRegistry.includes('StudyModeManager.isPackageRestricted(context, window.packageName)') ||
    !studyModePage.includes('setStudyModeProEnabled(enabled)') ||
    !studyModePage.includes('persistProAllowlist')) {
  fail('PRO must persist a strict Study Apps allowlist, share one enforcement predicate, and update it without a service restart');
}
if (!studyModeManager.includes('public static synchronized void setEnabled') ||
    !studyModeManager.includes('public static synchronized void reconcile') ||
    !studyModeAppPlugin.includes('public void getStatus(PluginCall call) {\n        call.resolve(StudyModeManager.getStatus(getContext()));') ||
    !studyModeFocus.includes('public static boolean isStarting()') ||
    !studyModeFocus.includes('public static boolean isStopping()') ||
    !studyModeFocus.includes('stopping = false;') ||
    !studyModeManager.includes('StudyModeFocusService.isStopping()') ||
    !studyModeFocus.includes('StudyModeManager.shouldEnforceNow(this)') ||
    !studyModePage.includes('recoveryAttemptRef.current = true') ||
    !studyModePage.includes('status.enforcementState !== "service_stopped"')) {
  fail('Study Mode master toggle must serialize native mutations, expose side-effect-free status reads, and report foreground-service startup truthfully');
}
if (!studyModeFocus.includes('UsageStatsManager') ||
    !studyModeFocus.includes('queryEvents') ||
    !studyModeFocus.includes('HandlerThread') ||
    !studyModeFocus.includes('THREAD_PRIORITY_BACKGROUND') ||
    !studyModeFocus.includes('TYPE_APPLICATION_OVERLAY') ||
    !studyModeFocus.includes('FOREGROUND_SERVICE_TYPE_SPECIAL_USE') ||
    !studyModeFocus.includes('service_start_blocked') ||
    !studyModeFocus.includes('lastForegroundPackage')) {
  fail('Personal-phone Focus Shield must use Usage Access, overlay permission, a user-visible foreground service and actual service state');
}

const taskRemovalStart = studyModeFocus.indexOf('public void onTaskRemoved(Intent rootIntent)');
const taskRemovalEnd = studyModeFocus.indexOf('public void onDestroy()', taskRemovalStart);
const taskRemovalHandler = taskRemovalStart >= 0 && taskRemovalEnd > taskRemovalStart
  ? studyModeFocus.slice(taskRemovalStart, taskRemovalEnd)
  : '';
if (taskRemovalStart < 0 ||
    taskRemovalEnd < 0 ||
    !taskRemovalHandler.includes('resetForegroundResolution();') ||
    !taskRemovalHandler.includes('monitorRunnable.run();') ||
    !taskRemovalHandler.includes('updateOngoingNotification();') ||
    /stopSelf|stopService|finishSession|setEnabled|finishIfExpired|\.delete\(/.test(taskRemovalHandler) ||
    !studyModeSetup.includes('android:stopWithTask="false"') ||
    !studyModeFocus.includes('return START_STICKY')) {
  fail('Recent Apps removal must reset the UsageEvents cursor without stopping the native service or mutating the persisted session');
}
if (!studyModeFocus.includes('resetForegroundResolution();') ||
    !studyModeFocus.includes('EMPTY_INITIAL_LOOKUP_RETRY_MS') ||
    !studyModeFocus.includes('INITIAL_EVENT_LOOKBACK_MS') ||
    !studyModeFocus.includes('EVENT_QUERY_OVERLAP_MS') ||
    !studyModeFocus.includes('updateOngoingNotification();') ||
    !studyModeManager.includes('App blocking paused · required permission is off') ||
    !studyModeFocus.includes('setServiceState(this, "permission_required")')) {
  fail('Screen wake must reset/rebuild the foreground cursor, wide-history recovery must be bounded, and permission loss must remain visible in the persistent notification');
}
if (!studyModeFocus.includes('boolean decisionChanged = !foreground.equals(lastDecisionPackage)') ||
    !studyModeFocus.includes('decision_changed_before_visibility_check') ||
    !studyModeFocus.includes('decision_changed_during_popup_build') ||
    !studyModeFocus.includes('verifiedRequestId, decisionSequence')) {
  fail('Popup request generation must remain stable during unchanged foreground polls and invalidate stale display work on real decision transitions');
}
if (!studyModeFocus.includes('public static boolean hasForegroundLookupFailure()') ||
    !studyModeManager.includes('state = "monitoring_unavailable"') ||
    !studyModePage.includes('status.enforcementState === "monitoring_unavailable"') ||
    !studyModePage.includes('grant Usage Access')) {
  fail('Study Mode must report monitoring unavailable when UsageStats cannot identify the foreground app');
}
if (!studyModeFocus.includes('private synchronized void resetPopupRetryState()') ||
    !studyModeFocus.includes('private synchronized void recordPopupLaunchFailure(String packageName)') ||
    !studyModeFocus.includes('private synchronized boolean shouldDeferPopupLaunch(String packageName, String requestId)') ||
    !studyModeFocus.includes('resetPopupRetryStateForDifferentPackage(foreground)')) {
  fail('Popup retry counters must be synchronized because monitor and main threads both update retry state');
}
if (!studyModeFocus.includes('hasOverlayFailure()') ||
    !studyModeManager.includes('StudyModeFocusService.getMonitoringState()') ||
    !studyModeFocus.includes('view.isAttachedToWindow()') ||
    !studyModeFocus.includes('view.getWindowToken()') ||
    !studyModeFocus.includes('windowManager.removeViewImmediate(existingView)') ||
    !studyModeFocus.includes('previous_overlay_removal_failed') ||
    !studyModeFocus.includes('POPUP_WINDOW_VISIBLE') ||
    !studyModeFocus.includes('MAX_POPUP_FAILURES_PER_FOREGROUND')) {
  fail('Focus Shield must verify actual overlay attachment, preserve removal failures without stacking views, bound retries, and report overlay failures truthfully');
}
const studyModeNativeFiles = studyModeSetup.match(/const NATIVE_FILES = \[([\s\S]*?)\];/)?.[1] ?? '';
if (studyModeNativeFiles.includes('StudyModeNotificationListenerService') ||
    studyModeSetup.includes('BIND_NOTIFICATION_LISTENER_SERVICE') ||
    studyModeManager.includes('StudyModeNotificationListenerService') ||
    studyModeManager.includes('notificationListenerConnected') ||
    studyModeManager.includes('notificationBlockingEnabled') ||
    studyModePage.includes('notificationAccess') ||
    studyModePage.includes('notificationBlockingEnabled') ||
    studyModeBridge.includes('notificationAccess') ||
    studyModeBridge.includes('permission: "notifications"') ||
    studyModeSchedule.includes('notificationBlockingEnabled')) {
  fail('Sideloadable Android builds must not package Play Protect-sensitive notification-listener access');
}
if (!studyModeSetup.includes('StudyModeSessionStore.java') ||
    !studyModeNativeFiles.includes('StudyModeWindowRegistry.java') ||
    !studyModeSetup.includes('app/src/main/java') ||
    studyModeSetup.includes('BIND_ACCESSIBILITY_SERVICE') ||
    studyModeSetup.includes('flagRetrieveInteractiveWindows') ||
    studyModeSetup.includes("copyFile(path.join(NATIVE_DIR, 'StudyModeAccessibilityService.java')") ||
    studyModeSetup.includes("writeFile(path.join(xmlTarget, 'study_mode_accessibility.xml')") ||
    !studyModeSetup.includes('MATHMASTER_UNIVERSAL_STUDY_MODE') ||
    !studyModeSetup.includes('android.permission.ACCESS_NOTIFICATION_POLICY') ||
    !studyModeSetup.includes('android.intent.category.LAUNCHER') ||
    studyModeSetup.includes('android.provider.Telephony.SMS_DELIVER') ||
    !studyModeSetup.includes('android.permission.QUERY_ALL_PACKAGES') ||
    !studyModeSetup.includes('StudyModeDeviceAdminReceiver') ||
    !studyModeSetup.includes("packageVisibility: 'all-installed-packages'") ||
    !widgetSetup.includes('configureAndroidWidgets(androidRoot)') ||
    !validationWorkflow.includes('run: node scripts/configure-android-study-mode.mjs') ||
    !validationWorkflow.includes('run: node scripts/configure-android-widgets.mjs') ||
    !studyModeBoot.includes('StudyModeManager.reconcile(context)')) {
  fail('Generated Android project must use launcher-only package visibility, omit SMS queries and notification-listener access, and restore Study Mode schedules');
}


const studyModeQuoteAndApps = read('android-native/com/sudhanshu/mathsbj/StudyModeManager.java');
const studyModeShieldUi = read('android-native/com/sudhanshu/mathsbj/StudyModeFocusService.java');
const studyModeNativePlugin = read('android-native/com/sudhanshu/mathsbj/StudyModePlugin.java');
if (!studyModeQuoteAndApps.includes('KEY_STUDY_PACKAGES')
    || !studyModeQuoteAndApps.includes('getSelectedStudyAppPackages')
    || !studyModeQuoteAndApps.includes('savePopupAppearance')
    || !studyModeQuoteAndApps.includes('getNextMotivationalQuote')
    || !studyModeQuoteAndApps.includes('launchStudyApp')
    || !studyModeQuoteAndApps.includes('Blocked Apps take priority')
    || !studyModeShieldUi.includes('StudyModeManager.getNextMotivationalQuote(this)')
    || !studyModeShieldUi.includes('StudyModeManager.getSelectedStudyAppPackages(this)')
    || !studyModeShieldUi.includes('StudyModeManager.launchStudyApp(StudyModeFocusService.this, packageName)')
    || !studyModeShieldUi.includes('Session ends at ')
    || studyModeShieldUi.includes('Back to Math Master')
    || studyModeShieldUi.includes('mathmaster://learn')
    || !studyModeShieldUi.includes('StudyModeManager.getCurrentSessionRemainingSeconds(this)')
    || !studyModeShieldUi.includes('StudyModeManager.getCurrentSessionEndMillis(this)')
    || !studyModeNativePlugin.includes('setPopupAppearance')
    || !studyModeNativePlugin.includes('studyAppPackageNames')
    || !studyModeBridge.includes('studyAppPackageNames')
    || !studyModeBridge.includes('theme-updated')) {
  fail('Study Mode shield must keep separate persisted app lists, conflict-safe real launcher actions, dynamic quotes, countdown, and theme synchronization');
}

if (!studyModeUsageAccumulator.includes('MAX_SAMPLE_GAP_MS = 4_000L') ||
    !studyModeUsageAccumulator.includes('elapsedRealtimeMs >= lastSampleElapsedMs') ||
    !studyModeUsageAccumulator.includes('void resetInterval()') ||
    !studyModeWindowRegistry.includes('findFocusedPackage(Context context, String usageForegroundPackage)') ||
    !studyModeWindowRegistry.includes('if (!fresh || !complete) return null;') ||
    !studyModeManager.includes('setReminderIntervalMinutes(Context context, int value)') ||
    !studyModeManager.includes('KEY_REMINDER_INTERVAL_MINUTES') ||
    !studyModeManager.includes('periodicReminderSystemPackagesCacheAtElapsedMs') ||
    !studyModeManager.includes('5L * 60L * 1000L') ||
    !studyModeFocus.includes('findFocusedPackage(StudyModeFocusService.this, foreground)') ||
    !studyModeFocus.includes('periodicReminderUsage.sample(') ||
    !studyModeFocus.includes('dismissPeriodicReminder("continue_anyway", true)') ||
    !studyModePage.includes('Reminder Interval') ||
    !studyModePage.includes('Array.from({ length: 10 }, (_, index) => index + 1)') ||
    !studyModeBridge.includes('export async function setStudyModeReminderInterval(minutes: number)') ||
    !studyModeSetup.includes('StudyModeUsageAccumulator.java')) {
  fail('Periodic reminders must use monotonic focused-window usage, validated 1–10 minute persistence and generated Android packaging');
}

const studyModeReminderPersistence = read('android-native/com/sudhanshu/mathsbj/StudyModeUsageAccumulator.java');
const studyModeReminderManager = read('android-native/com/sudhanshu/mathsbj/StudyModeManager.java');
const studyModeReminderFocus = read('android-native/com/sudhanshu/mathsbj/StudyModeFocusService.java');
const studyModeReminderPlugin = read('android-native/com/sudhanshu/mathsbj/StudyModePlugin.java');
const studyModeReminderIndex = read('src/pages/Index.tsx');
const studyModeReminderLearning = read('src/pages/LearningPage.tsx');
if (!studyModeReminderPersistence.includes('REMINDER_PENDING, REMINDER_VISIBLE')
    || !studyModeReminderPersistence.includes('restoreAccumulatedUsageMs(long value)')
    || !studyModeReminderPersistence.includes('state == State.REMINDER_PENDING')
    || !studyModeReminderManager.includes('KEY_REMINDER_USAGE_MS')
    || !studyModeReminderManager.includes('KEY_PENDING_REMINDER_ID')
    || !studyModeReminderManager.includes('savePendingPeriodicReminder(Context context, String reminderId, String packageName)')
    || !studyModeReminderFocus.includes('StudyModeManager.savePendingPeriodicReminder(this, reminderId, packageName)')
    || !studyModeReminderFocus.includes('restorePeriodicReminderOverlay()')
    || !studyModeReminderFocus.includes('shieldView != null || popupState != PopupState.IDLE')
    || !studyModeReminderFocus.includes('periodicReminderUsage.dismissReminder(resetInterval)')
    || !studyModeReminderFocus.includes('suspendPeriodicReminderForBlockedApp()')
    || studyModeReminderFocus.includes('dismissPeriodicReminder("focused_app_changed"')
    || !studyModeReminderFocus.includes('dispatchKeyEvent(KeyEvent event)')
    || !studyModeReminderManager.includes('openStudyAppsSelection(Context context)')
    || !studyModeReminderPlugin.includes('consumeOpenStudyAppsPickerRequest')
    || !studyModeBridge.includes('consumeStudyAppsPickerRequest')
    || !studyModeReminderIndex.includes('consumeStudyAppsPickerRequest')
    || !studyModeReminderIndex.includes('if (isPracticeSessionInProgress(practicePhase))')
    || !studyModeReminderIndex.includes('studyAppsPickerPending')
    || !studyModeReminderLearning.includes('openStudyAppsPicker={openStudyAppsPickerAfterMount}')
    || !studyModePage.includes('setStudyPickerOpen(true)')) {
  fail('Periodic reminders must remain latched and recover across service restarts, stay open through focus changes, and route the empty Study Apps state to the real picker');
}


const expandableStudySections = [
  ["focusProtection", "Expand Focus Protection", "Collapse Focus Protection", "study-mode-focus-protection-content"],
  ["focusSession", "Expand Focus Session", "Collapse Focus Session", "study-mode-focus-session-content"],
  ["studySchedule", "Expand Study Schedule", "Collapse Study Schedule", "study-mode-study-schedule-content"],
];
if (!studyModePage.includes('STUDY_MODE_SECTION_UI_STORAGE_KEY = "math-master.study-mode-section-ui.v1"')
    || !studyModePage.includes("const readStudyModeSectionExpansion =")
    || !studyModePage.includes("setExpandedSections((current) => ({ ...current, [section]: !current[section] }))")
    || !studyModePage.includes("JSON.stringify(expandedSections)")
    || !studyModePage.includes("permissions: saved.permissions === true")
    || !studyModePage.includes("aria-label={permissionsExpanded ? \"Collapse Android permissions\" : \"Expand Android permissions\"}")
    || !css.includes("@media (min-width: 560px) {\n  html.desktop-mode .study-mode-app-collections")
    || !studyModePage.includes("aria-hidden={!expandedSections.focusProtection}")
    || !studyModePage.includes("aria-hidden={!expandedSections.focusSession}")
    || !studyModePage.includes("aria-hidden={!expandedSections.studySchedule}")
    || !css.includes(".study-mode-expandable.is-expanded")
    || !css.includes("grid-template-rows: 0fr")
    || !css.includes("@media (prefers-reduced-motion: reduce)")) {
  fail("Study Mode sections must independently persist UI-only preferences, remain mounted, animate accessibly, and respect reduced motion");
}
for (const [section, expandLabel, collapseLabel, contentId] of expandableStudySections) {
  if (!studyModePage.includes(`toggleSection("${section}")`)
      || !studyModePage.includes(`aria-label={expandedSections.${section} ? "${collapseLabel}" : "${expandLabel}"}`)
      || !studyModePage.includes(`aria-controls="${contentId}"`)) {
    fail(`Study Mode expandable section wiring is incomplete: ${section}`);
  }
}

console.log('Architecture regression checks passed.');
